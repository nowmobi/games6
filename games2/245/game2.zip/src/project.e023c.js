window.__require = function e(n, a, o) {
    function i(r, c) {
        if (!a[r]) {
            if (!n[r]) {
                var d = r.split("/");
                if (d = d[d.length - 1],
                !n[d]) {
                    var s = "function" == typeof __require && __require;
                    if (!c && s)
                        return s(d, !0);
                    if (t)
                        return t(d, !0);
                    throw new Error("Cannot find module '" + r + "'")
                }
                r = d
            }
            var l = a[r] = {
                exports: {}
            };
            n[r][0].call(l.exports, function(e) {
                return i(n[r][1][e] || e)
            }, l, l.exports, e, n, a, o)
        }
        return a[r].exports
    }
    for (var t = "function" == typeof __require && __require, r = 0; r < o.length; r++)
        i(o[r]);
    return i
}({
    4399: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "95b70THLKNMBZyMSbcGkV65", "4399"),
        cc.Class({
            extends: cc.Component,
            properties: {},
            start: function() {
                window.is4399 || (this.node.active = !1)
            }
        }),
        cc._RF.pop()
    }
    , {}],
    AlertBanner: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "56642tK5UFLzJlJmALk/B8E", "AlertBanner"),
        cc.Class({
            extends: cc.Component,
            properties: {
                Img: {
                    default: null,
                    type: cc.Sprite,
                    displayName: "底图"
                },
                CloseButton: {
                    default: null,
                    type: cc.Node,
                    displayName: "关闭按钮"
                }
            },
            onLoad: function() {
                this.nativeInstance = null,
                this.CloseButton.active = !1,
                this.Img.node.active = !1,
                this.node.active = !1
            },
            executeRefresh: function(e, n, a) {
                var o = this
                  , i = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null;
                console.log("刷新弹出Banner"),
                this.handle = i,
                this.CloseButton.active = !1,
                cc.tween(this.CloseButton).delay(3).call(function() {
                    o.CloseButton.active = !0
                }).start(),
                this.nativeInstance = e,
                this.imgPath = n,
                this.code = a,
                cc.loader.load({
                    url: n,
                    type: "jpg"
                }, function(e, n) {
                    o.Img.node.active = !0,
                    o.Img.spriteFrame = new cc.SpriteFrame(n),
                    o.node.active = !0
                }),
                this.nativeInstance.reportAdShow({
                    adId: this.code
                })
            },
            executeDisplay: function() {
                this.nativeInstance ? this.node.active = !0 : this.node.active = !1
            },
            executeTouch: function() {
                this.nativeInstance && this.nativeInstance.reportAdClick({
                    adId: this.code
                })
            },
            executeClose: function() {
                this.node.active = !1,
                this.handle && this.handle()
            },
            buttonTouchEventCallBack: function(e) {
                switch (e.target.name) {
                case "closeButton":
                    this.executeClose();
                    break;
                case "window":
                case "showButton":
                    this.executeTouch()
                }
            }
        }),
        cc._RF.pop()
    }
    , {}],
    BoxHotWindow: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "8f630sFmJdBfqp9ubEhmXJP", "BoxHotWindow"),
        cc.Class({
            extends: cc.Component,
            properties: {
                MaskNode: {
                    default: null,
                    type: cc.Node,
                    displayName: "可视节点"
                },
                ItemContent: {
                    default: null,
                    type: cc.Node,
                    displayName: "单元容器"
                },
                ItemPrefab: {
                    default: null,
                    type: cc.Prefab,
                    displayName: "单元预制体"
                }
            },
            onLoad: function() {
                this.allowRoll = !1,
                this.rollDirection = 0,
                this.moveSpeed = 12,
                this.ItemContent.removeAllChildren(!0)
            },
            start: function() {
                this.ItemContent.getComponent(cc.Layout).updateLayout();
                var e = this.ItemContent.getContentSize().height
                  , n = this.MaskNode.getContentSize().height;
                this.distance = e - n,
                console.log("滑动距离 = ", this.distance),
                this.ItemContent.on(cc.Node.EventType.TOUCH_START, this.onTouchStart, this),
                this.ItemContent.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this),
                this.ItemContent.on(cc.Node.EventType.TOUCH_CANCEL, this.onTouchEnd, this),
                this.ItemContent.on(cc.Node.EventType.TOUCH_END, this.onTouchEnd, this),
                this.allowRoll = !0,
                this.node.active = !1
            },
            instantiation: function(e) {
                for (var n = 0; n < e.length; n++) {
                    console.log("123123123123");
                    var a = cc.instantiate(this.ItemPrefab);
                    this.ItemContent.addChild(a),
                    a.getComponent("NormalHotItem").instantiation(e[n])
                }
            },
            update: function(e) {
                if (this.allowRoll) {
                    var n = this.ItemContent.y;
                    if (0 === this.rollDirection) {
                        if ((n += this.moveSpeed * e) >= this.distance)
                            return this.ItemContent.y = this.distance,
                            void (this.rollDirection = 1);
                        this.ItemContent.y = n
                    } else {
                        if ((n -= this.moveSpeed * e) <= 0)
                            return this.ItemContent.y = 0,
                            void (this.rollDirection = 0);
                        this.ItemContent.y = n
                    }
                }
            },
            resetPlayPepleNumber: function() {
                for (var e = this.ItemContent.children, n = 0; n < e.length; n++)
                    e[n].getComponent("NormalHotItem").setPlayPepleNumber()
            },
            buttonTouchEventCallBack: function(e) {
                this.node.active = !1
            },
            onTouchStart: function(e) {
                this.allowRoll = !1,
                this.firstTouchPoint = this.ItemContent.convertToNodeSpaceAR(e.getLocation())
            },
            onTouchMove: function(e) {
                if (!this.allowRoll) {
                    var n = e.getDelta().y;
                    this.ItemContent.y += n,
                    this.ItemContent.y >= this.distance && (this.ItemContent.y = this.distance),
                    this.ItemContent.y <= 0 && (this.ItemContent.y = 0)
                }
            },
            onTouchEnd: function(e) {
                if (!this.allowRoll) {
                    this.allowRoll = !0;
                    var n = this.ItemContent.convertToNodeSpaceAR(e.getLocation());
                    if (this.firstTouchPoint.sub(n).mag() < 10)
                        for (var a = this.ItemContent.children, o = 0; o < a.length; o++) {
                            var i = a[o];
                            if (i.getBoundingBox().contains(n)) {
                                var t = i.getComponent("NormalHotItem").detail.package;
                                window.swan.navigateToMiniProgram({
                                    appKey: t,
                                    path: "/path/page/0",
                                    extraData: {
                                        from: "快乐玻璃杯"
                                    },
                                    success: function() {},
                                    fail: function(e) {}
                                });
                                break
                            }
                        }
                }
            }
        }),
        cc._RF.pop()
    }
    , {}],
    ButtonControl: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "24bedKlwE5J9abIt485kDHo", "ButtonControl");
        var o = e("../resources/Platform/PlatformUtils")
          , i = e("./Utils");
        cc.Class({
            extends: cc.Component,
            properties: {},
            onLoad: function() {
                var e = this.node.getComponent(cc.Sprite)
                  , n = e.spriteFrame.name
                  , a = n.split("-");
                n = cc.PlatformUtils.PlatformCode === o.PlatformList.头条 ? "".concat(a[0], "-tt") : "".concat(a[0], "-other"),
                i.AssMgr.setSpriteFrameByName(e, n)
            }
        }),
        cc._RF.pop()
    }
    , {
        "../resources/Platform/PlatformUtils": "PlatformUtils",
        "./Utils": "Utils"
    }],
    BuyMoneyItem: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "9ea6aXxK65B57trKoAoNnHc", "BuyMoneyItem");
        var o = e("../../TweenClass")
          , i = e("../../Utils");
        cc.Class({
            extends: cc.Component,
            properties: {},
            onLoad: function() {
                o.TweenClass.scale_3_1_Tween(this.node.children[1])
            },
            start: function() {
                this.jingBin_Count = 200,
                cc.PlatformUtils.executeShowBanner(cc.v2(cc.view.getVisibleSize().width / 2, cc.view.getVisibleSize().height), cc.v2(.5, 0)),
                cc.PlatformUtils.executeShowInterstitial(!0)
            },
            button_Click: function(e) {
                var n = this;
                switch (i.SoundMgr.playEffect("button"),
                e.target.name) {
                case "lingqu":
                    cc.PlatformUtils.executeShowVideo(function() {
                        cc.create_JiangLi(n.jingBin_Count)
                    });
                    break;
                case "fangqi":
                    cc.PlatformUtils.excuteRandSuiji()
                }
                o.TweenClass.scale_close_Tween(this.node.children[1])
            }
        }),
        cc._RF.pop()
    }
    , {
        "../../TweenClass": "TweenClass",
        "../../Utils": "Utils"
    }],
    CarItem: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "30b55EuJYRBdqdSiQ2f9XaK", "CarItem");
        var o = e("../../Utils")
          , i = e("../../Config/StorgeInfo");
        cc.Class({
            extends: cc.Component,
            properties: {},
            onLoad: function() {
                this.Img = this.node.getComponent(cc.Sprite),
                this.node.left_distance = 0,
                this.node.right_distance = 0,
                this.node.top_distance = 0,
                this.node.down_distance = 0,
                this.stop_x = this.node.x,
                this.stop_y = this.node.y
            },
            initialize: function(e, n, a, i, t) {
                this.isLandscape = a,
                this.distance = i,
                this.alteration_handle = t,
                this.node.distance = i,
                this.node.is_landscape = a,
                this.is_main = n,
                o.AssMgr.setSpriteFrameByName(this.Img, e)
            },
            start: function() {},
            init: function() {
                var e, n, a = this.distance % 2 == 0;
                if (this.isLandscape) {
                    a ? (e = this.node.x - this.distance / 2 * i.Grid_Width + i.Grid_Width / 2,
                    n = this.node.y) : (e = this.node.x - this.distance / 2 * i.Grid_Width,
                    n = this.node.y);
                    for (var o = 0; o < this.distance; o++) {
                        var t = e + i.Grid_Width * o + i.Max_Width / 2
                          , r = i.Max_Width / 2 - this.node.y
                          , c = parseInt(Math.abs(r) / i.Grid_Width)
                          , d = parseInt(t / i.Grid_Height);
                        this.alteration_handle(c, d)
                    }
                } else {
                    a ? (e = this.node.x,
                    n = this.node.y + this.distance / 2 * i.Grid_Height - i.Grid_Height / 2) : (e = this.node.x,
                    n = this.node.y + this.distance / 2 * i.Grid_Height);
                    for (var s = 0; s < this.distance; s++) {
                        var l = i.Max_Width / 2 + this.node.x
                          , x = n - i.Grid_Height * s - i.Max_Height / 2
                          , m = parseInt(Math.abs(x) / i.Grid_Width)
                          , f = parseInt(l / i.Grid_Height);
                        this.alteration_handle(m, f)
                    }
                }
            },
            calculateMoveDistance: function(e) {
                var n = this;
                if (this.isLandscape) {
                    for (var a = this.node.x + parseInt(this.distance / 2) * i.Grid_Width - (this.distance % 2 == 0 ? i.Grid_Width / 2 : 0), t = this.node.x - parseInt(this.distance / 2) * i.Grid_Width + (this.distance % 2 == 0 ? i.Grid_Width / 2 : 0), r = parseInt((i.Max_Height / 2 - this.node.y) / i.Grid_Height), c = parseInt((a + i.Max_Width / 2) / i.Grid_Width), d = 0, s = c + 1; s < i.Max_Col && 1 !== e[r][s]; s++)
                        d++;
                    this.node.right_distance = d * i.Grid_Width + this.node.x + this.node.width / 2,
                    d = 0;
                    for (var l = (c = parseInt((t + i.Max_Width / 2) / i.Grid_Width)) - 1; l >= 0 && 1 !== e[r][l]; l--)
                        d++;
                    if (this.node.left_distance = this.node.x - d * i.Grid_Width - this.node.width / 2,
                    cc.isStartGame && this.is_main && (console.log("车 ------------------"),
                    console.log(this.node.right_distance, i.Max_Width / 2 - i.Grid_Width / 2),
                    this.node.right_distance === i.Max_Width / 2 - i.Grid_Width / 2)) {
                        if (cc.time_count = null,
                        cc.set_Button_Color(),
                        this.node.parent.parent.pauseSystemEvents(),
                        cc.director.getScene().getChildByName("pushHint") && cc.director.getScene().getChildByName("pushHint").removeFromParent(),
                        "module-4" === cc.StorageInfo.click_ModuleName || "module-3" === cc.StorageInfo.click_ModuleName)
                            return o.SoundMgr.playEffect("model-3-4"),
                            void cc.tween(this.node).to(1, {
                                position: cc.v2(this.node.right_distance + i.Max_Width / 3, this.node.y)
                            }, {
                                easing: "smooth"
                            }).call(function() {
                                console.log("胜利!!!"),
                                window['uptap'].ShowScreenVideo("游戏结束",()=>{});
                                n.create_VictoryUI()
                            }).start();
                        o.SoundMgr.playEffect("model-1-2-qian"),
                        o.SoundMgr.playEffect("model-1-2");
                        cc.tween().to(.5, {
                            opacity: 255
                        }, {
                            easing: "smooth"
                        }).to(.5, {
                            opacity: 0
                        }, {
                            easing: "smooth"
                        });
                        cc.tween(this.node.children[0]).delay(1).to(.5, {
                            opacity: 255
                        }, {
                            easing: "smooth"
                        }).call(function() {
                            cc.tween(n.node).to(1.8, {
                                position: cc.v2(n.node.right_distance + i.Max_Width / 3, n.node.y)
                            }, {
                                easing: "smooth"
                            }).call(function() {
                                console.log("胜利!!!"),
                                window['uptap'].ShowScreenVideo("游戏结束",()=>{});
                                n.create_VictoryUI()
                            }).start()
                        }).start()
                    }
                } else {
                    for (var x = this.node.y + parseInt(this.distance / 2) * i.Grid_Height - (this.distance % 2 == 0 ? i.Grid_Height / 2 : 0), m = this.node.y - parseInt(this.distance / 2) * i.Grid_Height + (this.distance % 2 == 0 ? i.Grid_Height / 2 : 0), f = Math.abs(parseInt((m - i.Max_Height / 2) / i.Grid_Height)), y = parseInt((i.Max_Width / 2 + this.node.x) / i.Grid_Width), h = 0, u = f + 1; u < i.Max_Row && 1 !== e[u][y]; u++)
                        h++;
                    this.node.down_distance = this.node.y - h * i.Grid_Height,
                    h = 0;
                    for (var I = (f = Math.abs(parseInt((x - i.Max_Height / 2) / i.Grid_Height))) - 1; I >= 0 && 1 !== e[I][y]; I--)
                        h++;
                    this.node.top_distance = h * i.Grid_Height + this.node.y
                }
            },
            executeStop: function(e) {
                if (this.isLandscape) {
                    var n = 0
                      , a = this.node.x
                      , o = parseInt(Math.abs(a - this.stop_x) / i.Grid_Width);
                    parseInt(Math.abs(a - this.stop_x) % i.Grid_Width) >= i.Grid_Width / 2 && (n = i.Grid_Width),
                    a > this.stop_x ? this.node.x = this.stop_x + o * i.Grid_Width + n : this.node.x = this.stop_x - o * i.Grid_Width - n
                } else {
                    var t = 0
                      , r = this.node.y
                      , c = parseInt(Math.abs(r - this.stop_y) / i.Grid_Height);
                    parseInt(Math.abs(r - this.stop_y) % i.Grid_Height) >= i.Grid_Height / 2 && (t = i.Grid_Height),
                    r > this.stop_y ? this.node.y = this.stop_y + c * i.Grid_Height + t : this.node.y = this.stop_y - c * i.Grid_Height - t
                }
                this.setMapList(e),
                console.log("map  = ", e),
                this.stop_x = this.node.x,
                this.stop_y = this.node.y,
                cc.hint()
            },
            setMapList: function(e) {
                var n = this.distance % 2 == 0;
                if (this.isLandscape) {
                    var a, o;
                    this.old_col = null,
                    n ? (a = this.node.x - this.distance / 2 * i.Grid_Width + i.Grid_Width / 2,
                    this.node.y,
                    o = this.stop_x - this.distance / 2 * i.Grid_Width + i.Grid_Width / 2,
                    this.stop_y) : (a = this.node.x - this.distance / 2 * i.Grid_Width,
                    this.node.y,
                    o = this.stop_x - this.distance / 2 * i.Grid_Width,
                    this.stop_y);
                    for (var t = 0; t < this.distance; t++) {
                        var r = o + i.Grid_Width * t + i.Max_Width / 2
                          , c = i.Max_Height / 2 - this.stop_y
                          , d = parseInt(c / i.Grid_Width)
                          , s = parseInt(r / i.Grid_Height);
                        e[d][s] = 0
                    }
                    for (var l = 0; l < this.distance; l++) {
                        var x = a + i.Grid_Width * l + i.Max_Width / 2
                          , m = i.Max_Height / 2 - this.node.y
                          , f = parseInt(m / i.Grid_Width)
                          , y = parseInt(x / i.Grid_Height);
                        e[f][y] = 1
                    }
                } else {
                    var h, u;
                    this.old_row = null,
                    n ? (this.node.x,
                    h = this.node.y + this.distance / 2 * i.Grid_Height - i.Grid_Height / 2,
                    this.stop_x,
                    u = this.stop_y + this.distance / 2 * i.Grid_Height - i.Grid_Height / 2) : (this.node.x,
                    h = this.node.y + this.distance / 2 * i.Grid_Height,
                    this.stop_x,
                    u = this.stop_y + this.distance / 2 * i.Grid_Height);
                    for (var I = 0; I < this.distance; I++) {
                        var p = i.Max_Width / 2 + this.stop_x
                          , g = u - i.Grid_Height * I - i.Max_Height / 2
                          , z = parseInt(Math.abs(g) / i.Grid_Width)
                          , v = parseInt(p / i.Grid_Height);
                        e[z][v] = 0
                    }
                    for (var L = 0; L < this.distance; L++) {
                        var N = i.Max_Width / 2 + this.node.x
                          , M = h - i.Grid_Height * L - i.Max_Height / 2
                          , w = parseInt(Math.abs(M) / i.Grid_Width)
                          , C = parseInt(N / i.Grid_Height);
                        e[w][C] = 1
                    }
                }
            },
            registerAlterationHandle: function(e) {
                this.alteration_handle = e
            },
            create_VictoryUI: function() {
                o.AssMgr.createPrefabByName("victory", function(e) {
                    var n = cc.instantiate(e);
                    cc.director.getScene().addChild(n)
                })
            }
        }),
        cc._RF.pop()
    }
    , {
        "../../Config/StorgeInfo": "StorgeInfo",
        "../../Utils": "Utils"
    }],
    ExhibitionBar: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "28eecq1pLxOvqeAlKCggeUC", "ExhibitionBar"),
        cc.Class({
            extends: cc.Component,
            properties: {},
            onLoad: function() {
                var e = this.node.children;
                this.ImgList = [];
                for (var n = 0; n < e.length; n++)
                    this.ImgList.push(e[n].getComponent(cc.Sprite))
            },
            initialize: function(e) {
                for (var n = this, a = function(a) {
                    var o = "Platform/Textures/icon/gameIcon".concat(e[a]);
                    cc.loader.loadRes(o, cc.SpriteFrame, function(e, o) {
                        n.ImgList[a].spriteFrame = o
                    })
                }, o = 0; o < e.length; o++)
                    a(o)
            },
            start: function() {
                var e = 0
                  , n = this.node.children;
                (function a() {
                    cc.Tween.stopAllByTarget(n[e]);
                    var o = cc.tween().by(.2, {
                        position: cc.v2(0, 40)
                    })
                      , i = cc.tween().by(.2, {
                        position: cc.v2(0, -40)
                    });
                    cc.tween(n[e]).sequence(o, i).call(function() {
                        ++e > n.length - 1 && (e = 0),
                        a()
                    }).start()
                }
                )()
            },
            buttonTouchEventCallBack: function() {
                console.log("123123213123123213"),
                cc.PlatformUtils.executeShowMoreGames()
            }
        }),
        cc._RF.pop()
    }
    , {}],
    ExportNavigation: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "68f99zhhMtAL5qlPPcRhmjQ", "ExportNavigation");
        var o = e("../PlatformUtils")
          , i = e("../../../Scripts/Utils");
        cc.Class({
            extends: cc.Component,
            properties: {
                LandscapeNavigation: {
                    default: null,
                    type: cc.Node,
                    displayName: "横向导航"
                },
                VerticalNavigation: {
                    default: null,
                    type: cc.Node,
                    displayName: "纵向导航"
                }
            },
            onLoad: function() {},
            start: function() {
                this.LandscapeNavigation.getComponent("SlideEvent").instantiation(1, cc.size(122, 150)),
                this.VerticalNavigation.getComponent("SlideEvent").instantiation(2, cc.size(218, 268)),
                this.node.active = !1
            },
            doDisplay: function(e) {
                this.touchStatus = 0,
                this.node.active = !0,
                this.LandscapeNavigation.getComponent("SlideEvent").executeDisplay(),
                this.VerticalNavigation.getComponent("SlideEvent").executeDisplay(),
                this.handle = e
            },
            buttonTouchEventCallBack: function(e) {
                var n = this;
                i.MathMgr.getRandomNum(0, 100) < cc.PlatformUtils.RemoteConfig.randomFault ? 0 === this.touchStatus ? (this.touchStatus = -1,
                this.scheduleOnce(function() {
                    o.PlatformUtils.executeShowSystemBanner(),
                    n.scheduleOnce(function() {
                        n.touchStatus = 1,
                        cc.PlatformUtils.executeHideBanner()
                    }, 3)
                }, 1.5)) : 1 === this.touchStatus && (this.handle && this.handle(),
                this.node.active = !1) : (this.handle && this.handle(),
                this.node.active = !1)
            }
        }),
        cc._RF.pop()
    }
    , {
        "../../../Scripts/Utils": "Utils",
        "../PlatformUtils": "PlatformUtils"
    }],
    FengXiang: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "c9c12/bFtJIfJG088NVJZy3", "FengXiang");
        var o = e("../../TweenClass")
          , i = e("../../Utils");
        cc.Class({
            extends: cc.Component,
            properties: {
                closeBtn: {
                    default: null,
                    type: cc.Node,
                    displayName: "关闭按钮"
                },
                main: {
                    default: null,
                    type: cc.Node
                },
                fengXiang_btn: {
                    default: null,
                    type: cc.Node,
                    displayName: "分享按钮"
                },
                fengXiang_Img: {
                    default: null,
                    type: cc.Node,
                    displayName: "分享图"
                }
            },
            onLoad: function() {
                this.closeBtn.width = 25 * cc.PlatformUtils.RemoteConfig.scaleClose,
                this.closeBtn.height = 30 * cc.PlatformUtils.RemoteConfig.scaleClose,
                o.TweenClass.scale_3_1_Tween(this.node.children[1])
            },
            start: function() {},
            btnClick: function(e) {
                switch (i.SoundMgr.playEffect("button"),
                e.target.name) {
                case "fenxiangkuang":
                case "xuanyaoyixia":
                    cc.PlatformUtils.executeShare();
                    break;
                case "closeButton":
                    cc.PlatformUtils.executeRandomShare()
                }
                o.TweenClass.scale_close_Tween(this.node.children[1])
            }
        }),
        cc._RF.pop()
    }
    , {
        "../../TweenClass": "TweenClass",
        "../../Utils": "Utils"
    }],
    Hand_Prefab_Script: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "1f43e46ApxBAKtElJE4dMxF", "Hand_Prefab_Script"),
        cc.Class({
            extends: cc.Component,
            properties: {},
            onLoad: function() {
                cc.PlatformUtils.RemoteConfig.isShowHand || (this.node.active = !1)
            }
        }),
        cc._RF.pop()
    }
    , {}],
    JingBi: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "eff13HEJVtNuZyfU8gRGseH", "JingBi");
        var o = e("../Utils");
        cc.Class({
            extends: cc.Component,
            properties: {
                jb_Txt: {
                    default: null,
                    type: cc.Label,
                    displayName: "金币数量"
                }
            },
            onLoad: function() {
                var e = this;
                cc.setMoney = function() {
                    e.jb_Txt.string = cc.StorageInfo.sum_Money
                }
                ,
                cc.setMoney()
            },
            start: function() {},
            showBuyMoney: function() {
                o.SoundMgr.playEffect("button"),
                o.AssMgr.createPrefabByName("BuyMoney", function(e) {
                    var n = cc.instantiate(e);
                    cc.director.getScene().addChild(n)
                })
            }
        }),
        cc._RF.pop()
    }
    , {
        "../Utils": "Utils"
    }],
    LandscapeBanner: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "d513e4x36tJDZiRCZCRaxvV", "LandscapeBanner"),
        cc.Class({
            extends: cc.Component,
            properties: {
                MaskNode: {
                    default: null,
                    type: cc.Node,
                    displayName: "可视节点"
                },
                ItemContent: {
                    default: null,
                    type: cc.Node,
                    displayName: "单元容器"
                },
                ItemPrefab: {
                    default: null,
                    type: cc.Prefab,
                    displayName: "单元预制体"
                }
            },
            onLoad: function() {
                this.allowRoll = !1,
                this.rollDirection = 0,
                this.moveSpeed = 20,
                this.ItemContent.removeAllChildren(!0)
            },
            start: function() {
                this.ItemContent.getComponent(cc.Layout).updateLayout();
                var e = this.ItemContent.getContentSize().width
                  , n = this.MaskNode.getContentSize().width;
                this.minX = this.ItemContent.x,
                this.maxX = this.minX - (e - n),
                this.ItemContent.on(cc.Node.EventType.TOUCH_START, this.onTouchStart, this),
                this.ItemContent.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this),
                this.ItemContent.on(cc.Node.EventType.TOUCH_CANCEL, this.onTouchEnd, this),
                this.ItemContent.on(cc.Node.EventType.TOUCH_END, this.onTouchEnd, this),
                this.allowRoll = !0,
                this.node.active = !1
            },
            instantiation: function(e) {
                for (var n = 0; n < e.length; n++) {
                    var a = cc.instantiate(this.ItemPrefab);
                    this.ItemContent.addChild(a),
                    a.getComponent("SmallHotItem").instantiation(e[n])
                }
            },
            update: function(e) {
                if (this.allowRoll)
                    if (0 === this.rollDirection) {
                        if (this.ItemContent.x += this.moveSpeed * e,
                        this.ItemContent.x >= this.minX)
                            return this.ItemContent.x = this.minX,
                            void (this.rollDirection = 1)
                    } else if (1 === this.rollDirection && (this.ItemContent.x -= this.moveSpeed * e,
                    this.ItemContent.x <= this.maxX))
                        return this.ItemContent.x = this.maxX,
                        void (this.rollDirection = 0)
            },
            onTouchStart: function(e) {
                this.allowRoll = !1,
                this.firstTouchPoint = this.ItemContent.convertToNodeSpaceAR(e.getLocation())
            },
            onTouchMove: function(e) {
                if (!this.allowRoll) {
                    var n = e.getDelta().x;
                    this.ItemContent.x += n,
                    this.ItemContent.x >= this.minX && (this.ItemContent.x = this.minX),
                    this.ItemContent.x <= this.maxX && (this.ItemContent.x = this.maxX)
                }
            },
            onTouchEnd: function(e) {
                if (!this.allowRoll) {
                    this.allowRoll = !0;
                    var n = this.ItemContent.convertToNodeSpaceAR(e.getLocation());
                    if (this.firstTouchPoint.sub(n).mag() < 10) {
                        for (var a = this.ItemContent.children, o = 0; o < a.length; o++) {
                            var i = a[o];
                            if (i.getBoundingBox().contains(n)) {
                                var t = i.getComponent("SmallHotItem").detail.package;
                                window.swan.navigateToMiniProgram({
                                    appKey: t,
                                    path: "/path/page/0",
                                    extraData: {
                                        from: "快乐玻璃杯"
                                    },
                                    success: function() {},
                                    fail: function(e) {}
                                });
                                break
                            }
                        }
                        console.log("检测")
                    }
                }
            }
        }),
        cc._RF.pop()
    }
    , {}],
    LandscapeNavigation: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "d052aTSWhlIl4uZlPKc2ihC", "LandscapeNavigation"),
        cc.Class({
            extends: cc.Component,
            properties: {
                MaskNode: {
                    default: null,
                    type: cc.Node,
                    displayName: "可视节点"
                },
                ItemContent: {
                    default: null,
                    type: cc.Node,
                    displayName: "单元容器"
                },
                ItemPrefab: {
                    default: null,
                    type: cc.Prefab,
                    displayName: "单元预制体"
                }
            },
            onLoad: function() {
                if (cc.PlatformUtils.RemoteConfig.iconList.length <= 0)
                    this.node.active = !1;
                else {
                    this.isMeetRoll = !0,
                    this.allowRoll = !1,
                    this.rollDirection = 0,
                    this.moveSpeed = 20,
                    this.ItemContent.removeAllChildren(!0),
                    this.detailList = [];
                    for (var e = 0; e < cc.PlatformUtils.RemoteConfig.iconList.length; e++) {
                        var n = {
                            url: cc.PlatformUtils.RemoteConfig.iconList[e],
                            appId: cc.PlatformUtils.RemoteConfig.packageList[e]
                        };
                        this.detailList.push(n)
                    }
                    for (var a = 0; a < this.detailList.length; a++) {
                        var o = cc.instantiate(this.ItemPrefab);
                        this.ItemContent.addChild(o)
                    }
                }
            },
            start: function() {
                this.isMeetRoll = !1,
                this.node.active = !1
            },
            executeDisplay: function(e) {
                var n = this;
                this.detailList.sort(function() {
                    return .5 - Math.random()
                });
                for (var a = this.ItemContent.children, o = function(o) {
                    var i = a[o];
                    i.setContentSize(e),
                    i.index = o;
                    var t = i.getComponent(cc.Sprite);
                    cc.loader.load(n.detailList[o].url, function(e, n) {
                        t.spriteFrame = new cc.SpriteFrame(n)
                    })
                }, i = 0; i < a.length; i++)
                    o(i);
                this.ItemContent.x = -this.MaskNode.width / 2,
                this.allowRoll = !0,
                this.node.active = !0,
                this.ItemContent.getComponent(cc.Layout).updateLayout();
                var t = this.ItemContent.getContentSize().width
                  , r = this.MaskNode.getContentSize().width;
                t > r && (this.isMeetRoll = !0,
                this.ItemContent.on(cc.Node.EventType.TOUCH_START, this.onTouchStart, this),
                this.ItemContent.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this),
                this.ItemContent.on(cc.Node.EventType.TOUCH_CANCEL, this.onTouchEnd, this),
                this.ItemContent.on(cc.Node.EventType.TOUCH_END, this.onTouchEnd, this)),
                this.minX = this.ItemContent.x,
                this.maxX = this.minX - (t - r)
            },
            update: function(e) {
                if (this.isMeetRoll && this.allowRoll)
                    if (0 === this.rollDirection) {
                        if (this.ItemContent.x += this.moveSpeed * e,
                        this.ItemContent.x >= this.minX)
                            return this.ItemContent.x = this.minX,
                            void (this.rollDirection = 1)
                    } else if (1 === this.rollDirection && (this.ItemContent.x -= this.moveSpeed * e,
                    this.ItemContent.x <= this.maxX))
                        return this.ItemContent.x = this.maxX,
                        void (this.rollDirection = 0)
            },
            onTouchStart: function(e) {
                this.allowRoll = !1,
                this.firstTouchPoint = this.ItemContent.convertToNodeSpaceAR(e.getLocation())
            },
            onTouchMove: function(e) {
                if (!this.allowRoll) {
                    var n = e.getDelta().x;
                    this.ItemContent.x += n,
                    this.ItemContent.x >= this.minX && (this.ItemContent.x = this.minX),
                    this.ItemContent.x <= this.maxX && (this.ItemContent.x = this.maxX)
                }
            },
            onTouchEnd: function(e) {
                if (!this.allowRoll) {
                    this.allowRoll = !0;
                    var n = this.ItemContent.convertToNodeSpaceAR(e.getLocation());
                    if (this.firstTouchPoint.sub(n).mag() < 10) {
                        for (var a = this.ItemContent.children, o = 0; o < a.length; o++) {
                            var i = a[o];
                            if (i.getBoundingBox().contains(n)) {
                                var t = this.detailList[i.index].appId;
                                cc.PlatformUtils.executeNavigateToMiniProgram(t);
                                break
                            }
                        }
                        console.log("检测")
                    }
                }
            }
        }),
        cc._RF.pop()
    }
    , {}],
    LargeNavigation: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "93db4KXsf9MC6WlVNb95V+Z", "LargeNavigation");
        var o = e("../../../Scripts/Utils");
        cc.Class({
            extends: cc.Component,
            properties: {
                MaskNode: {
                    default: null,
                    type: cc.Node,
                    displayName: "可视节点"
                },
                ItemContent: {
                    default: null,
                    type: cc.Node,
                    displayName: "单元容器"
                },
                ItemPrefab: {
                    default: null,
                    type: cc.Prefab,
                    displayName: "单元预制体"
                }
            },
            onLoad: function() {
                cc.PlatformUtils.RemoteConfig.iconList.length <= 0 ? this.node.active = !1 : (this.isMeetRoll = !0,
                this.allowRoll = !1,
                this.rollDirection = 0,
                this.moveSpeed = 20,
                this.ItemContent.removeAllChildren(!0))
            },
            instantiation: function(e) {
                var n = this;
                this.detailList = e;
                for (var a = function(e) {
                    var a = cc.instantiate(n.ItemPrefab);
                    a.appId = n.detailList[e].appId,
                    n.ItemContent.addChild(a);
                    var o = a.getComponent(cc.Sprite);
                    cc.loader.load(n.detailList[e].url, function(e, n) {
                        e || (o.spriteFrame = new cc.SpriteFrame(n))
                    })
                }, o = 0; o < this.detailList.length; o++)
                    a(o);
                this.ItemContent.getComponent(cc.Layout).updateLayout()
            },
            start: function() {
                this.ItemContent.getComponent(cc.Layout).updateLayout();
                var e = this.ItemContent.getContentSize().height
                  , n = this.MaskNode.getContentSize().height;
                this.distance = 0,
                this.allowRoll = !1,
                this.isMeetRoll = !1,
                e > n && (this.isMeetRoll = !0,
                this.distance = e - n,
                this.allowRoll = !0,
                this.ItemContent.on(cc.Node.EventType.TOUCH_START, this.onTouchStart, this),
                this.ItemContent.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this),
                this.ItemContent.on(cc.Node.EventType.TOUCH_CANCEL, this.onTouchEnd, this),
                this.ItemContent.on(cc.Node.EventType.TOUCH_END, this.onTouchEnd, this)),
                this.node.active = !1
            },
            doDisplay: function(e) {
                this.node.active = !0;
                for (var n = this.ItemContent.children, a = 0; a < n.length; a++)
                    n[a].setContentSize(e);
                this.touchStatus = 0,
                this.ItemContent.y = 0,
                this.rollDirection = 0,
                this.ItemContent.getComponent(cc.Layout).updateLayout()
            },
            update: function(e) {
                if (this.isMeetRoll && this.allowRoll) {
                    var n = this.ItemContent.y;
                    if (0 === this.rollDirection) {
                        if ((n += this.moveSpeed * e) >= this.distance)
                            return this.ItemContent.y = this.distance,
                            void (this.rollDirection = 1);
                        this.ItemContent.y = n
                    } else {
                        if ((n -= this.moveSpeed * e) <= 0)
                            return this.ItemContent.y = 0,
                            void (this.rollDirection = 0);
                        this.ItemContent.y = n
                    }
                }
            },
            resetPlayPepleNumber: function() {
                for (var e = this.ItemContent.children, n = 0; n < e.length; n++)
                    e[n].getComponent("NormalHotItem").setPlayPepleNumber()
            },
            buttonTouchEventCallBack: function(e) {
                var n = this;
                o.MathMgr.getRandomNum(0, 100) < cc.PlatformUtils.RemoteConfig.randomFault ? 0 === this.touchStatus ? (this.touchStatus = -1,
                this.scheduleOnce(function() {
                    cc.PlatformUtils.executeShowSystemBanner(),
                    n.scheduleOnce(function() {
                        n.touchStatus = 1,
                        cc.PlatformUtils.executeHideBanner()
                    }, 3)
                }, 1.5)) : 1 === this.touchStatus && (cc.PlatformUtils.executeShowBanner(),
                this.node.active = !1) : (cc.PlatformUtils.executeShowBanner(),
                this.node.active = !1)
            },
            onTouchStart: function(e) {
                this.allowRoll = !1,
                this.firstTouchPoint = this.ItemContent.convertToNodeSpaceAR(e.getLocation())
            },
            onTouchMove: function(e) {
                if (!this.allowRoll) {
                    var n = e.getDelta().y;
                    this.ItemContent.y += n,
                    this.ItemContent.y >= this.distance && (this.ItemContent.y = this.distance),
                    this.ItemContent.y <= 0 && (this.ItemContent.y = 0)
                }
            },
            onTouchEnd: function(e) {
                if (!this.allowRoll) {
                    this.allowRoll = !0;
                    var n = this.ItemContent.convertToNodeSpaceAR(e.getLocation());
                    if (this.firstTouchPoint.sub(n).mag() < 10)
                        for (var a = this.ItemContent.children, o = 0; o < a.length; o++) {
                            var i = a[o];
                            if (i.getBoundingBox().contains(n)) {
                                cc.PlatformUtils.executeNavigateToMiniProgram(i.appId);
                                break
                            }
                        }
                }
            }
        }),
        cc._RF.pop()
    }
    , {
        "../../../Scripts/Utils": "Utils"
    }],
    LittleNavigation: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "da729lmjvBBOZBsVA0aHhYW", "LittleNavigation"),
        cc.Class({
            extends: cc.Component,
            properties: {
                ItemContent: {
                    default: null,
                    type: cc.Node,
                    displayName: "列表容器"
                }
            },
            instantiation: function() {
                this.detailList = [];
                for (var e = 0; e < cc.PlatformUtils.RemoteConfig.iconList.length; e++) {
                    var n = {
                        url: cc.PlatformUtils.RemoteConfig.iconList[e],
                        appId: cc.PlatformUtils.RemoteConfig.packageList[e]
                    };
                    this.detailList.push(n)
                }
                for (var a = this.ItemContent.children, o = 0; o < a.length; o++) {
                    a[o].appId = null,
                    a[o].getComponent(cc.Sprite).spriteFrame = null
                }
            },
            doDisplay: function() {
                this.executeRefreshDisplay(),
                this.schedule(this.executeRefreshDisplay, 5)
            },
            doHide: function() {
                this.unschedule(this.executeRefreshDisplay),
                this.node.active = !1
            },
            executeRefreshDisplay: function() {
                this.detailList.sort(function() {
                    return .5 - Math.random()
                });
                for (var e = this.ItemContent.children, n = this.detailList.slice(0, 4), a = function(a) {
                    var o = e[a];
                    o.appId = n[a].appId;
                    var i = o.getComponent(cc.Sprite);
                    cc.loader.load(n[a].url, function(e, n) {
                        i.spriteFrame = new cc.SpriteFrame(n)
                    })
                }, o = 0; o < n.length; o++)
                    a(o)
            },
            buttonTouchEventCallBack: function(e) {
                switch (e.target.name) {
                case "Item":
                    cc.PlatformUtils.executeNavigateToMiniProgram(e.target.appId)
                }
            }
        }),
        cc._RF.pop()
    }
    , {}],
    Load: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "1bb7bKdi/RCwJGb54JGt+YP", "Load");
        var o = e("../Utils")
          , i = e("../../resources/Platform/PlatformUtils")
          , t = e("../Config/StorgeInfo");
        window.is4399 = !0,
        cc.Class({
            extends: cc.Component,
            properties: {
                PlatformCode: {
                    default: i.PlatformList.无,
                    type: i.PlatformList,
                    displayName: "平台编码"
                },
                maskJinDuTiao: {
                    default: null,
                    type: cc.Node,
                    displayName: "mask进度条"
                },
                text: {
                    default: null,
                    type: cc.Label,
                    displayName: "进度文字"
                }
            },
            onLoad: function() {
                cc.PlatformUtils = new i.PlatformUtils(this.PlatformCode),
                this.ProgressCount = 0,
                this.MaxWidth = this.maskJinDuTiao.parent.width,
                this.maskJinDuTiao.width = 0,
                this.text.string = "0 %"
            },
            start: function() {
                var e = this;
                cc.PlatformUtils.requestLocation(function() {
                    console.log("远程配置:", cc.PlatformUtils.RemoteConfig),
                    cc.PlatformUtils.RemoteConfig.triggerLimit = cc.PlatformUtils.RemoteConfig.oppoBanner2,
                    cc.PlatformUtils.RemoteConfig.trigger = {},
                    cc.PlatformUtils.RemoteConfig.trigger.residue = cc.PlatformUtils.RemoteConfig.oppoBanner,
                    cc.PlatformUtils.RemoteConfig.default = cc.PlatformUtils.RemoteConfig.oppoBanner,
                    cc.PlatformUtils.instantiationPlatform(cc.PlatformUtils.RemoteConfig),
                    e.instantiationStorage()
                })
            },
            instantiationStorage: function() {
                var e = cc.sys.localStorage.getItem(i.App.storageName);
                e && "" !== e ? cc.StorageInfo = JSON.parse(e) : (cc.StorageInfo = t.StorgeInfo,
                cc.sys.localStorage.setItem(i.App.storageName, JSON.stringify(cc.StorageInfo))),
                this.loadSpriteFramePath()
            },
            loadSpriteFramePath: function() {
                var e = this;
                cc.loader.loadRes("App/Json/ImageList", cc.Asset, function(n, a) {
                    n || o.AssMgr.registerSpriteFramePath(a.json),
                    e.loadPrefabPath()
                })
            },
            loadPrefabPath: function() {
                var e = this;
                cc.loader.loadRes("App/Json/PrefabList", cc.Asset, function(n, a) {
                    n || o.AssMgr.registerPrefabPath(a.json),
                    e.loadTexturePath()
                })
            },
            loadTexturePath: function() {
                var e = this;
                cc.loader.loadRes("App/Json/TextureList", cc.Asset, function(n, a) {
                    n || o.AssMgr.registerTexturePath(a.json),
                    e.loadAudioPath()
                })
            },
            loadAudioPath: function() {
                var e = this;
                cc.loader.loadRes("App/Json/AudioList", cc.Asset, function(n, a) {
                    n || o.SoundMgr.registerSoundPath(a.json),
                    e.executeEnterNextScene()
                })
            },
            executeEnterNextScene: function() {
                var e = this;
                this.schedule(function() {
                    e.ProgressCount < 100 && (e.ProgressCount++,
                    e.text.string = "".concat(e.ProgressCount, " %"),
                    e.maskJinDuTiao.width = e.ProgressCount / 100 * e.MaxWidth),
                    99 === e.ProgressCount && cc.director.loadScene("Main")
                    if( e.ProgressCount  == 100){
                        console.log('加载完成');
                        window.parent.postMessage(
                            { func: "loadingCompleted" }
                        );
                    }
                }, .01, 99)
            }
        }),
        cc._RF.pop()
    }
    , {
        "../../resources/Platform/PlatformUtils": "PlatformUtils",
        "../Config/StorgeInfo": "StorgeInfo",
        "../Utils": "Utils"
    }],
    Main: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "1476fDrCxZOerNaG0B6hNEc", "Main");
        var o = e("../Utils");
        cc.Class({
            extends: cc.Component,
            properties: {
                timeLabel: {
                    default: null,
                    type: cc.Node,
                    displayName: "在线奖励"
                },
                ShortcutButton: {
                    default: null,
                    type: cc.Node,
                    displayName: "快捷桌面按钮"
                },
                MoreButton: {
                    default: null,
                    type: cc.Node,
                    displayName: "更多游戏按钮"
                }
            },
            onLoad: function() {
                o.SoundMgr.playMusic("BGM1"),
                void 0 != window.vivoUtil && vivoUtil.showMoreGame();
                this.MoreButton.active = false;
            },
            start: function() {
                var e = this;
                this.pd_isNowQianDao(),
                cc.PlatformUtils.setMoreButtonDisplayStatus(this.MoreButton),
                cc.PlatformUtils.setShortcutButtonDisplayStatus(this.ShortcutButton),
                window.uc && (this.ShortcutButton.active = !1);
                cc.PlatformUtils.isInstalledDesktopShortcut(function() {
                    e.ShortcutButton.active = !1
                }, function() {
                    e.ShortcutButton.active = !0
                })
            },
            click_btn: function(e) {
                switch (o.SoundMgr.playEffect("button"),
                e.target.name) {
                case "play":
                    cc.director.loadScene("model");
                    break;
                case "qiandao":
                    this.create_QianDao()
                }
            },
            onDestroy: function() {
                void 0 != window.vivoUtil && vivoUtil.closeBoxPortalAd()
            },
            pd_isNowQianDao: function() {
                var e = (new Date).getDate();
                0 === cc.StorageInfo.yiQianDaoList.length && (cc.StorageInfo.isSingIn = !0);
                for (var n = 0; n < cc.StorageInfo.yiQianDaoList.length; n++) {
                    var a = cc.StorageInfo.yiQianDaoList[n];
                    cc.StorageInfo.isSingIn = a !== e
                }
                cc.StorageInfo.isSingIn && this.create_QianDao()
            },
            create_QianDao: function() {
                o.AssMgr.createPrefabByName("QianDao", function(e) {
                    var n = cc.instantiate(e);
                    cc.director.getScene().addChild(n)
                })
            },
            doShortcut: function(e) {
                cc.PlatformUtils.executeDesktopShortcut(e.target)
            },
            doMore: function() {
                cc.PlatformUtils.executeHideBanner(),
                cc.PlatformUtils.executeShowMoreGames()
            }
        }),
        cc._RF.pop()
    }
    , {
        "../Utils": "Utils"
    }],
    MapItem: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "59256n2HvxOuqgye4nX+gZY", "MapItem");
        var o = e("./gameData")
          , i = e("../../Utils");
        cc.Class({
            extends: cc.Component,
            properties: {
                carContainer: {
                    default: null,
                    type: cc.Node,
                    displayName: "汽车容器"
                }
            },
            onLoad: function() {
                var e = this;
                this.Map_array = [[0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0]],
                cc.isStartGame = !1,
                cc.getMap = function() {
                    return e.Map_array
                }
                ,
                this.write_count = 0,
                this.touch_id = null,
                this.control_car = null
            },
            start: function() {
                var e = this;
                this.carInit(),
                cc.carInit = function() {
                    e.carInit()
                }
                ,
                this.node.on(cc.Node.EventType.TOUCH_START, this.onTouchStartEventCallBack, this),
                this.node.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMoveEventCallBack, this),
                this.node.on(cc.Node.EventType.TOUCH_END, this.onTouchEndEventCallBack, this),
                this.node.on(cc.Node.EventType.TOUCH_CANCEL, this.onTouchEndEventCallBack, this)
            },
            carInit: function() {
                var e = this;
                this.carContainer.removeAllChildren(),
                this.Map_array = [[0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0]],
                cc.isStartGame = !1;
                var n = cc.StorageInfo.Module[cc.StorageInfo.click_ModuleName].now_Leve - 1;
                cc.StorageInfo.click_Leve && (n = cc.StorageInfo.click_Leve - 1),
                console.log("level = ", n);
                var a = cc.StorageInfo.click_ModuleName.split("-")
                  , t = o.CarDataList["".concat(a[0], "-").concat(a[1])][n].start;
                i.AssMgr.createPrefabByName("car", function(n) {
                    for (var o = 0; o < t.length; o++) {
                        var i = t[o]
                          , r = i.frameName.split("-");
                        r = "".concat(r[0], "-").concat(a[1], "-").concat(r[2]);
                        var c = i.location
                          , d = i.isMain
                          , s = i.isLandscape
                          , l = i.distance
                          , x = i.angle
                          , m = i.orderIndex;
                        console.log(l),
                        e.write_count += l;
                        var f = cc.instantiate(n);
                        f.orderIndex = m,
                        f.children[0].opacity = 0,
                        f.id = o,
                        f.angle = x,
                        f.position = cc.v2(c.x, c.y),
                        e.carContainer.addChild(f);
                        var y = f.getComponent("CarItem");
                        y.initialize(r, d, s, l, e.executeAlterationMapData.bind(e)),
                        y.init()
                    }
                })
            },
            executeAlterationMapData: function(e, n, a) {
                this.Map_array[e][n] = 1,
                console.log(this.Map_array),
                this.write_count--,
                this.write_count <= 0 && this.executeCalculateMoveDistance()
            },
            executeCalculateMoveDistance: function() {
                for (var e = this.carContainer.children, n = 0; n < e.length; n++)
                    e[n].getComponent("CarItem").calculateMoveDistance(this.Map_array)
            },
            onTouchStartEventCallBack: function(e) {
                if (i.SoundMgr.playEffect("huadong"),
                !this.touch_id) {
                    this.touch_id || (this.touch_id = e.getID());
                    for (var n = e.getLocation(), a = this.carContainer.children, o = 0; o < a.length; o++) {
                        if (a[o].getBoundingBoxToWorld().contains(n)) {
                            var t = !0;
                            if (cc.car_id ? cc.car_id === a[o].orderIndex ? this.control_car = a[o] : t = !1 : this.control_car = a[o],
                            console.log(this.control_car),
                            t) {
                                var r = {
                                    index: this.control_car.id,
                                    position: this.control_car.position
                                };
                                cc.recordPosition.push(r)
                            }
                            cc.isStartGame = !0;
                            break
                        }
                    }
                }
            },
            onTouchMoveEventCallBack: function(e) {
                if (this.control_car && e.getID() === this.touch_id) {
                    var n = e.getDelta();
                    if (this.control_car.is_landscape) {
                        var a = this.control_car.position;
                        a.x += n.x,
                        a.x + this.control_car.width / 2 >= this.control_car.right_distance && (a.x = this.control_car.right_distance - this.control_car.width / 2),
                        a.x - this.control_car.width / 2 <= this.control_car.left_distance && (a.x = this.control_car.left_distance + this.control_car.width / 2),
                        this.control_car.x = a.x
                    } else {
                        var o = this.control_car.position;
                        o.y += n.y,
                        o.y >= this.control_car.top_distance && (o.y = this.control_car.top_distance),
                        o.y <= this.control_car.down_distance && (o.y = this.control_car.down_distance),
                        this.control_car.y = o.y
                    }
                }
            },
            onTouchEndEventCallBack: function(e) {
                this.control_car && (e.getID() === this.touch_id && (this.control_car.getComponent("CarItem").executeStop(this.Map_array),
                this.executeCalculateMoveDistance(),
                this.touch_id = null,
                this.control_car = null))
            }
        }),
        cc._RF.pop()
    }
    , {
        "../../Utils": "Utils",
        "./gameData": "gameData"
    }],
    Model: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "95caeqRLE9JzJqKAowMypUu", "Model");
        var o = e("../Utils");
        cc.Class({
            extends: cc.Component,
            properties: {
                model_content: {
                    default: null,
                    type: cc.Node,
                    displayName: "模式容器"
                }
            },
            onLoad: function() {
                this.model_init()
            },
            start: function() {
                cc.PlatformUtils.executeShowBanner(cc.v2(cc.view.getVisibleSize().width / 2, cc.view.getVisibleSize().height), cc.v2(.5, 0)),
                cc.PlatformUtils.executeShowInterstitial(!0)
            },
            clcik_Button: function(e) {
                switch (o.SoundMgr.playEffect("button"),
                e.target.name) {
                case "fanhui":
                    cc.director.loadScene("Main")
                }
            },
            model_init: function() {
                var e = this;
                this.model_content.removeAllChildren();
                o.AssMgr.createPrefabByName("model", function(n) {
                    for (var a = 0; a < 4; a++) {
                        var o = cc.instantiate(n);
                        e.model_content.addChild(o),
                        o.getComponent("modelItem").updateModel(a + 1)
                    }
                })
            }
        }),
        cc._RF.pop()
    }
    , {
        "../Utils": "Utils"
    }],
    MutuallyItem: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "f04a9uQa4RAfobf+bPJOn3W", "MutuallyItem");
        var o = e("../../../Scripts/Utils");
        cc.Class({
            extends: cc.Component,
            properties: {
                Img: {
                    default: null,
                    type: cc.Sprite,
                    displayName: "显示图"
                }
            },
            onLoad: function() {
                !cc.PlatformUtils.RemoteConfig.isLine || cc.PlatformUtils.RemoteConfig.iconList.length <= 0 ? this.node.active = !1 : (this.displayIndex = o.MathMgr.getRandomNum(0, cc.PlatformUtils.RemoteConfig.iconList.length - 1),
                this.Img.spriteFrame = null)
            },
            start: function() {
                var e = this;
                this.changeDisplayInformation(),
                this.schedule(function() {
                    e.changeDisplayInformation()
                }, 3)
            },
            changeDisplayInformation: function() {
                var e = this;
                this.displayIndex++,
                this.displayIndex >= cc.PlatformUtils.RemoteConfig.iconList.length && (this.displayIndex = 0),
                cc.loader.load(cc.PlatformUtils.RemoteConfig.iconList[this.displayIndex], function(n, a) {
                    n || (e.Img.spriteFrame = new cc.SpriteFrame(a))
                })
            },
            touchEventCallBack: function(e) {
                var n = cc.PlatformUtils.RemoteConfig.packageList[this.displayIndex];
                cc.PlatformUtils.executeNavigateToMiniProgram(n)
            }
        }),
        cc._RF.pop()
    }
    , {
        "../../../Scripts/Utils": "Utils"
    }],
    NativeBanner: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "617f0bBF/BH7493Vhd5SmNQ", "NativeBanner"),
        cc.Class({
            extends: cc.Component,
            properties: {
                NativeImg: {
                    default: null,
                    type: cc.Sprite,
                    displayName: "底图"
                },
                CloseButton: {
                    default: null,
                    type: cc.Sprite,
                    displayName: "关闭按钮"
                }
            },
            onLoad: function() {
                this.CloseButton.width = 38 * cc.PlatformUtils.RemoteConfig.scaleClose,
                this.CloseButton.height = 38 * cc.PlatformUtils.RemoteConfig.scaleClose
            },
            initialize: function(e, n, a) {
                var o = this;
                this.touch_handle = n,
                this.close_handle = a,
                cc.loader.load(e, function(e, n) {
                    e ? o.node.removeFromParent(!0) : o.NativeImg.spriteFrame = new cc.SpriteFrame(n)
                })
            },
            executeClose: function() {
                this.close_handle && this.close_handle()
            },
            executeTouch: function() {
                this.touch_handle && this.touch_handle()
            },
            buttonTouchEventCallBack: function(e) {
                switch (e.target.name) {
                case "NativeBanner":
                    this.executeTouch();
                    break;
                case "closeButton":
                    this.executeClose()
                }
            }
        }),
        cc._RF.pop()
    }
    , {}],
    NativeInterstitial: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "4094e9Xz+9E0YZnXqbz8/I9", "NativeInterstitial"),
        cc.Class({
            extends: cc.Component,
            properties: {
                NativeImg: {
                    default: null,
                    type: cc.Sprite,
                    displayName: "原生图"
                },
                CloseButton: {
                    default: null,
                    type: cc.Node,
                    displayName: "关闭按钮"
                }
            },
            onLoad: function() {
                this.CloseButton.width = 38 * cc.PlatformUtils.RemoteConfig.scaleClose,
                this.CloseButton.height = 38 * cc.PlatformUtils.RemoteConfig.scaleClose
            },
            initialize: function(e, n, a) {
                var o = this;
                console.error("初始化原生插屏"),
                this.touch_handle = n,
                this.close_handle = a,
                cc.loader.load(e, function(e, n) {
                    e ? o.node.removeFromParent(!0) : o.NativeImg.spriteFrame = new cc.SpriteFrame(n)
                })
            },
            executeClose: function() {
                this.close_handle && this.close_handle()
            },
            executeTouch: function() {
                this.touch_handle && this.touch_handle()
            },
            buttonTouchEventCallBack: function(e) {
                switch (e.target.name) {
                case "closeButton":
                    this.executeClose();
                    break;
                case "nativeButton":
                case "window":
                    this.executeTouch()
                }
            }
        }),
        cc._RF.pop()
    }
    , {}],
    NormalBanner: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "182422cBENDtrp6cxZZGlpg", "NormalBanner"),
        cc.Class({
            extends: cc.Component,
            properties: {
                Img: {
                    default: null,
                    type: cc.Sprite,
                    displayName: "底图"
                }
            },
            onLoad: function() {
                this.nativeInstance = null,
                this.node.active = !1
            },
            executeRefresh: function(e, n, a) {
                var o = this;
                console.log("显示Banner"),
                this.nativeInstance = e,
                this.imgPath = n,
                this.code = a,
                cc.loader.load({
                    url: n,
                    type: "jpg"
                }, function(e, n) {
                    e && console.log("加载图片发生错误"),
                    o.Img.spriteFrame = new cc.SpriteFrame(n),
                    o.node.active = !0
                }),
                this.nativeInstance.reportAdShow({
                    adId: this.code
                })
            },
            executeDisplay: function() {
                this.nativeInstance ? this.node.active = !0 : this.node.active = !1
            },
            getNativeInformation: function() {
                return {
                    nativeInstance: this.nativeInstance,
                    imgPath: this.imgPath,
                    code: this.code
                }
            },
            executeTouch: function() {
                this.nativeInstance && this.nativeInstance.reportAdClick({
                    adId: this.code
                })
            },
            buttonTouchEventCallBack: function(e) {
                switch (e.target.name) {
                case "NormalBanner":
                    this.executeTouch();
                    break;
                case "closeButton":
                    this.node.active = !1
                }
            }
        }),
        cc._RF.pop()
    }
    , {}],
    NormalHotItem: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "ccb94REM7ZCA6Wkj0CjEhkA", "NormalHotItem"),
        cc.Class({
            extends: cc.Component,
            properties: {
                Img: {
                    default: null,
                    type: cc.Sprite,
                    displayName: "游戏图标"
                },
                OnLineLabel: {
                    default: null,
                    type: cc.Label,
                    displayName: "在线人数"
                },
                HotNode: {
                    default: null,
                    type: cc.Node,
                    displayName: "Hot图标"
                }
            },
            start: function() {
                var e = cc.tween().to(.6, {
                    scale: 1.5
                }).to(.6, {
                    scale: 1
                });
                cc.tween(this.HotNode).repeatForever(e).start()
            },
            instantiation: function(e) {
                var n = this;
                this.detail = e,
                cc.loader.load(e.url, function(e, a) {
                    n.Img.spriteFrame = new cc.SpriteFrame(a)
                })
            },
            setPlayPepleNumber: function() {
                var e = function(e, n) {
                    var a = n - e
                      , o = Math.random();
                    return e + Math.round(o * a)
                };
                this.OnLineLabel.string = "".concat(e(3, 6), ".").concat(e(5, 9), "W人在玩")
            }
        }),
        cc._RF.pop()
    }
    , {}],
    NormalNavigation: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "af550MInMRAO58tArHgUL3y", "NormalNavigation"),
        cc.Class({
            extends: cc.Component,
            properties: {
                ItemContent: {
                    default: null,
                    type: cc.Node,
                    displayName: "列表容器"
                },
                CloseButton: {
                    default: null,
                    type: cc.Node,
                    displayName: "关闭按钮"
                }
            },
            onLoad: function() {
                this.detailList = [];
                for (var e = 0; e < cc.PlatformUtils.RemoteConfig.iconList.length; e++) {
                    var n = {
                        url: cc.PlatformUtils.RemoteConfig.iconList[e],
                        appId: cc.PlatformUtils.RemoteConfig.packageList[e]
                    };
                    this.detailList.push(n)
                }
                for (var a = this.ItemContent.children, o = 0; o < a.length; o++) {
                    a[o].appId = null,
                    a[o].getComponent(cc.Sprite).spriteFrame = null
                }
            },
            start: function() {
                this.node.active = !1
            },
            doDisplay: function() {
                var e = this;
                cc.PlatformUtils.RemoteConfig.isLine ? (this.CloseButton.active = !1,
                cc.tween(this.CloseButton).delay(3).call(function() {
                    e.CloseButton.active = !0
                }).start()) : this.CloseButton.active = !0,
                this.executeRefreshDisplay()
            },
            executeRefreshDisplay: function() {
                this.detailList.sort(function() {
                    return .5 - Math.random()
                });
                for (var e = this.ItemContent.children, n = this.detailList.slice(0, 9), a = function(a) {
                    var o = e[a];
                    o.appId = n[a].appId;
                    var i = o.getComponent(cc.Sprite);
                    cc.loader.load(n[a].url, function(e, n) {
                        i.spriteFrame = new cc.SpriteFrame(n)
                    })
                }, o = 0; o < n.length; o++)
                    a(o);
                this.node.active || (this.node.active = !0,
                this.schedule(this.executeRefreshDisplay, 5))
            },
            executeCloseWindow: function() {
                this.unschedule(this.executeRefreshDisplay),
                this.node.active = !1
            },
            buttonTouchEventCallBack: function(e) {
                switch (e.target.name) {
                case "closeButton":
                    this.executeCloseWindow();
                    break;
                case "Item":
                    cc.PlatformUtils.executeNavigateToMiniProgram(e.target.appId)
                }
            }
        }),
        cc._RF.pop()
    }
    , {}],
    OnlineRewards: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "52c20l3o9xDeojcdBBV4/mu", "OnlineRewards");
        var o = e("../Utils")
          , i = e("../TweenClass");
        cc.Class({
            extends: cc.Component,
            properties: {},
            onLoad: function() {
                var e = this;
                if (cc.onLineInfo.isFinal)
                    this.node.active = !1;
                else {
                    this.timeLabel = this.node.getChildByName("timeLabel").getComponent(cc.Label),
                    this.lqlibao = this.node.getChildByName("lq"),
                    this.guang = this.node.getChildByName("guang"),
                    this.baoxiang = this.node.getChildByName("baoxiang"),
                    i.TweenClass.scale_Tween(this.baoxiang),
                    this.guang.active = !1;
                    var n = cc.onLineInfo.data[cc.onLineInfo.step];
                    1 === n.receiveStatus ? (this.timeLabel.node.active = !0,
                    this.timeLabel.string = this.formatSeconds(cc.onLineInfo.data[cc.onLineInfo.step].time),
                    this.lqlibao.active = !1,
                    this.guang.active = !1,
                    o.AssMgr.setSpriteFrameByName(this.baoxiang.getComponent(cc.Sprite), "baoxiang")) : 2 === n.receiveStatus && (this.allow_time = !1,
                    this.timeLabel.node.active = !1,
                    this.lqlibao.active = !0,
                    this.guang.active = !0,
                    o.AssMgr.setSpriteFrameByName(this.baoxiang.getComponent(cc.Sprite), "jinbixiang")),
                    cc.create_JiangLi = function(n) {
                        e.create_JiangLi(n)
                    }
                }
            },
            start: function() {},
            update: function(e) {
                this.guang.angle++;
                var n = cc.onLineInfo.data[cc.onLineInfo.step];
                n.isFinal || (1 === n.receiveStatus ? (this.timeLabel.node.active = !0,
                this.timeLabel.string = this.formatSeconds(cc.onLineInfo.data[cc.onLineInfo.step].time),
                this.lqlibao.active = !1,
                this.guang.active = !1,
                o.AssMgr.setSpriteFrameByName(this.baoxiang.getComponent(cc.Sprite), "baoxiang")) : 2 === n.receiveStatus && (this.allow_time = !1,
                this.timeLabel.node.active = !1,
                this.lqlibao.active = !0,
                this.guang.active = !0,
                o.AssMgr.setSpriteFrameByName(this.baoxiang.getComponent(cc.Sprite), "jinbixiang")))
            },
            getGiftBag: function() {
                if (o.SoundMgr.playEffect("button"),
                2 === cc.onLineInfo.data[cc.onLineInfo.step].receiveStatus) {
                    if (this.create_JiangLi(cc.onLineInfo.data[cc.onLineInfo.step].money),
                    cc.onLineInfo.data[cc.onLineInfo.step].receiveStatus = 3,
                    cc.onLineInfo.step++,
                    cc.onLineInfo.step >= cc.onLineInfo.data.length)
                        return cc.onLineInfo.isFinal = !0,
                        void (this.node.active = !1);
                    cc.onLineInfo.data[cc.onLineInfo.step].receiveStatus = 1,
                    this.timeLabel.string = this.formatSeconds(cc.onLineInfo.data[cc.onLineInfo.step].time),
                    this.timeLabel.node.active = !0,
                    this.lqlibao.active = !1
                }
            },
            create_JiangLi: function(e) {
                o.AssMgr.createPrefabByName("jianglI", function(n) {
                    var a = cc.instantiate(n);
                    a.getComponent("jianglIItem").setJiangLi_Count(e),
                    cc.director.getScene().addChild(a)
                })
            },
            formatSeconds: function(e) {
                var n = parseInt(e)
                  , a = 0;
                n >= 60 && (a = parseInt(n / 60),
                n = parseInt(n % 60),
                a >= 60 && (parseInt(a / 60),
                a = parseInt(a % 60))),
                n < 10 && (n = "0" + parseInt(n));
                var o = "" + n;
                return a >= 0 && (a < 10 && (a = "0" + parseInt(a)),
                o = a + "/" + o),
                o
            }
        }),
        cc._RF.pop()
    }
    , {
        "../TweenClass": "TweenClass",
        "../Utils": "Utils"
    }],
    PlatformUtils: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "f7cc0gGtoVJIYuITYhWh6E1", "PlatformUtils"),
        Object.defineProperty(a, "__esModule", {
            value: !0
        }),
        a.PlatformUtils = a.App = a.PlatformList = void 0;
        var o, i = e("./_bytedance"), t = e("./_baidu"), r = (e("./_oppo"),
        e("./_wechat")), c = (e("./_tencent"),
        e("./_UC")), d = e("./_huawei"), s = e("./_4399"), l = e("../../Scripts/Utils"), x = e("./QQUtil");
        function m(e, n) {
            if (!(e instanceof n))
                throw new TypeError("Cannot call a class as a function")
        }
        function f(e, n) {
            for (var a = 0; a < n.length; a++) {
                var o = n[a];
                o.enumerable = o.enumerable || !1,
                o.configurable = !0,
                "value"in o && (o.writable = !0),
                Object.defineProperty(e, o.key, o)
            }
        }
        function y(e, n, a) {
            return n && f(e.prototype, n),
            a && f(e, a),
            e
        }
        function h(e, n, a) {
            return n in e ? Object.defineProperty(e, n, {
                value: a,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : e[n] = a,
            e
        }
        var u = cc.Enum({
            "无": 1,
            "头条": 2,
            "百度": 3,
            OPPO: 4,
            "微信": 5,
            QQ: 6,
            UC: 7,
            "华为": 8,
            "游家": 9
        });
        a.PlatformList = u;
        var I = {
            isLine: !1,
            allowInstall: !1,
            allowBanner: !1,
            allowInterstitial: !1,
            allowShowModal: !1,
            randomStartVideo: 0,
            randomCheckBox: 0,
            randomDelay: 0,
            randomFault: 0,
            randomVideo: 0,
            randomShare: 0,
            randomTry: 101,
            randomPush: 0,
            scaleClose: 1,
            isShowHand: !1,
            bannerInterval: 60,
            oppoBanner: 3,
            oppoBanner2: 3,
            closeScale: 1,
            randomNative: 100,
            systemRandom: 30,
            gridRandom: 100,
            wx_VideoCode: "",
            wx_BannerCode: "",
            wx_InterstitialCode: "",
            wx_GridCode: "",
            bgm: [],
            locationList: ["440300"],
            iconList: [],
            packageList: []
        };
        window.GameConfig = (h(o = {
            open1fz: !1,
            closeBtnScale: 1,
            sendDesk: !1,
            quitShow: 0,
            showChapingCiShu: 0,
            openBox: 0,
            randomSplshvideo: 0,
            randomShowvideo: 0,
            showbanner: !1,
            showChaping: !1,
            showhand: !1,
            isLine: !1,
            startVideo: !1,
            allowBanner: !1,
            randomVideo: 0,
            allowInterstitial: !1,
            randomShare: 0,
            faultBanner: 0,
            randomPush: 0,
            showModal: !1,
            randomCheckBox: 0,
            bannerShowTime: 0,
            tryPush: 0,
            locationList: [],
            showHutui: !1,
            TouShiLevel: !1,
            closebtnYC: !1,
            SceneID: [],
            kaiping: 0,
            winVideo: 0,
            showBlock: !1,
            randomkaiping: 0,
            randomLoadCaiQian: 0,
            showguanzhu: !1,
            ShowPopCp: 0,
            randomChaping: 0,
            ShowInGameCp: 0,
            randomSendDesk: 0,
            ShowJieSuanCp: 0,
            quitshow: 0
        }, "showModal", !1),
        h(o, "ShowTuiSongCiShu", 0),
        h(o, "Time180sAD", !1),
        o);
        a.App = {
            appName: "TingCheMoNiQi",
            storageName: "Uptap_MoveTheCar_tcmnq_2021827132537",
            ChineseName: "停车模拟器",
            ShareLanguage: "停车模拟器!"
        };
        var p = {
            version: "100",
            appId: "tt38c04e7da7f873a702",
            bannerCode: "je7f0q18eb3opqkd4b",
            interstitialCode: "2la5hh0bi23741ev2o",
            videoCode: "2ipmb8c7on71mnaiba"
        }
          , g = {
            version: "100",
            appId: "24029085",
            appSID: "fadb0949",
            videoCode: "7495483"
        }
          , z = {
            version: "100",
            appId: "wx009ea6f129f91d04"
        }
          , v = {
            version: "100",
            appId: "1111687485",
            bannerCode: "40120c96559e56b298e0a982f38f96d3",
            videoCode: "48efe0181ff328ebe32b5424f6f9c814",
            boxCode: "3223f87c77ec063e83eaba0ae6d03496",
            interstitialCode: "9bf8b387991bbcf98837efa11c819460",
            blockCode: "6692dd2ef0a6c5bae15dc18b20a35ad6"
        }
          , L = {
            version: "100"
        }
          , N = {
            version: "100"
        }
          , M = {
            version: "100"
        }
          , w = function() {
            function e(n) {
                m(this, e),
                this.Platform = null,
                this.isTriggerStartVideo = !1,
                this.PlatformCode = u.无,
                this.RemoteURL = "",
                this.RemoteConfig = I,
                this.Platform = null,
                this.isTriggerStartVideo = !1,
                this.PlatformCode = n,
                this.PlatformCode,
                console.log("初始化平台脚本成功, 当前平台编号为:".concat(Object.keys(u)[this.PlatformCode - 1]))
            }
            return y(e, [{
                key: "instantiationPlatform",
                value: function(e) {
                    switch (this.RemoteConfig = e,
                    console.log("初始化平台"),
                    this.PlatformCode) {
                    case u.头条:
                        this.Platform = new i.bytedance(e,p);
                        break;
                    case u.百度:
                        this.Platform = new t.baidu(e,g);
                        break;
                    case u.OPPO:
                        break;
                    case u.微信:
                        this.Platform = new r.wechat(e,z);
                        break;
                    case u.QQ:
                        this.Platform = new x.QQUtil(e,v);
                        break;
                    case u.UC:
                        this.Platform = new c._UC(e,L);
                        break;
                    case u.华为:
                        this.Platform = new d.huawei(e,N);
                        break;
                    case u.游家:
                        this.Platform = new s.youjia(e,M)
                    }
                    this.InitSDK()
                }
            }, {
                key: "requestLocation",
                value: function(e) {
                    var n = this;
                    if (console.log("读取所在区域信息" + this.PlatformCode),
                    this.PlatformCode === u.无 || this.platformCode == u.UC)
                        return console.log("无平台信息"),
                        void this.loadSubpackageInformation(e);
                    if (this.PlatformCode === u.头条 || this.PlatformCode === u.百度 || this.PlatformCode === u.微信 || this.PlatformCode === u.QQ) {
                        var a = null;
                        if (this.PlatformCode === u.头条) {
                            if ("ios" === window.tt.getSystemInfoSync().platform)
                                return void this.requestRemoteConfig(null, e);
                            a = tt.request
                        } else if (this.PlatformCode === u.百度) {
                            if (a = swan.request,
                            "ios" === window.swan.getSystemInfoSync().system.substr(0, 3).toLocaleLowerCase())
                                return void (e && e())
                        } else
                            this.PlatformCode === u.微信 ? a = wx.request : this.PlatformCode === u.QQ && (console.log("进入QQ"),
                            a = qq.request);
                        console.log("request:" + a),
                        a({
                            url: URL,
                            data: {},
                            header: {
                                "content-type": "application/json"
                            },
                            success: function(a) {
                                if (-1 != a) {
                                    console.log("读取所在地信息成功:", a.data);
                                    var o = a.data.cityCode + "," + a.data.proCode;
                                    n.requestRemoteConfig(o, e)
                                } else
                                    console.warn("读取所在地信息异常!"),
                                    n.loadSubpackageInformation(e)
                            },
                            fail: function(a) {
                                console.error("读取所在地信息失败:", JSON.stringify(a)),
                                n.loadSubpackageInformation(e)
                            }
                        })
                    } else {
                       
                    }
                }
            }, {
                key: "requestRemoteConfig",
                value: function(e, n) {
                    var a = this
                      , o = function(n) {
                        for (var a = 0; a < n.length; a++)
                            if (-1 != e.indexOf(n[a]))
                                return !0;
                        return !1
                    };
                    if (console.log("读取服务器配置信息"),
                    this.PlatformCode === u.头条 || this.PlatformCode === u.百度 || this.PlatformCode === u.微信 || this.PlatformCode === u.QQ) {
                        var i = null;
                        this.PlatformCode === u.头条 ? i = tt.request : this.PlatformCode === u.百度 ? i = swan.request : this.PlatformCode === u.微信 ? i = wx.request : this.PlatformCode === u.QQ && (i = qq.request),
                        console.log("----------------------"),
                        i({
                            url: this.RemoteURL,
                            data: {},
                            header: {
                                "content-type": "application/json"
                            },
                            success: function(e) {
                                if (console.log("读取配置信息成功:", e.data),
                                a.PlatformCode === u.头条) {
                                    if ("ios" !== tt.getSystemInfoSync().platform && o(e.data.locationList))
                                        return console.log("处于被过滤地域, 按默认配置处理!!"),
                                        void a.loadSubpackageInformation(n)
                                } else if (o(e.data.locationList))
                                    return console.log("处于被过滤地域, 按默认配置处理!!"),
                                    void a.loadSubpackageInformation(n);
                                console.log("读取远程配置信息成功:", e),
                                a.RemoteConfig = e.data,
                                window.GameConfig = e.data,
                                a.loadSubpackageInformation(n)
                            },
                            fail: function(e) {
                                console.error("读取远程配置信息失败:", JSON.stringify(e)),
                                a.loadSubpackageInformation(n)
                            }
                        })
                    } else {
                       
                    }
                }
            }, {
                key: "loadSubpackageInformation",
                value: function(e) {
                    console.log("加载分包资源");
                    var n = null;
                    switch (this.PlatformCode) {
                    case u.头条:
                        break;
                    case u.百度:
                        n = window.swan;
                        break;
                    case u.OPPO:
                        n = window.qg;
                        break;
                    case u.微信:
                        n = window.wx;
                        break;
                    case u.QQ:
                        n = window.qq;
                        break;
                    case u.UC:
                    case u.华为:
                    case u.游家:
                    }
                    if (n && n.loadSubpackage) {
                        window.qg || n.showLoading({
                            title: "加载分包数据,请稍等!",
                            mask: !0,
                            success: function() {
                                return console.log("loading 提示框显示成功")
                            }
                        });
                        var a = function(e, a) {
                            console.log("当前加载分包包名:", e),
                            n.loadSubpackage({
                                name: e,
                                success: function(e) {
                                    a()
                                },
                                fail: function(e) {}
                            }).onProgressUpdate(function(e) {})
                        };
                        (function(e, n) {
                            var o = 0;
                            a(e[o], function i() {
                                ++o >= e.length ? n() : a(e[o], i)
                            })
                        }
                        )(["bao1", "bao2", "bao3", "bao4", "bao5"], function() {
                            n.hideLoading(),
                            e && e()
                        })
                    } else
                        e && e()
                }
            }, {
                key: "InitSDK",
                value: function() {
                }
            }, {
                key: "setMoreButtonDisplayStatus",
                value: function(e) {}
            }, {
                key: "setShortcutButtonDisplayStatus",
                value: function(e) {
                    this.PlatformCode !== u.OPPO && this.PlatformCode !== u.QQ ? e.active = !1 : e.active = !0
                }
            }, {
                key: "setShareButtonDisplayStatus",
                value: function(e) {
                    this.PlatformCode !== u.头条 && this.PlatformCode !== u.微信 && this.PlatformCode !== u.QQ ? e.active = !1 : e.active = !0
                }
            }, {
                key: "executeShowStartVideo",
                value: function() {
                    this.Platform && this.RemoteConfig.isLine && !this.isTriggerStartVideo && (this.isTriggerStartVideo = !0,
                    l.MathMgr.getRandomNum(0, 100) < this.RemoteConfig.randomStartVideo && this.executeShowVideo(null, null))
                }
            }, {
                key: "executeShowVideo",
                value: function(e, n) {
                    // window.is4399 ? window.h5api.canPlayAd(function(a) {
                    //     // console.log("是否可播放广告", a.canPlayAd, "剩余次数", a.remain),
                    //     // window.h5api.playAd(function(a) {
                    //     //     console.log("代码:" + a.code + ",消息:" + a.message),
                    //     //     1e4 === a.code ? (cc.director.pause(),
                    //     //     console.log("开始播放")) : 10001 === a.code ? (console.log("播放结束"),
                    //     //     cc.director.resume(),
                    //     //     e && e()) : (console.log("广告异常"),
                    //     //     cc.director.resume(),
                    //     //     n && n())
                    //     // })
                    // }) : (console.log("触发激励视频"),
                    // null != TouTiaoTools && window.tt ? TouTiaoTools.getVideoAd(e, n) : null == oppoUtil || cc.sys.platform !== cc.sys.OPPO_GAME ? (console.log("执行了这个？"),
                    // void 0 == window.vivoUtil ? this.Platform ? this.Platform.executeShowAwardVideo && this.Platform.executeShowAwardVideo(e, n) : e && e() : vivoUtil.getVideoAd(e, n)) : oppoUtil.getVideoAd(e, n))
                    console.log("视频================")
                    window['uptap'].ShowExcitationVideoAdv((n1) =>
                        {
                            switch (n1.type) 
                            {
                                case "1":
                                //暂时没有广告
                                console.log("暂时没有广告");
                                n && n();
                                    break;
                                case "2":
                                //想要奖励，必须看完广告（用户点击跳过按钮）
                                console.log("必须看完整视频才能获得奖励哦！");
                                n && n();
                                    break;
                                case "3":
                                    //广告正常播放完毕
                                    cc.director.resume(),e&&e();
                                break;
                            }
                        })	

                }
            }, {
                key: "executeShowBanner",
                value: function(e, n) {
                    cc.sys.platform !== cc.sys.ANDROID ? (void 0 != window.vivoUtil && vivoUtil.showAd_Banner(),
                    cc.sys.platform === cc.sys.OPPO_GAME && null != oppoUtil && oppoUtil.showAd_Banner(),
                    null != TouTiaoTools && window.tt ? TouTiaoTools.showBanner() : this.Platform && this.Platform.showBanner && this.Platform.showBanner(e, n)) : GlobData.showBanner()
                }
            }, {
                key: "winVideo",
                value: function() {
                    if (window.qq) {
                        if (!this.Platform)
                            return;
                        this.Platform.winVideo && this.Platform.winVideo()
                    }
                }
            }, {
                key: "executeShowVivoChaPing",
                value: function() {
                    void 0 != window.vivoUtil && vivoUtil.showAd_ChaPing(),
                    null != oppoUtil && cc.sys.platform == cc.sys.OPPO_GAME && oppoUtil.showAd_ChaPing(),
                    window.qg && window.sendDesk && window.qg.hasShortcutInstalled({
                        success: function(e) {
                            e ? console.log("桌面有图标:", e) : (console.log("桌面无图标:", e),
                            window.qg.installShortcut({
                                success: function() {},
                                fail: function(e) {},
                                complete: function() {}
                            }))
                        }
                        .bind(this),
                        fail: function(e) {}
                        .bind(this),
                        complete: function() {}
                        .bind(this)
                    }),
                    this.Platform && this.Platform.executeJieSuanChaPing && this.Platform.executeJieSuanChaPing()
                }
            }, {
                key: "executeShowVIVOInGame",
                value: function() {
                    void 0 != window.vivoUtil ? vivoUtil.showAdInGame() : null != oppoUtil && cc.sys.platform === cc.sys.OPPO_GAME && oppoUtil.showAdInGame()
                }
            }, {
                key: "executeHideBanner",
                value: function() {
                    this.Platform && this.Platform.hideBanner && this.Platform.hideBanner()
                }
            }, {
                key: "executeHideSecondBanner",
                value: function() {
                    this.Platform && this.Platform.hideSecondBanner && this.Platform.hideSecondBanner()
                }
            }, {
                key: "excuteRandSuiji",
                value: function() {
                    this.Platform && this.Platform.Suijivideo && this.Platform.Suijivideo()
                }
            }, {
                key: "executeShowSystemBanner",
                value: function() {
                    this.Platform && this.Platform.showSystemBanner && this.Platform.showSystemBanner()
                }
            }, {
                key: "executeShowGrid",
                value: function(e, n) {
                    var a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "landscape";
                    this.Platform && this.PlatformCode === u.QQ && this.Platform.showGrid && this.Platform.showGrid(e, n, a)
                }
            }, {
                key: "executeShowSpecialBanner",
                value: function() {
                    this.Platform && this.RemoteConfig.isLine && this.RemoteConfig.allowBanner && this.PlatformCode === u.OPPO && this.Platform.showSpecialBanner && this.Platform.showSpecialBanner()
                }
            }, {
                key: "executeShowAlertBanner",
                value: function(e) {
                    this.Platform && this.RemoteConfig.isLine && this.RemoteConfig.allowBanner && this.PlatformCode === u.OPPO && this.Platform.showAlertBanner && this.Platform.showAlertBanner(e)
                }
            }, {
                key: "executeHideSpecialBanner",
                value: function() {
                    this.Platform && this.RemoteConfig.isLine && this.RemoteConfig.allowBanner && this.PlatformCode === u.OPPO && this.Platform.hideSpecialBanner && this.Platform.hideSpecialBanner()
                }
            }, {
                key: "executeShowInterstitial",
                value: function(e) {
                    this.Platform && (this.Platform.showInterstitial && this.Platform.showInterstitial())
                }
            }, {
                key: "executeStartRecorder",
                value: function() {
                    this.Platform && this.PlatformCode === u.头条 && this.Platform.startRecorder && this.Platform.startRecorder()
                }
            }, {
                key: "executeStopRecorder",
                value: function() {
                    this.Platform && this.PlatformCode === u.头条 && this.Platform.stopRecorder && this.Platform.stopRecorder()
                }
            }, {
                key: "executeRandomShare",
                value: function(e, n) {
                    this.Platform && this.PlatformCode === u.头条 && this.RemoteConfig.isLine && (l.MathMgr.getRandomNum(0, 100) < this.RemoteConfig.randomShare && this.executeShare(e, n))
                }
            }, {
                key: "executeShare",
                value: function(e, n) {
                    this.Platform && this.Platform.doShare && this.Platform.doShare(e, n)
                }
            }, {
                key: "executeShowMoreGames",
                value: function() {
                }
            }, {
                key: "isInstalledDesktopShortcut",
                value: function(e, n) {
                    window.qg && window.qg.hasShortcutInstalled({
                        success: function(a) {
                            a ? e && e() : n && n()
                        },
                        fail: function(e) {},
                        complete: function() {}
                    }),
                    this.Platform && this.Platform.isInstalledDesktopShortcut ? this.Platform.isInstalledDesktopShortcut(e, n) : e && e()
                }
            }, {
                key: "executeShowLargeNavigation",
                value: function() {
                    this.Platform && this.Platform.executeShowLargeNavigation && this.Platform.executeShowLargeNavigation()
                }
            }, {
                key: "executeNavigateToMiniProgram",
                value: function(e) {
                    this.Platform && this.Platform.fromToMiniProgram && this.Platform.fromToMiniProgram(e)
                }
            }, {
                key: "executeAddColorSign",
                value: function(e) {
                    this.Platform && this.Platform.additionColorSign && this.Platform.additionColorSign(e)
                }
            }, {
                key: "executeDesktopShortcut",
                value: function(e) {
                    cc.sys.platform !== cc.sys.VIVO_GAME && cc.sys.platform !== cc.sys.OPPO_GAME || window.qg.installShortcut({
                        success: function() {
                            e && (e.active = !1)
                        },
                        fail: function(e) {
                            null != oppoUtil && cc.sys.platform === cc.sys.OPPO_GAME && oppoUtil.showAd_Banner()
                        },
                        complete: function() {}
                    }),
                    this.Platform && this.Platform.additionShortcut && this.Platform.additionShortcut(e)
                }
            }, {
                key: "executeShortShake",
                value: function() {
                    window.tt.vibrateShort({
                        success: function(e) {
                            console.log("成功震动")
                        },
                        fail: function(e) {
                            console.log("成功失败")
                        },
                        complete: function() {
                            console.log("震动完成")
                        }
                    })
                }
            }]),
            e
        }();
        a.PlatformUtils = w,
        cc._RF.pop()
    }
    , {
        "../../Scripts/Utils": "Utils",
        "./QQUtil": "QQUtil",
        "./_4399": "_4399",
        "./_UC": "_UC",
        "./_baidu": "_baidu",
        "./_bytedance": "_bytedance",
        "./_huawei": "_huawei",
        "./_oppo": "_oppo",
        "./_tencent": "_tencent",
        "./_wechat": "_wechat"
    }],
    Playing_Scene_Script: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "d728a5us1NNAKakAewbtFsx", "Playing_Scene_Script");
        var o = e("../Prefab/Playing/gameData")
          , i = e("../Utils")
          , t = e("../Config/StorgeInfo");
        cc.Class({
            extends: cc.Component,
            properties: {
                cars: {
                    default: null,
                    type: cc.Node,
                    displayName: "车的父节点"
                },
                guan: {
                    default: null,
                    type: cc.Label,
                    displayName: "第几关"
                },
                hintNode: {
                    default: null,
                    type: cc.Node,
                    displayName: "提示框"
                },
                buttons: {
                    default: null,
                    type: cc.Node,
                    displayName: "提示撤销按钮"
                },
                background: {
                    default: null,
                    type: cc.Sprite,
                    displayName: "背景"
                }
            },
            onLoad: function() {
                var e = this;
                this.hint_Count = 0,
                this.car_Count = 0,
                cc.car_id = null,
                cc.recordPosition = [],
                cc.click_count = 0,
                cc.isHint = !1,
                cc.hint = function() {
                    cc.isHint && (cc.isHint = !0,
                    e.hint(),
                    e.set_Button_Color())
                }
                ,
                cc.set_Button_Color = function() {
                    e.set_Button_Color()
                }
                ,
                this.guan.string = cc.StorageInfo.click_Leve;
                var n = cc.StorageInfo.click_ModuleName.split("-");
                i.AssMgr.setSpriteFrameByName(this.background, "back-".concat(n[1])),
                cc.time_count = 1
            },
            start: function() {
                this.schedule(function() {
                    cc.isHint || cc.time_count && (cc.time_count++,
                    console.log("推送提示-----1"),
                    15 === cc.time_count && (cc.director.getScene().pauseSystemEvents(!0),
                    i.AssMgr.createPrefabByName("pushHint", function(e) {
                        var n = cc.instantiate(e);
                        cc.director.getScene().addChild(n)
                    })))
                }, 1),
                cc.PlatformUtils.executeStartRecorder(),
                console.log("执行"),
                window.qg ? cc.PlatformUtils.executeShowVIVOInGame() : cc.PlatformUtils.executeShowBanner(cc.v2(cc.view.getVisibleSize().width / 2, cc.view.getVisibleSize().height), cc.v2(.5, 0)),
                cc.PlatformUtils.executeShowInterstitial(!0)
            },
            click_btn: function(e) {
                var n = this;
                switch (i.SoundMgr.playEffect("button"),
                e.target.name) {
                case "jb_Hint":
                    if (cc.StorageInfo.sum_Money < 200)
                        return console.log("金币不够"),
                        void this.showBuyMoney();
                    cc.StorageInfo.sum_Money -= 200,
                    cc.isHint = !0,
                    cc.carInit(),
                    this.hint(),
                    cc.setMoney(),
                    this.set_Button_Color(),
                    console.log("免费---提示");
                    break;
                case "sp_Hint":
                    var a = function() {
                        cc.isHint = !0,
                        cc.carInit(),
                        n.hint(),
                        n.set_Button_Color()
                    };
                    cc.PlatformUtils.executeShowVideo(a),
                    console.log("视频---免费提示");
                    break;
                case "chexiao":
                    console.log("跳过"),
                    a = function() {
                        n.skipLevel()
                    }
                    ,
                    cc.PlatformUtils.executeShowVideo(a);
                    break;
                case "fanhui":
                    cc.director.loadScene("model")
                }
            },
            executeCalculateMoveDistance: function(e) {
                for (var n = this.cars.children, a = 0; a < n.length; a++)
                    n[a].getComponent("CarItem").calculateMoveDistance(e)
            },
            showBuyMoney: function() {
                i.AssMgr.createPrefabByName("BuyMoney", function(e) {
                    var n = cc.instantiate(e);
                    cc.director.getScene().addChild(n)
                })
            },
            skipLevel: function() {
                if (cc.StorageInfo.click_Leve >= cc.StorageInfo.Module[cc.StorageInfo.click_ModuleName].sumLevel)
                    return cc.StorageInfo.click_Leve = cc.StorageInfo.Module[cc.StorageInfo.click_ModuleName].sumLevel,
                    console.log("没有关卡了"),
                    void i.AssMgr.createPrefabByName("Warning", function(e) {
                        var n = cc.instantiate(e);
                        n.getComponent("warningItem").setWarning_text("没有关卡了"),
                        cc.director.getScene().addChild(n)
                    });
                cc.StorageInfo.click_Leve >= cc.StorageInfo.Module[cc.StorageInfo.click_ModuleName].now_Leve && (cc.StorageInfo.Module[cc.StorageInfo.click_ModuleName].now_Leve += 1),
                cc.StorageInfo.click_Leve += 1,
                cc.director.loadScene("Playing")
            },
            revocation: function() {
                var e = cc.getMap()
                  , n = cc.recordPosition.length
                  , a = cc.recordPosition[n - 1];
                if (a) {
                    var o = a.index
                      , i = a.position
                      , t = this.cars.children[o];
                    t.position = i,
                    t.getComponent("CarItem").executeStop(e),
                    this.executeCalculateMoveDistance(e),
                    cc.recordPosition.splice(n - 1, 1)
                } else
                    console.log("没有了,不能撤销了!!!");
                console.log(e)
            },
            set_Button_Color: function() {
                this.buttons.pauseSystemEvents(!0);
                for (var e = this.buttons.children, n = (cc.color(50, 50, 50, 255),
                0); n < e.length; n++)
                    e[n]
            },
            hint: function() {
                var e = this
                  , n = this.hintNode.parent.children[0];
                n.active = !1;
                var a = this.hintNode;
                a.active = !1;
                var r = cc.StorageInfo.click_ModuleName.split("-")
                  , c = cc.StorageInfo.Module["".concat(r[0], "-").concat(r[1])].now_Leve;
                cc.StorageInfo.click_Leve && (c = cc.StorageInfo.click_Leve),
                c -= 1;
                var d = o.CarDataList["".concat(r[0], "-").concat(r[1])][c].end
                  , s = null
                  , l = null
                  , x = null
                  , m = null
                  , f = null;
                (function o() {
                    s = d[e.car_Count],
                    l = s.location,
                    x = cc.v2(l.x, l.y);
                    var r = s.orderIndex;
                    cc.car_id = r;
                    for (var c = 0; c < e.cars.children.length; c++)
                        if (e.cars.children[c].orderIndex === r) {
                            m = e.cars.children[c];
                            break
                        }
                    f = m.position,
                    a.active = !0,
                    cc.Tween.stopAllByTarget(a),
                    a.opacity = 0,
                    a.position = f;
                    var y = "sange";
                    if (m.height <= 2 * t.Grid_Width && (y = "liangge"),
                    console.log(y, m.height),
                    i.AssMgr.setSpriteFrameByName(n.getComponent(cc.Sprite), y),
                    n.active = !0,
                    cc.Tween.stopAllByTarget(n),
                    n.position = x,
                    n.angle = m.angle,
                    m.x === x.x && m.y === x.y) {
                        if (e.car_Count === d.length - 1)
                            return a.active = !1,
                            n.active = !1,
                            void console.log("没有提示的了");
                        e.car_Count += 1,
                        o(),
                        cc.car_id = s.orderIndex,
                        console.log(111111)
                    }
                }
                )();
                var y = cc.tween().to(.3, {
                    opacity: 255
                }).to(1.5, {
                    position: x
                }, {
                    easing: "smooth"
                }).to(1, {
                    opacity: 0
                }).call(function() {
                    a.position = f
                })
                  , h = cc.tween().to(.5, {
                    opacity: 0
                }, {
                    easing: "smooth"
                }).to(.5, {
                    opacity: 255
                }, {
                    easing: "smooth"
                });
                cc.tween(a).repeatForever(y).start(),
                cc.tween(n).repeatForever(h).start()
            }
        }),
        cc._RF.pop()
    }
    , {
        "../Config/StorgeInfo": "StorgeInfo",
        "../Prefab/Playing/gameData": "gameData",
        "../Utils": "Utils"
    }],
    QQUtil: [function(e, n, a) {
        "use strict";
        function o(e, n) {
            if (!(e instanceof n))
                throw new TypeError("Cannot call a class as a function")
        }
        function i(e, n) {
            for (var a = 0; a < n.length; a++) {
                var o = n[a];
                o.enumerable = o.enumerable || !1,
                o.configurable = !0,
                "value"in o && (o.writable = !0),
                Object.defineProperty(e, o.key, o)
            }
        }
        function t(e, n, a) {
            return n && i(e.prototype, n),
            a && i(e, a),
            e
        }
        cc._RF.push(n, "c3688resY5D5IpOhsDvHCs0", "QQUtil"),
        Object.defineProperty(a, "__esModule", {
            value: !0
        }),
        a.QQUtil = void 0,
        window.qqisios = !1;
        var r = function() {
            function e() {
                o(this, e),
                this.SystemInformation = null,
                this.BannerCode = "f16cac73228abe349dcee482011fa78e",
                this.VideoCode = "05cd3fc1d5c0376eecbd1769d884ab3e",
                this.InterstitialCode = "ec60ebcd8750b7dc51e4c2af8a10a8dd",
                this.GameBoxCode = "a838b0faac2858394edda7abc024ef55",
                this.BlockCode = "c1dfb256aafa7d9ecfa2c6448a196d95",
                this.BlockIndex = 0,
                this.BannerInstance = null,
                this.ShuaxinTime = null,
                this.VideoInstance = null,
                this.VideoSuccessCallBack = null,
                this.VideoFailureCallBack = null,
                this.InterstitialInstance = null,
                this.BlockInstance = null,
                this.wincount = 0,
                this.fangxiang = null,
                this.shareImgUrl = "logo.png"
            }
            return t(e, [{
                key: "doInitialize",
                value: function() {
                    this.kaiping = !0,
                    window.ServerConfigBd = window.GameConfig,
                    console.log("实例化头条组件  qq");
                    var e = this;
                    e.SystemInformation = window.qq.getSystemInfoSync(),
                    "ios" === e.SystemInformation.platform && (window.qqisios = !0,
                    console.log("是ios系统" + window.qqisios)),
                    console.log("不是ios系统" + window.qqisios),
                    window.qq.createRewardedVideoAd && (e.VideoInstance = window.qq.createRewardedVideoAd({
                        adUnitId: e.VideoCode
                    }),
                    e.VideoInstance.load(),
                    e.VideoInstance.onClose(function(n) {
                        1 == n.isEnded ? e.videoDisplaySuccessCallBack() : window.ServerConfigBd.showModal ? window.qq.showModal({
                            title: "未观看完视频",
                            content: "观看完视频才能获得奖励哦",
                            success: function(n) {
                                n.confirm ? e.VideoInstance.show().then(function() {
                                    return console.log("激励视频 广告显示")
                                }).catch(function() {
                                    e.VideoInstance.load().then(function() {
                                        return e.VideoInstance.show()
                                    }).catch(function(e) {
                                        console.log("激励视频 广告显示失败"),
                                        window.qq.showToast({
                                            title: "广告加载失败,请稍后重试！",
                                            icon: "none",
                                            duration: 1e3,
                                            success: function(e) {
                                                console.log(e)
                                            },
                                            fail: function(e) {
                                                console.log("showToast 调用失败")
                                            }
                                        })
                                    })
                                }) : n.cancel ? (console.log("取消1111"),
                                e.videoDisplayFailureCallBack(),
                                window.qq.showToast({
                                    title: "未观看完整视频！",
                                    icon: "none",
                                    duration: 1e3,
                                    success: function(e) {
                                        console.log("".concat(e))
                                    },
                                    fail: function(e) {
                                        console.log("showToast调用失败")
                                    }
                                })) : (e.videoDisplayFailureCallBack(),
                                window.qq.showToast({
                                    title: "未观看完整视频！",
                                    icon: "none",
                                    duration: 1e3,
                                    success: function(e) {
                                        console.log("".concat(e))
                                    },
                                    fail: function(e) {
                                        console.log("showToast调用失败")
                                    }
                                }))
                            },
                            fail: function(n) {
                                console.log("showModal调用失败"),
                                e.videoDisplayFailureCallBack(),
                                window.qq.showToast({
                                    title: "未观看完整视频！",
                                    icon: "none",
                                    duration: 1e3,
                                    success: function(e) {
                                        console.log("".concat(e))
                                    },
                                    fail: function(e) {
                                        console.log("showToast调用失败")
                                    }
                                })
                            }
                        }) : (e.videoDisplayFailureCallBack(),
                        window.qq.showToast({
                            title: "未观看完整视频！",
                            icon: "none",
                            duration: 1e3,
                            success: function(e) {
                                console.log("".concat(e))
                            },
                            fail: function(e) {
                                console.log("showToast调用失败")
                            }
                        }))
                    }))
                }
            }, {
                key: "sceneTrue",
                value: function() {
                    var e = qq.getLaunchOptionsSync().scene;
                    if (console.log("场景值：" + e),
                    window.ServerConfigBd.sceneID == [])
                        return !1;
                    for (var n = window.ServerConfigBd.sceneID, a = 0; a < n.length; a++)
                        if (e == n[a])
                            return !0;
                    return !1
                }
            }, {
                key: "winVideo",
                value: function() {
                    this.wincount++,
                    0 !== window.ServerConfigBd.winVideo && this.wincount % window.ServerConfigBd.winVideo == 0 && this.executeShowAwardVideo(null, null)
                }
            }, {
                key: "showAddZhuomian",
                value: function(e, n) {
                    console.log("执行3：" + window.ServerConfigBd.randomSendDesk + "isJieSuan::" + n),
                    console.log("执行2：" + this.GaiLv(window.ServerConfigBd.randomSendDesk)),
                    n ? this.GaiLv(window.ServerConfigBd.randomSendDesk) && this.sendDesktopShortcut(null, !1, function() {}) : this.sendDesktopShortcut(e, n, function() {})
                }
            }, {
                key: "showMainCaiqian",
                value: function() {
                    arguments.length > 0 && void 0 !== arguments[0] && arguments[0] ? this.GaiLv(window.GameConfig.randomLoadCaiQian) && 0 == qq.isColorSignExistSync() && this.executeAddColorSign() : 0 == qq.isColorSignExistSync() && this.executeAddColorSign()
                }
            }, {
                key: "showBanner",
                value: function() {
                    if (0 != window.ServerConfigBd.showbanner) {
                        if (null == this.BannerInstance) {
                            var e = this;
                            e.BannerInstance = window.qq.createBannerAd({
                                adUnitId: e.BannerCode,
                                style: {
                                    left: (qq.getSystemInfoSync().screenWidth - .4 * qq.getSystemInfoSync().screenWidth) / 2,
                                    top: qq.getSystemInfoSync().screenHeight - 100,
                                    width: .4 * qq.getSystemInfoSync().screenWidth,
                                    height: .4 * qq.getSystemInfoSync().screenWidth * .24
                                },
                                adIntervals: 30
                            }),
                            e.BannerInstance.onResize(function(n) {
                                0 != n.width && 0 != n.height && (e.BannerInstance.style.top = e.SystemInformation.windowHeight - n.height,
                                e.BannerInstance.style.left = (e.SystemInformation.windowWidth - n.width) / 2)
                            }),
                            e.BannerInstance.onError(function(e) {
                                console.log("banner sdk bannerAd错误日志" + e.errMsg + e.errCode)
                            })
                        }
                        console.log("qq显示banner"),
                        null != this.BannerInstance && this.BannerInstance.show(),
                        this.showChaPingMoreGame()
                    }
                }
            }, {
                key: "hideBanner",
                value: function() {
                    console.log("隐藏Banner"),
                    null != this.BannerInstance && (this.BannerInstance.offResize(),
                    this.BannerInstance.offError(),
                    this.BannerInstance.destroy(),
                    this.BannerInstance = null)
                }
            }, {
                key: "Suijivideo",
                value: function() {
                    console.log("qq随机视频"),
                    this.GaiLv(window.ServerConfigBd.randomShowvideo) && this.executeShowAwardVideo(null, null)
                }
            }, {
                key: "kaipingVideo",
                value: function() {
                    console.log("是否第一次：" + this.kaiping),
                    this.GaiLv(window.ServerConfigBd.randomkaiping) && this.sceneTrue() && this.kaiping && (this.executeShowAwardVideo(),
                    this.kaiping = !1)
                }
            }, {
                key: "executeShowInterstitials",
                value: function() {
                    console.log("qq运行显示插屏");
                    var e = qq.createInterstitialAd({
                        adUnitId: this.InterstitialCode
                    });
                    e.load().then(function() {
                        e.show().catch(function(i) {
                            console.error("show", i),
                            e.offLoad(n),
                            e.offError(a),
                            e.offClose(o)
                        })
                    }).catch(function(i) {
                        console.error("load", i),
                        e.offLoad(n),
                        e.offError(a),
                        e.offClose(o)
                    });
                    var n = function() {
                        console.log("onLoad event emit")
                    }
                      , a = function a(i) {
                        console.log("error", i),
                        e.offLoad(n),
                        e.offError(a),
                        e.offClose(o)
                    }
                      , o = function o() {
                        console.log("close event emit"),
                        e.offLoad(n),
                        e.offError(a),
                        e.offClose(o)
                    };
                    e.onLoad(n),
                    e.onClose(o),
                    e.onError(a)
                }
            }, {
                key: "executeShowAwardVideo",
                value: function(e, n) {
                    var a = this;
                    console.log("qq显示激励视频"),
                    this.VideoSuccessCallBack = e,
                    this.VideoFailureCallBack = n,
                    this.VideoInstance.show().then(function() {
                        return console.log("激励视频 广告显示")
                    }).catch(function() {
                        a.VideoInstance.load().then(function() {
                            return a.VideoInstance.show()
                        }).catch(function(e) {
                            console.log("激励视频 广告显示失败"),
                            window.qq.showToast({
                                title: "广告加载失败,请稍后重试！",
                                icon: "none",
                                duration: 1e3,
                                success: function(e) {
                                    console.log("".concat(e))
                                },
                                fail: function(e) {
                                    console.log("showToast 调用失败")
                                }
                            })
                        })
                    }),
                    this.VideoInstance.onError(function(e) {
                        console.log(e)
                    })
                }
            }, {
                key: "videoDisplaySuccessCallBack",
                value: function() {
                    null != this.VideoSuccessCallBack && (this.VideoSuccessCallBack(),
                    this.VideoSuccessCallBack = null)
                }
            }, {
                key: "videoDisplayFailureCallBack",
                value: function() {
                    null != this.VideoFailureCallBack && (this.VideoFailureCallBack(),
                    this.VideoFailureCallBack = null)
                }
            }, {
                key: "executeShowPushBox",
                value: function() {
                    console.log("qq执行显示");
                    var e = window.qq.createAppBox({
                        adUnitId: this.GameBoxCode
                    });
                    e.onClose(function() {
                        e.destroy().then(function() {}).catch(function(e) {})
                    }
                    .bind(this)),
                    e.load().then(function() {
                        e.show().then(function() {}).catch(function(e) {})
                    }).catch(function(e) {})
                }
            }, {
                key: "sendDesktopShortcut",
                value: function(e, n) {
                    var a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null;
                    qq.saveAppToDesktop({
                        success: function(e) {
                            console.log("添加桌面成功")
                        },
                        fail: function(e) {
                            console.log("添加桌面失败" + JSON.stringify(e)),
                            a && (a(),
                            a = null)
                        },
                        complete: function() {
                            e && (e.active = !1),
                            window.qq.showToast({
                                title: "添加桌面成功",
                                icon: "none",
                                duration: 1e3
                            })
                        }
                    })
                }
            }, {
                key: "executeBlockAdShow",
                value: function() {
                    var e = this;
                    console.log("积木====="),
                    window.ServerConfigBd.showBlock && (this.destorBlockAd(),
                    this.ShuaxinTime = setInterval(function() {
                        e.closeBlockAd();
                        window.qq.getSystemInfoSync();
                        e.BlockInstance = window.qq.createBlockAd({
                            adUnitId: e.BlockCode,
                            style: {
                                left: qq.getSystemInfoSync().screenWidth - 100,
                                top: e.SystemInformation.windowHeight / 4.7
                            },
                            size: 1,
                            orientation: "landscape"
                        }),
                        e.BlockInstance.onLoad(function(n) {
                            e.BlockInstance.show()
                        }),
                        e.BlockInstance.onError(function(e) {
                            console.log("积木广告失败::" + e.errMsg + "   code  " + e.errCode)
                        }),
                        e.BlockInstance.onResize(function(e) {})
                    }, 5e3))
                }
            }, {
                key: "closeBlockAd",
                value: function() {
                    null != this.BlockInstance && (this.BlockInstance.destroy(),
                    this.BlockInstance.hide(),
                    this.BlockInstance = null)
                }
            }, {
                key: "destorBlockAd",
                value: function() {
                    null != this.ShuaxinTime && clearInterval(this.ShuaxinTime),
                    this.closeBlockAd()
                }
            }, {
                key: "executeAddColorSign",
                value: function() {
                    0 == qq.isColorSignExistSync() && (console.log("qq.isColorSignExistSync" + qq.isColorSignExistSync()),
                    qq.addColorSign({
                        success: function(e) {
                            console.log("添加彩签成功")
                        },
                        fail: function(e) {
                            console.log("添加彩签失败" + JSON.stringify(e))
                        },
                        complete: function() {}
                    }))
                }
            }, {
                key: "showChaPingMoreGame",
                value: function() {
                    0 != window.ServerConfigBd.randomChaping && (this.GaiLv(window.ServerConfigBd.randomChaping) ? this.executeShowInterstitials() : this.executeShowPushBox())
                }
            }, {
                key: "executeRecorder",
                value: function() {}
            }, {
                key: "stopRecorder",
                value: function() {}
            }, {
                key: "isInstalledShortcut",
                value: function() {}
            }, {
                key: "executeShareRecorder",
                value: function(e, n) {
                    this.shareSuccessHandle = e,
                    this.shareFailureHandle = n,
                    this.isOpenShare = !0,
                    window.qq.shareAppMessage({
                        title: this.shareText,
                        imageUrl: this.shareImgUrl,
                        success: function() {
                            console.log("分享视频成功111"),
                            e && e()
                        },
                        fail: function(e) {
                            console.log("分享视频失败"),
                            n && n()
                        }
                    }),
                    console.log("分享---")
                }
            }, {
                key: "GaiLv",
                value: function(e) {
                    var n = 1 + Math.floor(100 * Math.random());
                    return console.log("随机数为：" + n),
                    console.log("服务器值为：" + e),
                    n <= e
                }
            }]),
            e
        }();
        a.QQUtil = r,
        cc._RF.pop()
    }
    , {}],
    QianDao: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "b58342adyhIJrI/ip2D0qGW", "QianDao");
        var o = e("../../../Utils")
          , i = e("../../../TweenClass")
          , t = e("../../../../resources/Platform/PlatformUtils");
        cc.Class({
            extends: cc.Component,
            properties: {
                center: {
                    default: null,
                    type: cc.Node,
                    displayName: "容器"
                },
                buttons: {
                    default: null,
                    type: cc.Node,
                    displayName: "按钮"
                },
                main: {
                    default: null,
                    type: cc.Node
                }
            },
            onLoad: function() {
                this.init(),
                i.TweenClass.scale_3_1_Tween(this.node.children[1])
            },
            start: function() {
                cc.PlatformUtils.executeShowBanner(cc.v2(cc.view.getVisibleSize().width / 2, cc.view.getVisibleSize().height), cc.v2(.5, 0)),
                cc.PlatformUtils.executeShowInterstitial(!0)
            },
            btn_Click: function(e) {
                var n = this;
                switch (o.SoundMgr.playEffect("button"),
                e.target.name) {
                case "guanbi":
                    i.TweenClass.scale_close_Tween(this.node.children[1]);
                    break;
                case "qiandao":
                    this.click_QianDao(1),
                    cc.setMoney();
                    break;
                case "shuangbeiqiandao":
                    console.log("看广告双倍领取");
                    cc.PlatformUtils.executeShowVideo(function() {
                        n.click_QianDao(2),
                        cc.setMoney()
                    })
                }
                cc.sys.localStorage.setItem(t.App.storageName, JSON.stringify(cc.StorageInfo))
            },
            click_QianDao: function(e) {
                for (var n = (new Date).getDate(), a = 0; a < 7; a++) {
                    if (1 === cc.StorageInfo.QianDaoList[a]) {
                        cc.StorageInfo.QianDaoList[a] = "2-".concat(n),
                        cc.StorageInfo.QianDaoList[a + 1] = 1,
                        cc.StorageInfo.yiQianDaoList.push(n);
                        var o = this.center.children[a].children[0].children[0].getComponent(cc.Label).string;
                        o = parseInt(o.replace("/", "")),
                        cc.create_JiangLi("/".concat(o * e)),
                        this.init();
                        break
                    }
                }
            },
            init: function() {
                var e = this
                  , n = (new Date).getDate();
                this.center.removeAllChildren();
                for (var a = 0; a < 7; a++)
                    if ("string" == typeof cc.StorageInfo.QianDaoList[a]) {
                        var i = cc.StorageInfo.QianDaoList[a].split("-")[1]
                          , t = cc.StorageInfo.QianDaoList[a - 1];
                        if (t)
                            i - (t = t.split("-")) > 1 && (cc.StorageInfo.QianDaoList = [1, 0, 0, 0, 0, 0, 0],
                            cc.StorageInfo.yiQianDaoList = []);
                        var r = parseInt(cc.StorageInfo.QianDaoList[a].split("-")[1]);
                        this.buttons.active = r !== n
                    }
                o.AssMgr.createPrefabByName("putong", function(n) {
                    for (var a = 0; a < 7; a++) {
                        var o = cc.StorageInfo.QianDaoList[a]
                          , i = a + 1
                          , t = cc.instantiate(n);
                        t.getComponent("putong").init(i, o, cc.StorageInfo.QianDaoList[a - 1]),
                        e.center.addChild(t)
                    }
                })
            }
        }),
        cc._RF.pop()
    }
    , {
        "../../../../resources/Platform/PlatformUtils": "PlatformUtils",
        "../../../TweenClass": "TweenClass",
        "../../../Utils": "Utils"
    }],
    SlideEvent: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "955c7Dga9lBypZTdpzq548y", "SlideEvent"),
        cc.Class({
            extends: cc.Component,
            properties: {
                MaskNode: {
                    default: null,
                    type: cc.Node,
                    displayName: "可视节点"
                },
                ItemContent: {
                    default: null,
                    type: cc.Node,
                    displayName: "单元容器"
                },
                ItemPrefab: {
                    default: null,
                    type: cc.Prefab,
                    displayName: "单元预制体"
                }
            },
            onLoad: function() {
                this.isMeetRoll = !0,
                this.allowRoll = !1,
                this.rollDirection = 0,
                this.moveSpeed = 20,
                this.ItemContent.removeAllChildren(!0)
            },
            executeDisplay: function() {
                if (this.isMeetRoll = !1,
                this.allowRoll = !1,
                console.log("更新尺寸"),
                this.ItemContent.getComponent(cc.Layout).updateLayout(),
                1 === this.directionStyle) {
                    var e = this.ItemContent.getContentSize().width
                      , n = this.MaskNode.getContentSize().width;
                    e > n && (this.isMeetRoll = !0,
                    this.allowRoll = !0,
                    this.ItemContent.on(cc.Node.EventType.TOUCH_START, this.onTouchStart, this),
                    this.ItemContent.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this),
                    this.ItemContent.on(cc.Node.EventType.TOUCH_CANCEL, this.onTouchEnd, this),
                    this.ItemContent.on(cc.Node.EventType.TOUCH_END, this.onTouchEnd, this)),
                    this.minX = this.ItemContent.x,
                    this.maxX = this.minX - (e - n)
                } else if (2 === this.directionStyle) {
                    var a = this.ItemContent.getContentSize().height
                      , o = this.MaskNode.getContentSize().height;
                    this.distance = 0,
                    this.isMeetRoll = !1,
                    a > o && (this.isMeetRoll = !0,
                    this.distance = a - o,
                    this.allowRoll = !0,
                    this.ItemContent.on(cc.Node.EventType.TOUCH_START, this.onTouchStart, this),
                    this.ItemContent.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this),
                    this.ItemContent.on(cc.Node.EventType.TOUCH_CANCEL, this.onTouchEnd, this),
                    this.ItemContent.on(cc.Node.EventType.TOUCH_END, this.onTouchEnd, this))
                }
            },
            instantiation: function(e, n) {
                var a = this;
                this.directionStyle = e,
                this.detailList = [];
                for (var o = 0; o < cc.PlatformUtils.RemoteConfig.iconList.length; o++) {
                    var i = {
                        url: cc.PlatformUtils.RemoteConfig.iconList[o],
                        appId: cc.PlatformUtils.RemoteConfig.packageList[o]
                    };
                    this.detailList.push(i)
                }
                for (var t = function(e) {
                    var o = cc.instantiate(a.ItemPrefab);
                    o.setContentSize(n),
                    o.appId = a.detailList[e].appId,
                    a.ItemContent.addChild(o);
                    var i = o.getComponent(cc.Sprite);
                    cc.loader.load(a.detailList[e].url, function(e, n) {
                        i.spriteFrame = new cc.SpriteFrame(n)
                    })
                }, r = 0; r < this.detailList.length; r++)
                    t(r)
            },
            update: function(e) {
                if (this.isMeetRoll && this.allowRoll)
                    if (1 === this.directionStyle) {
                        if (0 === this.rollDirection) {
                            if (this.ItemContent.x += this.moveSpeed * e,
                            this.ItemContent.x >= this.minX)
                                return this.ItemContent.x = this.minX,
                                void (this.rollDirection = 1)
                        } else if (1 === this.rollDirection && (this.ItemContent.x -= this.moveSpeed * e,
                        this.ItemContent.x <= this.maxX))
                            return this.ItemContent.x = this.maxX,
                            void (this.rollDirection = 0)
                    } else if (2 === this.directionStyle) {
                        var n = this.ItemContent.y;
                        if (0 === this.rollDirection) {
                            if ((n += this.moveSpeed * e) >= this.distance)
                                return this.ItemContent.y = this.distance,
                                void (this.rollDirection = 1);
                            this.ItemContent.y = n
                        } else {
                            if ((n -= this.moveSpeed * e) <= 0)
                                return this.ItemContent.y = 0,
                                void (this.rollDirection = 0);
                            this.ItemContent.y = n
                        }
                    }
            },
            onTouchStart: function(e) {
                this.allowRoll = !1,
                this.firstTouchPoint = this.ItemContent.convertToNodeSpaceAR(e.getLocation())
            },
            onTouchMove: function(e) {
                if (!this.allowRoll)
                    if (1 === this.directionStyle) {
                        var n = e.getDelta().x;
                        this.ItemContent.x += n,
                        this.ItemContent.x >= this.minX && (this.ItemContent.x = this.minX),
                        this.ItemContent.x <= this.maxX && (this.ItemContent.x = this.maxX)
                    } else if (2 === this.directionStyle) {
                        var a = e.getDelta().y;
                        this.ItemContent.y += a,
                        this.ItemContent.y >= this.distance && (this.ItemContent.y = this.distance),
                        this.ItemContent.y <= 0 && (this.ItemContent.y = 0)
                    }
            },
            onTouchEnd: function(e) {
                if (!this.allowRoll) {
                    this.allowRoll = !0;
                    var n = this.ItemContent.convertToNodeSpaceAR(e.getLocation());
                    if (this.firstTouchPoint.sub(n).mag() < 10)
                        for (var a = this.ItemContent.children, o = 0; o < a.length; o++) {
                            var i = a[o];
                            if (i.getBoundingBox().contains(n)) {
                                cc.PlatformUtils.executeNavigateToMiniProgram(i.appId);
                                break
                            }
                        }
                }
            }
        }),
        cc._RF.pop()
    }
    , {}],
    SmallHotItem: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "59f892zh1NC2r/vOPWPYxGR", "SmallHotItem"),
        cc.Class({
            extends: cc.Component,
            properties: {
                Img: {
                    default: null,
                    type: cc.Sprite,
                    displayName: "图"
                },
                HotNode: {
                    default: null,
                    type: cc.Node,
                    displayName: "标识"
                }
            },
            start: function() {
                var e = cc.tween().to(.6, {
                    scale: .7
                }).to(.6, {
                    scale: .5
                });
                cc.tween(this.HotNode).repeatForever(e).start()
            },
            instantiation: function(e) {
                var n = this;
                this.detail = e,
                cc.loader.load(e.url, function(e, a) {
                    n.Img.spriteFrame = new cc.SpriteFrame(a)
                })
            }
        }),
        cc._RF.pop()
    }
    , {}],
    SpecialBanner: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "144f1IhPOlIlZCHn0JAzre/", "SpecialBanner"),
        cc.Class({
            extends: cc.Component,
            properties: {
                Img: {
                    default: null,
                    type: cc.Sprite,
                    displayName: "底图"
                }
            },
            onLoad: function() {
                this.nativeInstance = null,
                this.node.active = !1
            },
            executeRefresh: function(e, n, a) {
                var o = this;
                this.nativeInstance = e,
                this.imgPath = n,
                this.code = a,
                cc.loader.load({
                    url: n,
                    type: "jpg"
                }, function(e, n) {
                    o.Img.spriteFrame = new cc.SpriteFrame(n),
                    o.node.active = !0
                }),
                this.nativeInstance.reportAdShow({
                    adId: this.code
                })
            },
            executeDisplay: function() {
                this.nativeInstance ? this.node.active = !0 : this.node.active = !1
            },
            getNativeInformation: function() {
                return {
                    nativeInstance: this.nativeInstance,
                    imgPath: this.imgPath,
                    code: this.code
                }
            },
            executeTouch: function() {
                this.nativeInstance && this.nativeInstance.reportAdClick({
                    adId: this.code
                })
            },
            executeClose: function() {
                if (cc.PlatformUtils.RemoteConfig.isLine && cc.PlatformUtils.RemoteConfig.trigger.residue > 0 && cc.PlatformUtils.RemoteConfig.triggerLimit > 0) {
                    if (cc.PlatformUtils.RemoteConfig.trigger.residue--,
                    cc.PlatformUtils.RemoteConfig.trigger.residue <= 0)
                        return cc.PlatformUtils.RemoteConfig.triggerLimit--,
                        cc.PlatformUtils.RemoteConfig.trigger.residue = cc.PlatformUtils.RemoteConfig.trigger.default,
                        void this.executeTouch();
                    this.node.active = !1
                } else
                    this.node.active = !1
            },
            buttonTouchEventCallBack: function(e) {
                switch (e.target.name) {
                case "closeButton":
                    this.executeClose();
                    break;
                case "SpecialBanner":
                case "showButton":
                    this.executeTouch()
                }
            }
        }),
        cc._RF.pop()
    }
    , {}],
    StorgeInfo: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "c1f6cxLt6tDfLhP8MG6KiJ2", "StorgeInfo"),
        Object.defineProperty(a, "__esModule", {
            value: !0
        }),
        a.StorgeInfo = a.Max_Col = a.Max_Row = a.Max_Height = a.Max_Width = a.Grid_Height = a.Grid_Width = a.Direction = void 0;
        a.Direction = {
            Idle: 1,
            UP: 2,
            DOWN: 3,
            LEFT: 4,
            RIGHT: 5
        };
        a.Grid_Width = 110;
        a.Grid_Height = 110;
        a.Max_Width = 660;
        a.Max_Height = 660;
        a.Max_Row = 6;
        a.Max_Col = 6;
        a.StorgeInfo = {
            QianDaoList: [1, 0, 0, 0, 0, 0, 0],
            yiQianDaoList: [],
            sum_Money: 100,
            click_Leve: 0,
            isSingIn: !1,
            click_ModuleName: "",
            Module: {
                "module-1": {
                    sumLevel: 30,
                    now_Leve: 1
                },
                "module-2": {
                    sumLevel: 30,
                    now_Leve: 1
                },
                "module-3": {
                    sumLevel: 30,
                    now_Leve: 1
                },
                "module-4": {
                    sumLevel: 30,
                    now_Leve: 1
                }
            },
            Module_suo: [!0, !0, !1, !1]
        },
        cc._RF.pop()
    }
    , {}],
    TDHttps: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "a81d5zIpkVIZrmoZweaYt28", "TDHttps"),
        cc._RF.pop()
    }
    , {}],
    TimeControl: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "fa1f7lo41pCvrV3YJJeHA6A", "TimeControl"),
        cc.Class({
            extends: cc.Component,
            properties: {},
            onLoad: function() {
                cc.onLineInfo = {
                    step: 0,
                    isFinal: !1,
                    data: [{
                        receiveStatus: 1,
                        time: 180,
                        money: 200
                    }, {
                        receiveStatus: 1,
                        time: 360,
                        money: 500
                    }]
                },
                cc.game.addPersistRootNode(this.node)
            },
            start: function() {
                var e = this;
                this.schedule(function n() {
                    cc.onLineInfo.isFinal ? e.unschedule(n) : cc.onLineInfo.data[cc.onLineInfo.step].receiveStatus > 1 || (cc.onLineInfo.data[cc.onLineInfo.step].time--,
                    cc.onLineInfo.data[cc.onLineInfo.step].time <= 0 && (cc.onLineInfo.data[cc.onLineInfo.step].receiveStatus = 2))
                }, 1)
            }
        }),
        cc._RF.pop()
    }
    , {}],
    TouTiaoTools: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "20a02F4JwxLool8UTtiCXe4", "TouTiaoTools"),
        window.TouTiaoTools = {
            ingameBanner: !1,
            bannerID: "ibk3eefe88p1su4lh2",
            videoID: "d18034aie7fi2g8h1o",
            chapingID: "2li54jd4jan84oq5kd",
            AppName: "不服来挑战",
            ShareID: "e2dck3h75hhe978g27",
            ShareDataTitle: "史上最烧脑的游戏绞尽脑汁也闯不过第五关",
            videoCallbackSuccess: null,
            videoCallbackFaile: null,
            videoAd: null,
            interstitialAd: null,
            randomVideo: function() {
                TouTiaoTools.GaiLv(window.ServerConfigBd.randomShowvideo) && TouTiaoTools.getVideoAd(null, null)
            },
            KaipingVideo: function() {
                TouTiaoTools.GaiLv(window.ServerConfigBd.kaiping) && TouTiaoTools.getVideoAd(null, null)
            },
            getVideoAd: function(e, n) {
                this.videoCallbackSuccess = e,
                this.videoCallbackFaile = n,
                window.tt ? TouTiaoTools.videoAd.show().then(function() {
                    return console.log("激励视频 广告显示")
                }).catch(function() {
                    TouTiaoTools.videoAd.load().then(function() {
                        return TouTiaoTools.videoAd.show()
                    }).catch(function(e) {
                        console.log("激励视频 广告显示失败"),
                        tt.showToast({
                            title: "广告加载失败,请稍后重试！",
                            icon: "none",
                            duration: 1e3,
                            success: function(e) {
                                console.log("".concat(e))
                            },
                            fail: function(e) {
                                console.log("showToast 调用失败")
                            }
                        })
                    })
                }) : TouTiaoTools.AdSuccess()
            },
            showShare: function() {
                if (window.tt) {
                    console.log("sdk share page....");
                    var e = TouTiaoTools.getShareData();
                    if (!e || void 0 === e.title)
                        return console.log("sdk share page....no data"),
                        !1;
                    tt.showShareMenu({
                        withShareTicket: !0
                    }),
                    tt.onShareAppMessage(function() {
                        return e
                    })
                }
            },
            moreGame: function() {
                "ios" !== tt.getSystemInfoSync().platform ? tt.showMoreGamesModal({
                    appLaunchOptions: [{
                        appId: "",
                        query: "",
                        extraData: {}
                    }],
                    success: function(e) {
                        console.log("success", e.errMsg)
                    },
                    fail: function(e) {
                        console.log("fail", e.errMsg)
                    }
                }) : tt.showToast({
                    title: "iOS不支持此功能"
                })
            },
            getShareData: function() {
                return TouTiaoTools._randomShareDatas[0]
            },
            _randomShareDatas: [],
            showBanner: function() {},
            hideBanner: function() {
                window.tt && (console.log("hide banner"),
                TouTiaoTools.GAME_QQ_BANNER && (TouTiaoTools.GAME_QQ_BANNER.destroy(),
                TouTiaoTools.GAME_QQ_BANNER = null))
            },
            share_successF: null,
            share_failF: null,
            GAME_SHARE_NOW: !1,
            share_startTime: 0,
            share_MaxTime: 0,
            Game_InScene: !1,
            GAME_QQ_BANNER: null,
            GAME_SET_BANNER: null,
            GAME_CESHI_BANNER: null,
            recorder: null,
            shareTo: function() {
                window.tt && tt.shareAppMessage({
                    templateId: "d8kcs176ro73ipnrqg",
                    query: "",
                    success: function() {
                        console.log("分享成功")
                    },
                    fail: function(e) {
                        console.log("分享失败")
                    }
                })
            },
            initQQShow: function() {
                if (window.tt) {
                    window.ServerConfigBd = window.GameConfig,
                    setInterval(function() {
                        TouTiaoTools.showChaPing()
                    }, 4e4),
                    setInterval(function() {
                        TouTiaoTools.showBanner()
                    }, 1e4),
                    TouTiaoTools.recorder = tt.getGameRecorderManager(),
                    tt.createRewardedVideoAd && (TouTiaoTools.videoAd = tt.createRewardedVideoAd({
                        adUnitId: TouTiaoTools.videoID
                    }),
                    TouTiaoTools.videoAd.load(),
                    TouTiaoTools.videoAd.onClose(function(e) {
                        1 == e.isEnded ? TouTiaoTools.AdSuccess() : window.ServerConfigBd.showModal ? tt.showModal({
                            title: "未观看完视频",
                            content: "观看完视频才能获得奖励哦",
                            success: function(e) {
                                e.confirm ? TouTiaoTools.videoAd.show().then(function() {
                                    return console.log("激励视频 广告显示")
                                }).catch(function() {
                                    TouTiaoTools.videoAd.load().then(function() {
                                        return TouTiaoTools.videoAd.show()
                                    }).catch(function(e) {
                                        console.log("激励视频 广告显示失败"),
                                        tt.showToast({
                                            title: "广告加载失败,请稍后重试！",
                                            icon: "none",
                                            duration: 1e3,
                                            success: function(e) {
                                                console.log("".concat(e))
                                            },
                                            fail: function(e) {
                                                console.log("showToast 调用失败")
                                            }
                                        })
                                    })
                                }) : (e.cancel,
                                TouTiaoTools.AdFaile(),
                                tt.showToast({
                                    title: "未观看完整视频！",
                                    icon: "none",
                                    duration: 1e3,
                                    success: function(e) {
                                        console.log("".concat(e))
                                    },
                                    fail: function(e) {
                                        console.log("showToast调用失败")
                                    }
                                }))
                            },
                            fail: function(e) {
                                console.log("showModal调用失败"),
                                TouTiaoTools.AdFaile(),
                                tt.showToast({
                                    title: "未观看完整视频！",
                                    icon: "none",
                                    duration: 1e3,
                                    success: function(e) {
                                        console.log("".concat(e))
                                    },
                                    fail: function(e) {
                                        console.log("showToast调用失败")
                                    }
                                })
                            }
                        }) : (TouTiaoTools.AdFaile(),
                        tt.showToast({
                            title: "未观看完整视频！",
                            icon: "none",
                            duration: 1e3,
                            success: function(e) {
                                console.log("".concat(e))
                            },
                            fail: function(e) {
                                console.log("showToast调用失败")
                            }
                        }))
                    })),
                    TouTiaoTools.showShare();
                    var e = window.GlobData.sceneIDTrue();
                    console.log("a:" + e),
                    window.GlobData.sceneIDTrue() ? (console.log("陈宫"),
                    TouTiaoTools.KaipingVideo()) : console.log("失败-----")
                }
            },
            showChaPing: function() {
                window.tt && window.ServerConfigBd.showChaping && TouTiaoTools.showChaPing1()
            },
            canReTry: !0,
            showChaPing1: function() {
                console.log("-- TT 触发插屏"),
                TouTiaoTools.interstitialAd = tt.createInterstitialAd({
                    adUnitId: TouTiaoTools.chapingID
                }),
                TouTiaoTools.interstitialAd.load().then(function() {
                    TouTiaoTools.interstitialAd.show().then(function() {
                        console.log("-- TT 展示插屏广告成功！")
                    }).catch(function(e) {
                        console.error("-- TT 展示插屏广告失败！err =", e)
                    })
                }).catch(function(e) {
                    console.error("-- TT 加载插屏广告失败,err =", e)
                })
            },
            AdSuccess: function() {
                null != TouTiaoTools.videoCallbackSuccess && (TouTiaoTools.videoCallbackSuccess(),
                TouTiaoTools.videoCallbackSuccess = null)
            },
            AdFaile: function() {
                null != TouTiaoTools.videoCallbackFaile && (TouTiaoTools.videoCallbackFaile(),
                TouTiaoTools.videoCallbackFaile = null)
            },
            startTime: 0,
            endTime: 0,
            luzhiKaishi: function() {
                window.tt && (TouTiaoTools.recorder.stop(),
                tt.onShow(function(e) {
                    TouTiaoTools.recorder.resume()
                }),
                tt.onHide(function() {
                    TouTiaoTools.recorder.pause()
                }),
                TouTiaoTools.recorder.onStart(function(e) {}),
                TouTiaoTools.overvideo = !1,
                setTimeout(TouTiaoTools.startLuzhi, 300))
            },
            startLuzhi: function() {
                window.tt && (console.log("录屏开始"),
                TouTiaoTools.recorder.start({
                    duration: 6e4
                }),
                TouTiaoTools.startTime = (new Date).getTime())
            },
            videoPath: "",
            overvideo: !1,
            GaiLv: function(e) {
                var n = 1 + Math.floor(100 * Math.random());
                return console.log("当前概率为:" + n),
                n <= e
            },
            IS_VIDEO: !1,
            luzhijieshu: function() {
                window.tt && (console.log("luzhijieshu"),
                tt.offShow(function() {}),
                tt.offHide(function() {}),
                TouTiaoTools.recorder.stop(),
                TouTiaoTools.endTime = (new Date).getTime(),
                TouTiaoTools.recorder.onStop(function(e) {
                    TouTiaoTools.videoPath = e.videoPath,
                    console.log("录屏结束：" + e.videoPath),
                    TouTiaoTools.overvideo = !0
                }))
            },
            randomsharelp: function() {
                console.log("当前随机视频的概率为" + window.ServerConfigBd.randomShare),
                TouTiaoTools.GaiLv(window.ServerConfigBd.randomShare) && TouTiaoTools.fenxiangVideo(null, null)
            },
            fenxiangVideo: function(e, n) {
                if (window.tt) {
                    if (TouTiaoTools.endTime - TouTiaoTools.startTime <= 3500)
                        return console.log("fenxiang meiyoushipin"),
                        tt.showToast({
                            title: "录屏时间少于3秒,分享失败!",
                            icon: "none",
                            duration: 1e3,
                            success: function(e) {
                                console.log("".concat(e))
                            },
                            fail: function(e) {
                                console.log("showToast调用失败")
                            }
                        }),
                        void (n && n());
                    console.log("fenxiang shipin"),
                    tt.shareAppMessage({
                        templateId: TouTiaoTools.ShareID,
                        channel: "video",
                        title: "点击这里，开始游戏！",
                        desc: TouTiaoTools.ShareDataTitle,
                        extra: {
                            videoPath: TouTiaoTools.videoPath,
                            videoTopics: ["小游戏", TouTiaoTools.AppName, TouTiaoTools.ShareDataTitle]
                        },
                        success: function() {
                            console.log("分享视频成功111"),
                            tt.showToast({
                                title: "分享成功",
                                icon: "none",
                                duration: 1e3,
                                success: function(e) {
                                    console.log("".concat(e))
                                },
                                fail: function(e) {
                                    console.log("showToast调用失败")
                                }
                            }),
                            e && e()
                        },
                        fail: function(e) {
                            console.log(e),
                            tt.showToast({
                                title: "分享失败",
                                icon: "none",
                                duration: 1e3,
                                success: function(e) {
                                    console.log("".concat(e))
                                },
                                fail: function(e) {
                                    console.log("showToast调用失败")
                                }
                            }),
                            n && n(),
                            console.log("分享视频失败")
                        }
                    })
                }
            }
        },
        cc._RF.pop()
    }
    , {}],
    TweenClass: [function(e, n, a) {
        "use strict";
        function o(e) {
            "@babel/helpers - typeof";
            return (o = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                return typeof e
            }
            : function(e) {
                return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
            }
            )(e)
        }
        function i(e, n) {
            if (!(e instanceof n))
                throw new TypeError("Cannot call a class as a function")
        }
        function t(e, n) {
            for (var a = 0; a < n.length; a++) {
                var o = n[a];
                o.enumerable = o.enumerable || !1,
                o.configurable = !0,
                "value"in o && (o.writable = !0),
                Object.defineProperty(e, o.key, o)
            }
        }
        function r(e, n, a) {
            return n && t(e.prototype, n),
            a && t(e, a),
            e
        }
        function c(e, n) {
            if ("function" != typeof n && null !== n)
                throw new TypeError("Super expression must either be null or a function");
            e.prototype = Object.create(n && n.prototype, {
                constructor: {
                    value: e,
                    writable: !0,
                    configurable: !0
                }
            }),
            n && d(e, n)
        }
        function d(e, n) {
            return (d = Object.setPrototypeOf || function(e, n) {
                return e.__proto__ = n,
                e
            }
            )(e, n)
        }
        function s(e) {
            var n = m();
            return function() {
                var a, o = f(e);
                if (n) {
                    var i = f(this).constructor;
                    a = Reflect.construct(o, arguments, i)
                } else
                    a = o.apply(this, arguments);
                return l(this, a)
            }
        }
        function l(e, n) {
            return !n || "object" !== o(n) && "function" != typeof n ? x(e) : n
        }
        function x(e) {
            if (void 0 === e)
                throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return e
        }
        function m() {
            if ("undefined" == typeof Reflect || !Reflect.construct)
                return !1;
            if (Reflect.construct.sham)
                return !1;
            if ("function" == typeof Proxy)
                return !0;
            try {
                return Date.prototype.toString.call(Reflect.construct(Date, [], function() {})),
                !0
            } catch (e) {
                return !1
            }
        }
        function f(e) {
            return (f = Object.setPrototypeOf ? Object.getPrototypeOf : function(e) {
                return e.__proto__ || Object.getPrototypeOf(e)
            }
            )(e)
        }
        cc._RF.push(n, "dc9edbBf81IBZTIJQuci4ND", "TweenClass"),
        Object.defineProperty(a, "__esModule", {
            value: !0
        }),
        a.TweenClass = void 0;
        var y = new (function(e) {
            c(a, cc.Component);
            var n = s(a);
            function a() {
                return i(this, a),
                n.apply(this, arguments)
            }
            return r(a, [{
                key: "shake_Tween",
                value: function(e) {
                    var n = e.position.x
                      , a = e.position.y
                      , o = cc.tween().to(.018, {
                        position: cc.v2(n + 10, a + 12)
                    }, {
                        easing: "smooth"
                    }).to(.018, {
                        position: cc.v2(n + 6, a + 6)
                    }, {
                        easing: "smooth"
                    }).to(.018, {
                        position: cc.v2(n + 6, a - 6)
                    }, {
                        easing: "smooth"
                    }).to(.018, {
                        position: cc.v2(n - 6, a + 6)
                    }, {
                        easing: "smooth"
                    }).to(.018, {
                        position: cc.v2(n - 6, a - 6)
                    }, {
                        easing: "smooth"
                    }).to(.018, {
                        position: cc.v2(n + 5, a + 5)
                    }, {
                        easing: "smooth"
                    }).to(.018, {
                        position: cc.v2(n + 10, a + 12)
                    }, {
                        easing: "smooth"
                    }).to(.018, {
                        position: cc.v2(n + 6, a + 6)
                    }, {
                        easing: "smooth"
                    }).to(.018, {
                        position: cc.v2(n + 6, a - 6)
                    }, {
                        easing: "smooth"
                    }).to(.018, {
                        position: cc.v2(n - 6, a + 6)
                    }, {
                        easing: "smooth"
                    }).to(.018, {
                        position: cc.v2(n - 6, a - 6)
                    }, {
                        easing: "smooth"
                    }).to(.018, {
                        position: cc.v2(n + 5, a + 5)
                    }, {
                        easing: "smooth"
                    }).call(function() {}).delay(3);
                    cc.tween(e).delay(1).repeatForever(o).start()
                }
            }, {
                key: "scale_Tween",
                value: function(e) {
                    var n = cc.tween().to(.5, {
                        scale: 1.2
                    }, {
                        easing: "bounceOut"
                    }).to(.5, {
                        scale: 1
                    }, {
                        easing: "backOut"
                    }).delay(2);
                    cc.tween(e).delay(1).repeatForever(n).start()
                }
            }, {
                key: "scale_2_Tween",
                value: function(e) {
                    var n = cc.tween().to(.5, {
                        scale: 1.1
                    }, {
                        easing: "smooth"
                    }).to(.5, {
                        scale: 1
                    }, {
                        easing: "smooth"
                    });
                    cc.tween(e).repeatForever(n).start()
                }
            }, {
                key: "scale_3_Tween",
                value: function(e) {
                    e.scale = 0,
                    cc.tween(e).delay(.5).to(.2, {
                        scale: 1
                    }, {
                        easing: "backOut"
                    }).start()
                }
            }, {
                key: "scale_3_1_Tween",
                value: function(e) {
                    e.scale = 0,
                    cc.tween(e).to(.2, {
                        scale: 1
                    }, {
                        easing: "backOut"
                    }).start()
                }
            }, {
                key: "scale_4_Tween",
                value: function(e) {
                    var n = e.position;
                    e.position = cc.v2(0, 1e3),
                    cc.tween(e).to(.5, {
                        position: n
                    }, {
                        easing: "bounceOut"
                    }).start()
                }
            }, {
                key: "scale_5_Tween",
                value: function(e) {
                    e.scale = 0,
                    cc.tween(e).to(.2, {
                        scale: 1
                    }, {
                        easing: "backOut"
                    }).delay(.5).to(.2, {
                        scale: 0
                    }, {
                        easing: "smooth"
                    }).start()
                }
            }, {
                key: "scale_close_Tween",
                value: function(e) {
                    cc.tween(e).to(.4, {
                        scale: 0
                    }, {
                        easing: "smooth"
                    }).call(function() {
                        e.parent.removeFromParent()
                    }).start()
                }
            }, {
                key: "opacity_Tween",
                value: function(e) {
                    e.opacity = 255,
                    cc.tween(e).to(.8, {
                        opacity: 0
                    }, {
                        easing: "smooth"
                    }).start()
                }
            }, {
                key: "opacity_2_Tween",
                value: function(e, n) {
                    cc.tween(e).to(.8, {
                        opacity: 255
                    }, {
                        easing: "smooth"
                    }).call(function() {
                        cc.director.loadScene(n)
                    }).start()
                }
            }]),
            a
        }());
        a.TweenClass = y,
        cc._RF.pop()
    }
    , {}],
    UserYinsi: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "c5860p0Fn9JNrVBgneeOvPI", "UserYinsi"),
        cc.Class({
            extends: cc.Component,
            properties: {
                userkuang: cc.Node,
                erciTanchuang: cc.Node,
                onButtonJieMian: cc.Node
            },
            start: function() {
                window.qg || window.qq ? this.jiance() : this.node.active = !1
            },
            jiance: function() {
                var e = cc.sys.localStorage.getItem("user");
                console.log("item" + e),
                void 0 == e || null == e || 0 == e.length ? (console.log("新用户"),
                this.node.getChildByName("item").active = !0) : (console.log("老用户"),
                this.node.getChildByName("item").active = !1)
            },
            onShow: function() {
                this.node.getChildByName("item").active = !0,
                this.onButtonJieMian.getChildByName("btn_ty").active = !1,
                this.onButtonJieMian.getChildByName("btn_bty").active = !1,
                this.onButtonJieMian.getChildByName("btn_Close").active = !0
            },
            onBtnClickEvent: function(e) {
                var n = e.target.name;
                switch (console.log("点击了"),
                n) {
                case "btn_ty":
                    cc.sys.localStorage.setItem("user", 1),
                    this.node.getChildByName("item").active = !1;
                    break;
                case "btn_bty2":
                    cc.game.end(),
                    this.node.getChildByName("item").active = !1;
                    break;
                case "btn_bty":
                    window.qq ? qq.exitMiniProgram() : this.erciTanchuang.active = !0;
                    break;
                case "btn_Close":
                    this.node.getChildByName("item").active = !1;
                    break;
                case "btn_queding":
                    this.erciTanchuang.active = !1
                }
            }
        }),
        cc._RF.pop()
    }
    , {}],
    Utils: [function(e, n, a) {
        "use strict";
        function o(e, n) {
            if (!(e instanceof n))
                throw new TypeError("Cannot call a class as a function")
        }
        function i(e, n) {
            for (var a = 0; a < n.length; a++) {
                var o = n[a];
                o.enumerable = o.enumerable || !1,
                o.configurable = !0,
                "value"in o && (o.writable = !0),
                Object.defineProperty(e, o.key, o)
            }
        }
        function t(e, n, a) {
            return n && i(e.prototype, n),
            a && i(e, a),
            e
        }
        cc._RF.push(n, "6a1bfqH5a9FrIit0gICk1ex", "Utils"),
        Object.defineProperty(a, "__esModule", {
            value: !0
        }),
        a.MouseMgr = a.SoundMgr = a.AssMgr = a.MathMgr = void 0;
        var r = function() {
            function e() {
                o(this, e)
            }
            return t(e, [{
                key: "getRandomNum",
                value: function(e, n) {
                    var a = n - e
                      , o = Math.random();
                    return e + Math.round(o * a)
                }
            }, {
                key: "getTwoVectorDegree",
                value: function(e, n) {
                    var a = n.x - e.x
                      , o = n.y - e.y
                      , i = Math.atan2(o, a);
                    return cc.misc.radiansToDegrees(i) - 90
                }
            }]),
            e
        }()
          , c = function() {
            function e() {
                o(this, e),
                this.soundList = [],
                this.soundPathList = []
            }
            return t(e, [{
                key: "registerSoundPath",
                value: function(e) {
                    this.soundPathList = e
                }
            }, {
                key: "playMusic",
                value: function(e) {
                    for (var n = this, a = function(e) {
                        return cc.audioEngine.playMusic(e, !0)
                    }, o = 0; o < this.soundList.length; o++) {
                        var i = this.soundList[o];
                        if (i.name === e)
                            return a(i)
                    }
                    for (var t = 0; t < this.soundPathList.length; t++) {
                        var r = this.soundPathList[t];
                        if (r.indexOf(e) >= 0) {
                            cc.loader.loadRes(r, cc.AudioClip, function(e, o) {
                                return n.soundList.push(o),
                                a(o)
                            });
                            break
                        }
                    }
                }
            }, {
                key: "stopMusic",
                value: function() {
                    cc.audioEngine.stopMusic()
                }
            }, {
                key: "playEffect",
                value: function(e) {
                    for (var n = this, a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null, o = function(e) {
                        var n = cc.audioEngine.playEffect(e, !1);
                        return a && cc.audioEngine.setFinishCallback(n, a),
                        n
                    }, i = 0; i < this.soundList.length; i++) {
                        var t = this.soundList[i];
                        if (t.name === e)
                            return o(t)
                    }
                    for (var r = 0; r < this.soundPathList.length; r++) {
                        var c = this.soundPathList[r];
                        if (c.indexOf(e) >= 0) {
                            cc.loader.loadRes(c, cc.AudioClip, function(e, a) {
                                return n.soundList.push(a),
                                o(a)
                            });
                            break
                        }
                    }
                }
            }]),
            e
        }()
          , d = function() {
            function e() {
                o(this, e),
                this.frameList = [],
                this.framePathList = [],
                this.textureList = [],
                this.texturePathList = [],
                this.prefabList = [],
                this.prefabPathList = []
            }
            return t(e, [{
                key: "registerSpriteFramePath",
                value: function(e) {
                    this.framePathList = e
                }
            }, {
                key: "registerTexturePath",
                value: function(e) {
                    this.texturePathList = e
                }
            }, {
                key: "registerPrefabPath",
                value: function(e) {
                    this.prefabPathList = e
                }
            }, {
                key: "setSpriteFrameByName",
                value: function(e, n, a) {
                    var o = this;
                    if (e instanceof cc.Sprite) {
                        for (var i = !1, t = 0; t < this.frameList.length; t++) {
                            var r = this.frameList[t];
                            if (r.name === n)
                                return e.spriteFrame = r,
                                a && a(),
                                i = !0
                        }
                        for (var c = 0; c < this.framePathList.length; c++) {
                            var d = this.framePathList[c]
                              , s = d.split("/");
                            if (s[s.length - 1] === n)
                                return cc.loader.loadRes(d, cc.SpriteFrame, function(n, i) {
                                    o.frameList.push(i),
                                    e.spriteFrame = i,
                                    a && a()
                                }),
                                i = !0
                        }
                        return i
                    }
                    console.warn("无效的Sprite类型")
                }
            }, {
                key: "setSpriteFrameByTexture",
                value: function(e, n, a) {
                    var o = this;
                    if (e instanceof cc.Sprite) {
                        for (var i = 0; i < this.textureList.length; i++) {
                            var t = this.textureList[i];
                            if (t.name === "".concat(n, ".plist"))
                                return void (e.spriteFrame = t.getSpriteFrame(a))
                        }
                        for (var r = 0; r < this.texturePathList.length; r++) {
                            var c = this.texturePathList[r];
                            if (c.indexOf(n) >= 0) {
                                cc.loader.loadRes(c, cc.SpriteAtlas, function(n, i) {
                                    o.textureList.push(i),
                                    e.spriteFrame = i.getSpriteFrame(a)
                                });
                                break
                            }
                        }
                    } else
                        console.warn("无效的Sprite类型")
                }
            }, {
                key: "createPrefabByName",
                value: function(e, n) {
                    for (var a = this, o = 0; o < this.prefabList.length; o++) {
                        var i = this.prefabList[o];
                        if (i.name === e)
                            return void (n && n(i))
                    }
                    for (var t = 0; t < this.prefabPathList.length; t++) {
                        var r = this.prefabPathList[t]
                          , c = r.split("/");
                        if ((c = c[c.length - 1]) === e) {
                            cc.loader.loadRes(r, cc.Prefab, function(e, o) {
                                a.prefabList.push(o),
                                n && n(o)
                            });
                            break
                        }
                    }
                }
            }, {
                key: "setDragonBones",
                value: function(e, n, a) {
                    var o = e.getComponent(dragonBones.ArmatureDisplay)
                      , i = "App/Skeleton/person/gq_" + n + "/gq_" + n + "_" + a + "_ske"
                      , t = "App/Skeleton/person/gq_" + n + "/gq_" + n + "_" + a + "_tex";
                    cc.loader.loadRes(t, dragonBones.DragonBonesAtlasAsset, function(e, t) {
                        e ? console.log("err=", e) : (o.dragonAtlasAsset = t,
                        cc.loader.loadRes(i, dragonBones.DragonBonesAsset, function(e, i) {
                            e ? console.log("err=", e) : (o.dragonAsset = i,
                            o.armatureName = "gq_" + n + "_" + a,
                            o.playAnimation("donghua", 1))
                        }))
                    })
                }
            }]),
            e
        }()
          , s = function() {
            function e() {
                o(this, e)
            }
            return t(e, [{
                key: "clickStartMoveEnd",
                value: function(e) {
                    var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null
                      , a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null
                      , o = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null
                      , i = function(e) {
                        o && (window.CuontError += 1,
                        o(e))
                    };
                    e.on(cc.Node.EventType.TOUCH_START, function(e) {
                        n && (x.playEffect("BrushMovePoc"),
                        n(e))
                    }, this),
                    e.on(cc.Node.EventType.TOUCH_MOVE, function(e) {
                        a && a(e)
                    }, this),
                    e.on(cc.Node.EventType.TOUCH_END, i, this),
                    e.on(cc.Node.EventType.TOUCH_CANCEL, i, this)
                }
            }]),
            e
        }()
          , l = new d;
        a.AssMgr = l;
        var x = new c;
        a.SoundMgr = x;
        var m = new r;
        a.MathMgr = m;
        var f = new s;
        a.MouseMgr = f,
        cc._RF.pop()
    }
    , {}],
    _4399: [function(e, n, a) {
        "use strict";
        function o(e, n) {
            if (!(e instanceof n))
                throw new TypeError("Cannot call a class as a function")
        }
        cc._RF.push(n, "5e983Sn7etDCpyQZttTYdWn", "_4399"),
        Object.defineProperty(a, "__esModule", {
            value: !0
        }),
        a.youjia = void 0;
        a.youjia = function e(n, a) {
            o(this, e)
        }
        ,
        cc._RF.pop()
    }
    , {}],
    _UC: [function(e, n, a) {
        "use strict";
        function o(e, n) {
            if (!(e instanceof n))
                throw new TypeError("Cannot call a class as a function")
        }
        function i(e, n) {
            for (var a = 0; a < n.length; a++) {
                var o = n[a];
                o.enumerable = o.enumerable || !1,
                o.configurable = !0,
                "value"in o && (o.writable = !0),
                Object.defineProperty(e, o.key, o)
            }
        }
        function t(e, n, a) {
            return n && i(e.prototype, n),
            a && i(e, a),
            e
        }
        cc._RF.push(n, "5dcd57O2mlK6rC/6LtjESpB", "_UC"),
        Object.defineProperty(a, "__esModule", {
            value: !0
        }),
        a._UC = void 0;
        var r = function() {
            function e(n, a) {
                o(this, e),
                this.SystemInformation = null,
                this.BannerInstance = null,
                this.VideoInstance = null,
                this.VideoSuccessCallBack = null,
                this.VideoFailureCallBack = null,
                this.InterstitialInstance = null,
                this.InterstitialTimer = null
            }
            return t(e, [{
                key: "doInitialize",
                value: function() {
                    console.log("初始化uc"),
                    self = this,
                    self.SystemInformation = uc.getSystemInfoSync()
                }
            }, {
                key: "showBanner",
                value: function(e) {
                    console.log("ucbanner"),
                    this.BannerInstance && (this.BannerInstance.destroy(),
                    this.BannerInstance = null);
                    var n = uc.getSystemInfoSync();
                    if ("string" == typeof n)
                        try {
                            n = JSON.parse(n),
                            console.log("res111111::" + n)
                        } catch (e) {
                            console.log("res::" + n)
                        }
                    var a = (n.screenWidth > n.screenHeight ? n.screenHeight : n.screenWidth) / 2
                      , o = 194 * a / 345;
                    this.BannerInstance = uc.createBannerAd({
                        style: {
                            width: a,
                            height: o,
                            gravity: 7
                        }
                    }),
                    this.BannerInstance.onError(function(e) {
                        console.log("bannerAd 广告加载出错", e)
                    }),
                    this.BannerInstance.onLoad(function() {
                        console.log("bannerAd 广告加载成功")
                    }),
                    this.BannerInstance.show(),
                    e && this.executeJieSuanChaPing()
                }
            }, {
                key: "showInterstitial",
                value: function() {
                    this.executeJieSuanChaPing()
                }
            }, {
                key: "executeJieSuanChaPing",
                value: function() {
                    console.log("uc插屏"),
                    this.InterstitialInstance = uc.createInterstitialAd(),
                    this.InterstitialInstance.show().then(function() {
                        return console.log("展示成功")
                    }).catch(function(e) {
                        return console.log(e)
                    }),
                    this.InterstitialInstance.onLoad(function() {
                        console.log("插屏-广告加载成功")
                    }),
                    this.InterstitialInstance.onError(function(e) {
                        console.log("插屏-广告加载失败", e)
                    }),
                    this.InterstitialInstance.onClose(function(e) {
                        console.log("插屏-关闭")
                    })
                }
            }, {
                key: "executeShowAwardVideo",
                value: function(e, n) {
                    var a = this;
                    this.VideoSuccessCallBack = e,
                    this.VideoFailureCallBack = n,
                    this.VideoInstance = uc.createRewardVideoAd(),
                    this.VideoInstance.show().then().catch(function(e) {
                        return console.log(e)
                    }),
                    this.VideoInstance.onLoad(function() {
                        console.log("激励视频-广告加载成功")
                    }),
                    this.VideoInstance.onError(function(e) {
                        console.log("激励视频-广告加载失败", e)
                    }),
                    this.VideoInstance.onClose(function(e) {
                        e && e.isEnded ? (a.videoDisplaySuccessCallBack(),
                        console.log("正常播放结束，可以下发游戏奖励 res: ", e)) : (console.log("播放中途退出，不下发游戏奖励 res :", e),
                        a.videoDisplayFailureCallBack()),
                        a.VideoInstance && (a.VideoInstance.offClose(),
                        a.VideoInstance.offLoad(),
                        a.VideoInstance.offError())
                    })
                }
            }, {
                key: "videoDisplaySuccessCallBack",
                value: function() {
                    null != this.VideoSuccessCallBack && (this.VideoSuccessCallBack(),
                    this.VideoSuccessCallBack = null)
                }
            }, {
                key: "videoDisplayFailureCallBack",
                value: function() {
                    null != this.VideoFailureCallBack && (this.VideoFailureCallBack(),
                    this.VideoFailureCallBack = null)
                }
            }]),
            e
        }();
        a._UC = r,
        cc._RF.pop()
    }
    , {}],
    _baidu: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "37c552uPW9KrYDruO+CclJX", "_baidu"),
        Object.defineProperty(a, "__esModule", {
            value: !0
        }),
        a.baidu = void 0;
        var o = e("./PlatformUtils");
        function i(e, n) {
            if (!(e instanceof n))
                throw new TypeError("Cannot call a class as a function")
        }
        function t(e, n) {
            for (var a = 0; a < n.length; a++) {
                var o = n[a];
                o.enumerable = o.enumerable || !1,
                o.configurable = !0,
                "value"in o && (o.writable = !0),
                Object.defineProperty(e, o.key, o)
            }
        }
        function r(e, n, a) {
            return n && t(e.prototype, n),
            a && t(e, a),
            e
        }
        var c = function() {
            function e(n, a) {
                var o = this;
                i(this, e),
                this.Banner = null,
                this.Box = null,
                this.Video = null,
                this.ServerConfig = n,
                this.CodeList = a,
                this.ServerConfig.isLine && this.ServerConfig.iconList.length >= 10 ? (cc.loader.loadRes("Platform/Prefabs/LandscapeBanner", cc.Prefab, function(e, n) {
                    o.Banner = cc.instantiate(n),
                    o.Banner.zIndex = 99999,
                    cc.game.addPersistRootNode(o.Banner);
                    for (var a = [], i = 0; i < o.ServerConfig.iconList.length; i++) {
                        var t = {
                            url: o.ServerConfig.iconList[i],
                            package: o.ServerConfig.packageList[i]
                        };
                        a.push(t)
                    }
                    o.Banner.getComponent("LandscapeBanner").instantiation(a)
                }),
                cc.loader.loadRes("Platform/Prefabs/BoxHotWindow", cc.Prefab, function(e, n) {
                    o.Box = cc.instantiate(n),
                    o.Box.zIndex = 99998,
                    cc.game.addPersistRootNode(o.Box);
                    for (var a = [], i = 0; i < o.ServerConfig.iconList.length; i++) {
                        var t = {
                            url: o.ServerConfig.iconList[i],
                            package: o.ServerConfig.packageList[i]
                        };
                        a.push(t)
                    }
                    o.Box.getComponent("BoxHotWindow").instantiation(a)
                })) : (this.Banner = null,
                this.Box = null),
                this.Video = window.swan.createRewardedVideoAd({
                    adUnitId: this.CodeList.videoCode,
                    appSid: this.CodeList.appSID
                }),
                this.Video.onClose(function(e) {
                    e.isEnded ? o.executeVideoSuccessCallBack() : o.ServerConfig.isLine && o.ServerConfig.allowShowModal ? window.swan.showModal({
                        title: "提示",
                        content: "未观看完视频，是否继续？",
                        success: function(e) {
                            e.cancel ? o.executeVideoFailureCallBack() : e.confirm && o.Video.load().then(function() {
                                console.log("拉取视频广告成功, 等待显示!!"),
                                o.Video.show().then(function() {
                                    console.log("视频广告成功显示~~~~")
                                }).catch(function(e) {
                                    console.log("视频广告成功失败:", e),
                                    o.executeShowToast("视频组件显示失败，请稍后再试！")
                                })
                            }).catch(function(e) {
                                console.error("拉取视频广告失败:", e),
                                o.executeShowToast("视频组件加载失败，请稍后再试！")
                            })
                        },
                        fail: function(e) {
                            o.executeVideoFailureCallBack()
                        }
                    }) : o.executeVideoFailureCallBack()
                })
            }
            return r(e, [{
                key: "showBanner",
                value: function() {
                    this.Banner && (this.Banner.active || (this.Banner.active = !0))
                }
            }, {
                key: "hideBanner",
                value: function() {
                    this.Banner && (this.Banner.active = !1)
                }
            }, {
                key: "showMoreGames",
                value: function() {
                    this.Box && (this.Box.active = !0)
                }
            }, {
                key: "showVideo",
                value: function(e, n) {
                    var a = this;
                    this.video_success = e,
                    this.video_failure = n,
                    cc.audioEngine.pauseAll(),
                    cc.director.pause(),
                    this.Video.load().then(function() {
                        console.log("广告加载成功, 开始显示广告"),
                        a.Video.show().catch(function(e) {
                            a.Video.load().then(function() {
                                return a.Video.show()
                            }).catch(function(e) {
                                a.executeVideoFailureCallBack()
                            })
                        })
                    }).catch(function(e) {
                        a.executeVideoFailureCallBack()
                    })
                }
            }, {
                key: "fromToMiniProgram",
                value: function(e) {
                    window.swan.navigateToMiniProgram({
                        appKey: e,
                        path: "/path/page/0",
                        extraData: {
                            from: o.App.ChineseName
                        },
                        success: function() {},
                        fail: function(e) {}
                    })
                }
            }, {
                key: "executeShowToast",
                value: function(e) {
                    window.swan.showToast({
                        title: e,
                        duration: 1500
                    })
                }
            }, {
                key: "executeVideoSuccessCallBack",
                value: function() {
                    cc.director.resume(),
                    cc.audioEngine.resumeAll(),
                    this.video_success && this.video_success(),
                    this.video_success = null
                }
            }, {
                key: "executeVideoFailureCallBack",
                value: function() {
                    cc.director.resume(),
                    cc.audioEngine.resumeAll(),
                    this.video_failure && this.video_failure(),
                    this.video_failure = null
                }
            }]),
            e
        }();
        a.baidu = c,
        cc._RF.pop()
    }
    , {
        "./PlatformUtils": "PlatformUtils"
    }],
    _bytedance: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "26fe70UYvxDNLSPU+VBu8uP", "_bytedance"),
        Object.defineProperty(a, "__esModule", {
            value: !0
        }),
        a.bytedance = void 0;
        var o = e("./PlatformUtils")
          , i = e("../../Scripts/Utils");
        function t(e, n) {
            if (!(e instanceof n))
                throw new TypeError("Cannot call a class as a function")
        }
        function r(e, n) {
            for (var a = 0; a < n.length; a++) {
                var o = n[a];
                o.enumerable = o.enumerable || !1,
                o.configurable = !0,
                "value"in o && (o.writable = !0),
                Object.defineProperty(e, o.key, o)
            }
        }
        function c(e, n, a) {
            return n && r(e.prototype, n),
            a && r(e, a),
            e
        }
        var d = function() {
            function e(n, a) {
                var o = this;
                t(this, e),
                this.Device = null,
                this.Video = null,
                this.Banner = null,
                this.Interstitial = null,
                this.Recorder = null,
                this.RecorderPath = "",
                this.StartRecorderTime = null,
                this.EndRecorderTime = null,
                this.video_success = null,
                this.video_failure = null,
                this.share_success = null,
                this.share_failure = null,
                this.ServerConfig = n,
                this.CodeList = a,
                this.Device = window.tt.getSystemInfoSync(),
                window.tt.onShow(function(e) {
                    o.Recorder && o.Recorder.isRecording && o.Recorder.resume()
                }),
                window.tt.onHide(function() {
                    o.Recorder && o.Recorder.isRecording && o.Recorder.pause()
                }),
                this.Recorder = window.tt.getGameRecorderManager(),
                this.Recorder.onStop(function(e) {
                    o.RecorderPath = e.videoPath,
                    o.EndRecorderTime = (new Date).getTime(),
                    o.Recorder.isRecording = !1
                }),
                this.Video = window.tt.createRewardedVideoAd({
                    adUnitId: this.CodeList.videoCode
                }),
                this.Video.onClose(function(e) {
                    e.isEnded ? (console.log("视频广告播放完毕, 开始下发奖励!!"),
                    o.executeVideoSuccessCallBack()) : o.ServerConfig.allowShowModal && o.ServerConfig.isLine ? (console.log("视频广告未播放完毕, 准备二次询问用户!!"),
                    window.tt.showModal({
                        title: "提示",
                        content: "未观看完视频，是否继续？",
                        success: function(e) {
                            e.cancel ? o.executeVideoFailureCallBack() : e.confirm && o.Video.load().then(function() {
                                console.log("拉取视频广告成功, 等待显示!!"),
                                o.Video.show().then(function() {
                                    console.log("视频广告成功显示~~~~")
                                }).catch(function(e) {
                                    console.log("视频广告成功失败:", e),
                                    o.executeShowToast("视频组件显示失败，请稍后再试！")
                                })
                            }).catch(function(e) {
                                console.error("拉取视频广告失败:", e),
                                o.executeShowToast("视频组件加载失败，请稍后再试！")
                            })
                        },
                        fail: function(e) {
                            o.executeVideoFailureCallBack()
                        }
                    })) : o.executeVideoFailureCallBack()
                });
                var i = this;
                i.SystemInformation = window.tt.getSystemInfoSync();
                var r = tt.getSystemInfoSync()
                  , c = r.windowWidth
                  , d = r.windowHeight;
                i.BannerInstance = window.tt.createBannerAd({
                    adUnitId: i.CodeList.bannerCode,
                    style: {
                        left: (i.SystemInformation.windowWidth - 128) / 2,
                        top: i.SystemInformation.windowHeight - 128,
                        width: 128,
                        adIntervals: 30
                    }
                }),
                i.BannerInstance.onResize(function(e) {
                    0 != e.width && 0 != e.height && (console.log("size=", e),
                    i.BannerInstance.style.top = d - e.height,
                    i.BannerInstance.style.left = (c - e.width) / 2)
                }),
                i.BannerInstance.onError(function(e) {
                    console.log("toutiao banner onError= ", e)
                })
            }
            return c(e, [{
                key: "showVideo",
                value: function(e, n) {
                    var a = this;
                    cc.director.pause(),
                    cc.audioEngine.pauseAll(),
                    this.video_success = e,
                    this.video_failure = n,
                    this.Video.load().then(function() {
                        console.log("拉取视频广告成功, 等待显示!!"),
                        a.Video.show().then(function() {
                            console.log("视频广告成功显示~~~~")
                        }).catch(function(e) {
                            console.log("视频广告成功失败:", e),
                            a.executeShowToast("视频组件显示失败，请稍后再试！")
                        })
                    }).catch(function(e) {
                        console.error("拉取视频广告失败:", e),
                        a.executeShowToast("视频组件加载失败，请稍后再试！")
                    })
                }
            }, {
                key: "showBanner",
                value: function(e, n) {
                    this.BannerInstance.show()
                }
            }, {
                key: "hideBanner",
                value: function() {
                    console.log("隐藏banner"),
                    this.BannerInstance.hide()
                }
            }, {
                key: "showInterstitial",
                value: function() {
                    var e = this;
                    e.Interstitial && (e.Interstitial.destroy(),
                    e.Interstitial = null),
                    e.Interstitial = window.tt.createInterstitialAd({
                        adUnitId: e.CodeList.interstitialCode
                    }),
                    e.Interstitial.load().then(function() {
                        e.Interstitial.show().then(function() {}).catch(function(n) {
                            e.Interstitial.destroy(),
                            e.Interstitial = null
                        })
                    }).catch(function(n) {
                        console.error("-- TT 加载插屏广告失败,err =", n),
                        e.Interstitial.destroy(),
                        e.Interstitial = null
                    }),
                    e.Interstitial.onClose(function() {
                        e.Interstitial && (e.Interstitial = null)
                    })
                }
            }, {
                key: "startRecorder",
                value: function() {
                    var e = this;
                    if (this.Recorder) {
                        this.Recorder.isRecording && this.stopRecorder();
                        setTimeout(function() {
                            e.Recorder.start({
                                duration: 120
                            }),
                            e.StartRecorderTime = (new Date).getTime(),
                            console.log("开始录制, 开始时间:", e.StartRecorderTime)
                        }, 200)
                    } else
                        console.error("开始录制失败:无效的录制组件!!")
                }
            }, {
                key: "stopRecorder",
                value: function() {
                    this.Recorder ? this.Recorder.stop() : console.error("停止录制失败:无效的录制组件!!")
                }
            }, {
                key: "doShare",
                value: function(e, n) {
                    if (this.RecorderPath && "" !== this.RecorderPath)
                        if (this.EndRecorderTime - this.StartRecorderTime <= 3e3)
                            this.executeShowToast("视频时长过短,无法分享!");
                        else {
                            this.share_success = e,
                            this.share_failure = n;
                            var a = "";
                            if (this.ServerConfig.bgm.length > 0) {
                                var t = i.MathMgr.getRandomNum(0, this.ServerConfig.bgm.length - 1);
                                a = this.ServerConfig.bgm[t]
                            }
                            window.tt.shareAppMessage({
                                channel: "video",
                                title: "点击这里，开始游戏",
                                extra: {
                                    defaultBgm: a,
                                    videoPath: this.RecorderPath,
                                    videoTopics: ["小游戏", o.App.ChineseName, o.App.ShareLanguage]
                                },
                                success: function() {
                                    this.share_success && this.share_success()
                                },
                                fail: function(e) {
                                    this.share_failure && this.share_failure()
                                }
                            })
                        }
                    else
                        this.executeShowToast("视频录制失败!")
                }
            }, {
                key: "showMoreGames",
                value: function() {
                    "ios" !== this.Device.platform ? window.tt.showMoreGamesModal({
                        appLaunchOptions: [{
                            appId: this.CodeList.appId
                        }]
                    }) : this.executeShowToast("IOS暂不支持此功能")
                }
            }, {
                key: "executeShowToast",
                value: function(e) {
                    window.tt.showToast({
                        title: e,
                        duration: 1500
                    })
                }
            }, {
                key: "executeVideoSuccessCallBack",
                value: function() {
                    cc.director.resume(),
                    cc.audioEngine.resumeAll(),
                    this.video_success && this.video_success(),
                    this.video_success = null
                }
            }, {
                key: "executeVideoFailureCallBack",
                value: function() {
                    cc.director.resume(),
                    cc.audioEngine.resumeAll(),
                    this.video_failure && this.video_failure(),
                    this.video_failure = null
                }
            }]),
            e
        }();
        a.bytedance = d,
        cc._RF.pop()
    }
    , {
        "../../Scripts/Utils": "Utils",
        "./PlatformUtils": "PlatformUtils"
    }],
    _huawei: [function(e, n, a) {
        "use strict";
        function o(e, n) {
            if (!(e instanceof n))
                throw new TypeError("Cannot call a class as a function")
        }
        cc._RF.push(n, "47e9fku9TdBKIY/58uwENZd", "_huawei"),
        Object.defineProperty(a, "__esModule", {
            value: !0
        }),
        a.huawei = void 0;
        a.huawei = function e(n, a) {
            o(this, e)
        }
        ,
        cc._RF.pop()
    }
    , {}],
    _oppo: [function(e, n, a) {
        "use strict";
        function o(e, n) {
            if (!(e instanceof n))
                throw new TypeError("Cannot call a class as a function")
        }
        function i(e, n) {
            for (var a = 0; a < n.length; a++) {
                var o = n[a];
                o.enumerable = o.enumerable || !1,
                o.configurable = !0,
                "value"in o && (o.writable = !0),
                Object.defineProperty(e, o.key, o)
            }
        }
        function t(e, n, a) {
            return n && i(e.prototype, n),
            a && i(e, a),
            e
        }
        cc._RF.push(n, "7e5e7pNzHBLGJWvZmP4dDiz", "_oppo"),
        Object.defineProperty(a, "__esModule", {
            value: !0
        }),
        a.oppo = void 0;
        var r = function() {
            function e(n, a) {
                var i = this;
                o(this, e),
                this.NormalBanner = null,
                this.SpecialBanner = null,
                this.AlertBanner = null,
                this.lastBannerTime = 0,
                this.bannerIndex = 0,
                this.Video = null,
                this.GamePortal = null,
                this.video_success = null,
                this.video_failure = null,
                this.ServerConfig = n,
                this.CodeList = a,
                this.lastBannerTime = 0,
                this.bannerIndex = 0;
                var t = function() {
                    i.Video = window.qg.createRewardedVideoAd({
                        adUnitId: i.CodeList.videoCode
                    }),
                    i.GamePortal = window.qg.createGamePortalAd({
                        adUnitId: i.CodeList.boxCode
                    }),
                    i.GamePortal.isTrigger = !1,
                    i.GamePortal.onClose(function() {
                        i.GamePortal.isTrigger = !1
                    })
                };
                window.qg.initAdService({
                    appId: this.CodeList.appID,
                    isDebug: !0,
                    success: function(e) {
                        console.log("初始化OPPO广告服务成功"),
                        t && t()
                    },
                    fail: function(e) {
                        console.error("初始化OPPO广告服务失败:", e.code, e.msg)
                    },
                    complete: function(e) {
                        console.log("完成OPPO广告初始化")
                    }
                })
            }
            return t(e, [{
                key: "showVideo",
                value: function(e, n) {
                    var a = this;
                    cc.director.pause(),
                    cc.audioEngine.pauseAll(),
                    this.video_success = e,
                    this.video_failure = n,
                    this.Video.load().then(function() {
                        console.log("拉取视频广告成功, 等待显示!!"),
                        a.Video.show().then(function() {
                            console.log("视频广告成功显示~~~~")
                        }).catch(function(e) {
                            console.log("视频广告成功失败:", e),
                            a.executeShowToast("视频组件显示失败，请稍后再试！")
                        })
                    }).catch(function(e) {
                        console.error("拉取视频广告失败:", e),
                        a.executeShowToast("视频组件加载失败，请稍后再试！")
                    }),
                    this.Video.onClose(function(e) {
                        e.isEnded ? (console.log("视频广告播放完毕, 开始下发奖励!!"),
                        a.executeVideoSuccessCallBack()) : a.ServerConfig.allowShowModal && a.ServerConfig.isLine ? (console.log("视频广告未播放完毕, 准备二次询问用户!!"),
                        window.qg.showModal({
                            title: "提示",
                            content: "未观看完视频，是否继续？",
                            success: function(e) {
                                a.executeVideoFailureCallBack()
                            },
                            fail: function(e) {
                                e.cancel ? a.Video.load().then(function() {
                                    console.log("拉取视频广告成功, 等待显示!!"),
                                    a.Video.show().then(function() {
                                        console.log("视频广告成功显示~~~~")
                                    }).catch(function(e) {
                                        console.log("视频广告成功失败:", e),
                                        a.executeShowToast("视频组件显示失败，请稍后再试！")
                                    })
                                }).catch(function(e) {
                                    console.error("拉取视频广告失败:", e),
                                    a.executeShowToast("视频组件加载失败，请稍后再试！")
                                }) : e.confirm && a.executeVideoFailureCallBack()
                            }
                        })) : a.executeVideoFailureCallBack()
                    })
                }
            }, {
                key: "showBanner",
                value: function(e, n) {}
            }, {
                key: "hideBanner",
                value: function() {}
            }, {
                key: "showSpecialBanner",
                value: function() {
                    var e = this;
                    this.NormalBanner.active && (this.NormalBanner.active = !1);
                    var n = function() {
                        var n = e.CodeList.nativeCodes[e.bannerIndex]
                          , a = window.qg.createNativeAd({
                            adUnitId: n
                        });
                        a.load().then(function(n) {
                            console.log("提取原生广告成功:", n),
                            e.lastBannerTime = (new Date).getTime(),
                            e.bannerIndex++,
                            e.bannerIndex >= e.CodeList.nativeCodes.length && (e.bannerIndex = 0);
                            var o = n.adList[0]
                              , i = o.adId
                              , t = o.imgUrlList[0];
                            "" !== i && "" !== t && e.SpecialBanner.getComponent("SpecialBanner").executeRefresh(a, t, i)
                        }).catch(function(n) {
                            console.log("提取原生广告失败---:", n),
                            e.SpecialBanner.getComponent("SpecialBanner").executeDisplay()
                        })
                    };
                    if (this.SpecialBanner.zIndex = 9999,
                    0 === this.lastBannerTime)
                        n && n();
                    else {
                        console.log("显示特殊Banner_1");
                        var a = (new Date).getTime();
                        if (Math.floor((a - this.lastBannerTime) / 1e3) <= this.ServerConfig.bannerInterval) {
                            console.log("显示特殊Banner_3");
                            var o = cc.director.getScene().getChildByName("NormalBanner").getComponent("NormalBanner").getNativeInformation();
                            return void this.SpecialBanner.getComponent("SpecialBanner").executeRefresh(o.nativeInstance, o.imgPath, o.code)
                        }
                        console.log("显示特殊Banner_2"),
                        n && n()
                    }
                }
            }, {
                key: "hideSpecialBanner",
                value: function() {
                    this.SpecialBanner.active && (this.SpecialBanner.active = !1)
                }
            }, {
                key: "showAlertBanner",
                value: function(e) {
                    var n = this;
                    this.SpecialBanner.active && (this.SpecialBanner.active = !1);
                    var a = function() {
                        var a = n.CodeList.nativeCodes[n.bannerIndex]
                          , o = window.qg.createNativeAd({
                            adUnitId: a
                        });
                        o.load().then(function(a) {
                            n.lastBannerTime = (new Date).getTime(),
                            n.bannerIndex++,
                            n.bannerIndex >= n.CodeList.nativeCodes.length && (n.bannerIndex = 0);
                            var i = a.adList[0]
                              , t = i.adId
                              , r = i.imgUrlList[0];
                            "" !== t && "" !== r && n.AlertBanner.getComponent("AlertBanner").executeRefresh(o, r, t, e)
                        }).catch(function(a) {
                            var o = cc.director.getScene().getChildByName("SpecialBanner").getComponent("SpecialBanner").getNativeInformation();
                            n.AlertBanner.getComponent("SpecialBanner").executeRefresh(o.nativeInstance, o.imgPath, o.code, e)
                        })
                    };
                    if (this.AlertBanner.zIndex = 9999,
                    0 === this.lastBannerTime)
                        a && a();
                    else {
                        var o = (new Date).getTime();
                        if (Math.floor((o - this.lastBannerTime) / 1e3) <= this.ServerConfig.bannerInterval) {
                            var i = cc.director.getScene().getChildByName("SpecialBanner").getComponent("SpecialBanner").getNativeInformation();
                            return void this.AlertBanner.getComponent("AlertBanner").executeRefresh(i.nativeInstance, i.imgPath, i.code, e)
                        }
                        a && a()
                    }
                }
            }, {
                key: "showInterstitial",
                value: function() {
                    var e = this;
                    this.native_interstitial && (console.log("销毁插屏广告"),
                    this.native_interstitial.destroy(),
                    this.native_interstitial = null);
                    var n = cc.director.getScene().getChildByName("NativeInterstitial");
                    n && (console.log("销毁插屏节点"),
                    n.removeFromParent(!0)),
                    this.hideSecondBanner();
                    var a = this.CodeList.nativeCodes[this.bannerIndex];
                    this.native_interstitial = qg.createNativeAd({
                        adUnitId: a
                    }),
                    this.bannerIndex++,
                    this.bannerIndex >= this.CodeList.nativeCodes.length && (this.bannerIndex = 0),
                    this.native_interstitial.onLoad(function(n) {
                        var a = n.adList[0]
                          , o = a.adId
                          , i = a.imgUrlList[0];
                        console.error("插屏-广告ID = ", o),
                        console.error("插屏-图片地址 = ", i),
                        i && (e.native_interstitial.reportAdShow({
                            adId: o
                        }),
                        cc.loader.loadRes("Platform/Prefabs/oppo/NativeInterstitial", function(n, a) {
                            if (n)
                                console.error("载入插屏预制资源失败, 原因:" + n);
                            else if (a instanceof cc.Prefab) {
                                var t = cc.instantiate(a);
                                cc.director.getScene().addChild(t),
                                t.getComponent("NativeInterstitial").initialize(i, function() {
                                    e.native_interstitial.reportAdClick({
                                        adId: o
                                    }),
                                    e.executeDestroyInterstitial()
                                }, function() {
                                    e.executeDestroyInterstitial()
                                })
                            } else
                                console.error("你载入的不是插屏预制资源!")
                        }))
                    }),
                    this.native_interstitial.onError(function(e) {
                        console.error("加载原生广告(插屏)信息错误:", JSON.stringify(e))
                    }),
                    this.native_interstitial.load()
                }
            }, {
                key: "executeDestroyInterstitial",
                value: function() {
                    this.native_interstitial && (console.log("销毁插屏广告"),
                    this.native_interstitial.destroy(),
                    this.native_interstitial = null);
                    var e = cc.director.getScene().getChildByName("NativeInterstitial");
                    e && (console.log("销毁插屏节点"),
                    e.removeFromParent(!0)),
                    this.showSecondBanner()
                }
            }, {
                key: "showSecondBanner",
                value: function() {
                    var e = this;
                    this.hideSecondBanner();
                    var n = this.CodeList.nativeCodes[this.bannerIndex];
                    this.native_banner = window.qg.createNativeAd({
                        adUnitId: n
                    }),
                    this.bannerIndex++,
                    this.bannerIndex >= this.CodeList.nativeCodes.length && (this.bannerIndex = 0),
                    this.native_banner.onLoad(function(n) {
                        var a = n.adList[0]
                          , o = a.adId
                          , i = a.imgUrlList[0];
                        console.error("Banner-广告ID = ", o),
                        console.error("Banner-图片地址 = ", i),
                        i && (e.native_banner.reportAdShow({
                            adId: o
                        }),
                        cc.loader.loadRes("Platform/Prefabs/oppo/NativeBanner", function(n, a) {
                            if (n)
                                console.error("载入Banner预制资源失败, 原因:" + n);
                            else if (a instanceof cc.Prefab) {
                                console.log("创建Banner对象成功!!!");
                                var t = cc.instantiate(a);
                                cc.director.getScene().addChild(t),
                                t.getComponent("NativeBanner").initialize(i, function() {
                                    e.native_banner.reportAdClick({
                                        adId: o
                                    }),
                                    e.hideSecondBanner()
                                }, function() {
                                    e.hideSecondBanner()
                                })
                            } else
                                console.error("你载入的不是Banner预制资源!")
                        }))
                    }),
                    this.native_banner.onError(function(n) {
                        console.error("加载原生广告(Banner)信息错误:", JSON.stringify(n)),
                        e.hideSecondBanner()
                    }),
                    this.native_banner.load()
                }
            }, {
                key: "hideSecondBanner",
                value: function() {
                    this.native_banner && (console.warn("销毁Banner广告"),
                    this.native_banner.destroy(),
                    this.native_banner = null);
                    var e = cc.director.getScene().getChildByName("NativeBanner");
                    e && (console.warn("销毁Banner节点"),
                    e.removeFromParent(!0))
                }
            }, {
                key: "showMoreGames",
                value: function() {
                    var e = this;
                    this.GamePortal.isTrigger ? console.log("无法触发游戏盒子") : (this.GamePortal.isTrigger = !0,
                    this.GamePortal.load().then(function() {
                        e.GamePortal.isTrigger = !1,
                        e.GamePortal.show()
                    }).catch(function(n) {
                        e.GamePortal.isTrigger = !1
                    }))
                }
            }, {
                key: "isInstalledDesktopShortcut",
                value: function(e, n) {
                    window.qg.hasShortcutInstalled({
                        success: function(a) {
                            a ? e && e() : n && n()
                        },
                        fail: function(e) {},
                        complete: function() {}
                    })
                }
            }, {
                key: "additionShortcut",
                value: function(e) {
                    window.qg.installShortcut({
                        success: function() {
                            e && (e.active = !1)
                        },
                        fail: function(e) {},
                        complete: function() {}
                    })
                }
            }, {
                key: "executeShowToast",
                value: function(e) {
                    window.qg.showToast({
                        title: e,
                        duration: 1500
                    })
                }
            }, {
                key: "executeVideoSuccessCallBack",
                value: function() {
                    cc.director.resume(),
                    cc.audioEngine.resumeAll(),
                    this.video_success && this.video_success(),
                    this.video_success = null
                }
            }, {
                key: "executeVideoFailureCallBack",
                value: function() {
                    cc.director.resume(),
                    cc.audioEngine.resumeAll(),
                    this.video_failure && this.video_failure(),
                    this.video_failure = null
                }
            }]),
            e
        }();
        a.oppo = r,
        cc._RF.pop()
    }
    , {}],
    _tencent: [function(e, n, a) {
        "use strict";
        function o(e, n) {
            if (!(e instanceof n))
                throw new TypeError("Cannot call a class as a function")
        }
        function i(e, n) {
            for (var a = 0; a < n.length; a++) {
                var o = n[a];
                o.enumerable = o.enumerable || !1,
                o.configurable = !0,
                "value"in o && (o.writable = !0),
                Object.defineProperty(e, o.key, o)
            }
        }
        function t(e, n, a) {
            return n && i(e.prototype, n),
            a && i(e, a),
            e
        }
        cc._RF.push(n, "32441E5Gy5Ewo3DtcEq9DoY", "_tencent"),
        Object.defineProperty(a, "__esModule", {
            value: !0
        }),
        a.tencent = void 0;
        var r = function() {
            function e(n, a) {
                var i = this;
                o(this, e),
                this.Device = null,
                this.Video = null,
                this.Banner = null,
                this.Interstitial = null,
                this.Grid = null,
                this.GridDetail = null,
                this.Box = null,
                this.video_success = null,
                this.video_failure = null,
                this.isOpenShare = !1,
                this.triggerTime = 0,
                this.shareCount = 0,
                this.share_success = null,
                this.share_failure = null,
                this.ServerConfig = n,
                this.CodeList = a,
                this.Device = window.qq.getSystemInfoSync(),
                this.GridDetail = {},
                window.qq.showShareMenu({
                    showShareItems: ["qq", "qzone", "wechatFriends", "wechatMoment"]
                }),
                window.qq.onShareAppMessage(function() {
                    return {
                        title: App.ChineseName,
                        imageUrl: "./shareImg.jpg"
                    }
                }),
                window.qq.onShow(this.onShowCallBack.bind(this)),
                window.qq.onHide(this.onHideCallBack.bind(this)),
                this.Video = window.qq.createRewardedVideoAd({
                    adUnitId: this.CodeList.videoCode
                }),
                this.Video.onClose(function(e) {
                    e.isEnded ? (i.Video.isLock = !1,
                    i.executeVideoSuccessCallBack()) : i.ServerConfig.isLine && i.ServerConfig.allowShowModal ? window.qq.showModal({
                        title: "提示",
                        content: "未观看完视频，是否继续？",
                        success: function(e) {
                            e.confirm ? (i.Video.isLock = !0,
                            i.Video.load().then(function() {
                                i.Video.show().then(function() {
                                    i.Video.isLock = !1
                                }).catch(function() {
                                    i.Video.isLock = !1,
                                    i.executeVideoFailureCallBack()
                                })
                            }).catch(function(e) {
                                i.Video.isLock = !1,
                                i.executeVideoFailureCallBack()
                            })) : e.cancel && (i.Video.isLock = !1,
                            i.executeVideoFailureCallBack())
                        },
                        fail: function(e) {
                            i.Video.isLock = !1,
                            i.executeVideoFailureCallBack()
                        }
                    }) : (i.Video.isLock = !1,
                    i.executeVideoFailureCallBack())
                }),
                this.Box = window.qq.createAppBox({
                    adUnitId: this.CodeList.boxCode
                }),
                this.Box.load().then(function() {
                    console.log("盒子广告初始化成功")
                }).catch(function(e) {
                    console.log("盒子广告初始化失败:", e)
                });
                this.Banner = window.qq.createBannerAd({
                    adUnitId: this.CodeList.bannerCode,
                    adIntervals: 30,
                    style: {
                        left: 0,
                        top: this.Device.screenHeight - 200,
                        width: 200
                    }
                }),
                this.Banner.onResize(function(e) {
                    i.Banner.style.left = (i.Device.screenWidth - e.width) / 2,
                    i.Banner.style.top = i.Device.screenHeight - e.height
                }),
                this.Banner.onLoad(function() {
                    console.log("微信Banner组件初始化成功, 等待触发显示!!!!")
                }),
                this.Interstitial = window.qq.createInterstitialAd({
                    adUnitId: this.CodeList.interstitialCode
                }),
                this.Interstitial.isLock = !1,
                this.Interstitial.onClose(function() {
                    i.Interstitial.isLock = !1
                })
            }
            return t(e, [{
                key: "showVideo",
                value: function(e, n) {
                    var a = this;
                    this.Video.isLock || (cc.director.pause(),
                    cc.audioEngine.pauseAll(),
                    this.video_success = e,
                    this.video_failure = n,
                    this.Video.isLock = !0,
                    this.Video.load().then(function() {
                        a.Video.show().then(function() {
                            a.Video.isLock = !1
                        }).catch(function() {
                            a.Video.isLock = !1,
                            a.executeVideoFailureCallBack()
                        })
                    }).catch(function(e) {
                        a.Video.isLock = !1,
                        a.executeVideoFailureCallBack()
                    }))
                }
            }, {
                key: "showBanner",
                value: function(e, n) {
                    this.Banner && (this.hideBanner(),
                    this.Banner.show())
                }
            }, {
                key: "hideBanner",
                value: function() {
                    this.Banner && this.Banner.hide()
                }
            }, {
                key: "showInterstitial",
                value: function() {
                    var e = this;
                    this.Interstitial && !this.Interstitial.isLock && (this.Interstitial.isLock = !0,
                    this.Interstitial.load().then(function() {
                        e.Interstitial.show().then(function() {}).catch(function(n) {
                            e.Interstitial.isLock = !1
                        })
                    }).catch(function(n) {
                        e.Interstitial.isLock = !1
                    }))
                }
            }, {
                key: "refreshGridLogicTimer",
                value: function() {
                    this.showGrid(this.GridDetail.location, this.GridDetail.size, this.GridDetail.orientation)
                }
            }, {
                key: "showGrid",
                value: function(e, n, a) {
                    var o = this;
                    this.hideGrid(),
                    this.GridDetail.location = e,
                    this.GridDetail.size = n,
                    this.GridDetail.orientation = a;
                    var i = cc.view.getVisibleSize()
                      , t = this.Device.windowWidth / i.width
                      , r = this.Device.windowHeight / i.height
                      , c = e.x * t
                      , d = e.y * r;
                    console.log("构建积木广告"),
                    this.Grid = window.qq.createBlockAd({
                        adUnitId: this.CodeList.blockCode,
                        size: n,
                        orientation: a,
                        style: {
                            left: c,
                            top: d
                        }
                    }),
                    this.Grid.onResize(function(e) {
                        o.Grid.style.left = c - e.width / 2,
                        o.Grid.style.top = d - e.height / 2
                    }),
                    this.Grid.onError(function(e) {
                        console.log(JSON.stringify(e)),
                        o.hideGrid()
                    }),
                    this.Grid.onLoad(function() {
                        o.Grid.show()
                    })
                }
            }, {
                key: "hideGrid",
                value: function() {
                    this.Grid && (this.Grid.destroy(),
                    this.Grid = null)
                }
            }, {
                key: "additionColorSign",
                value: function(e) {
                    window.qq.isColorSignExistSync ? cc.isDesktopShortcut || e && e() : window.qq.addColorSign({
                        success: function(e) {},
                        fail: function(n) {
                            e && e()
                        }
                    })
                }
            }, {
                key: "isInstalledDesktopShortcut",
                value: function(e, n) {
                    cc.isDesktopShortcut ? e && e() : n && n()
                }
            }, {
                key: "additionShortcut",
                value: function(e) {
                    window.qq.saveAppToDesktop({
                        success: function() {
                            e && (e.active = !1),
                            cc.isDesktopShortcut = !0
                        },
                        fail: function(e) {},
                        complete: function() {}
                    })
                }
            }, {
                key: "showMoreGames",
                value: function() {
                    this.Box && this.Box.show()
                }
            }, {
                key: "doShare",
                value: function(e, n) {
                    this.share_success = e,
                    this.share_failure = n,
                    this.isOpenShare = !0,
                    window.qq.shareAppMessage({
                        title: App.ChineseName,
                        imageUrl: "./shareImg.jpg",
                        shareAppType: "qq"
                    })
                }
            }, {
                key: "onHideCallBack",
                value: function() {
                    console.log("微信切入了后台"),
                    this.isOpenShare && (this.triggerTime = (new Date).getTime())
                }
            }, {
                key: "onShowCallBack",
                value: function() {
                    var e = this;
                    if (console.log("微信返回了前台"),
                    this.isOpenShare) {
                        var n = (new Date).getTime()
                          , a = e.shareCount <= 0 ? 3 : e.shareCount >= 1 && e.shareCount <= 2 ? 3.5 : e.shareCount >= 3 && e.shareCount <= 4 ? 4 : e.shareCount >= 5 && e.shareCount <= 6 ? 4.5 : e.shareCount >= 7 && e.shareCount <= 8 ? 5 : e.shareCount >= 9 && e.shareCount <= 10 ? 5.5 : 6;
                        Math.floor((n - this.triggerTime) / 1e3) >= a ? (console.log("分享成功"),
                        this.shareCount++,
                        this.share_success && this.share_success(),
                        this.share_success = null) : (console.log("分享失败"),
                        this.share_failure && this.share_failure(),
                        this.share_failure = null)
                    }
                }
            }, {
                key: "executeVideoSuccessCallBack",
                value: function() {
                    cc.director.resume(),
                    cc.audioEngine.resumeAll(),
                    this.video_success && this.video_success(),
                    this.video_success = null
                }
            }, {
                key: "executeVideoFailureCallBack",
                value: function() {
                    cc.director.resume(),
                    cc.audioEngine.resumeAll(),
                    this.video_failure && this.video_failure(),
                    this.video_failure = null
                }
            }]),
            e
        }();
        a.tencent = r,
        cc._RF.pop()
    }
    , {}],
    _wechat: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "f2f93GIDLJGqY+j5u2xMa9m", "_wechat"),
        Object.defineProperty(a, "__esModule", {
            value: !0
        }),
        a.wechat = void 0;
        var o = e("./PlatformUtils")
          , i = e("../../Scripts/Utils");
        function t(e, n) {
            if (!(e instanceof n))
                throw new TypeError("Cannot call a class as a function")
        }
        function r(e, n) {
            for (var a = 0; a < n.length; a++) {
                var o = n[a];
                o.enumerable = o.enumerable || !1,
                o.configurable = !0,
                "value"in o && (o.writable = !0),
                Object.defineProperty(e, o.key, o)
            }
        }
        function c(e, n, a) {
            return n && r(e.prototype, n),
            a && r(e, a),
            e
        }
        var d = function() {
            function e(n, a) {
                var o = this;
                if (t(this, e),
                this.Device = null,
                this.ServerConfig = {},
                this.Video = null,
                this.Banner = null,
                this.Interstitial = null,
                this.Grid = null,
                this.LandscapeNavigation = null,
                this.NormalNavigation = null,
                this.LargeNavigation = null,
                this.ExportNavigation = null,
                this.video_success = null,
                this.video_failure = null,
                this.isOpenShare = !1,
                this.triggerTime = 0,
                this.shareCount = 0,
                this.share_success = null,
                this.share_failure = null,
                this.ServerConfig = n,
                this.CodeList = a,
                this.Device = window.wx.getSystemInfoSync(),
                window.wx.showShareMenu({
                    withShareTicket: !0,
                    menus: ["shareAppMessage", "shareTimeline"]
                }),
                window.wx.onShow(this.onShowCallBack.bind(this)),
                window.wx.onHide(this.onHideCallBack.bind(this)),
                console.log("微信游戏配置:", this.ServerConfig),
                0 === this.ServerConfig.iconList.length)
                    this.LandscapeNavigation = null,
                    this.NormalNavigation = null,
                    this.LargeNavigation = null,
                    this.ExportNavigation = null;
                else {
                    var i = "Platform/Prefabs/LandscapeNavigation";
                    cc.loader.loadRes(i, cc.Prefab, function(e, n) {
                        e && console.log("发生错误:", e),
                        o.LandscapeNavigation = cc.instantiate(n),
                        o.LandscapeNavigation.zIndex = 9998,
                        cc.game.addPersistRootNode(o.LandscapeNavigation)
                    }),
                    i = "Platform/Prefabs/NormalNavigation",
                    cc.loader.loadRes(i, cc.Prefab, function(e, n) {
                        e && console.log("发生错误:", e),
                        o.NormalNavigation = cc.instantiate(n),
                        o.NormalNavigation.zIndex = 9999,
                        cc.game.addPersistRootNode(o.NormalNavigation)
                    }),
                    i = "Platform/Prefabs/LargeNavigation",
                    cc.loader.loadRes(i, cc.Prefab, function(e, n) {
                        e && console.log("发生错误:", e),
                        o.LargeNavigation = cc.instantiate(n),
                        o.LargeNavigation.zIndex = 9999,
                        cc.game.addPersistRootNode(o.LargeNavigation);
                        for (var a = [], i = 0; i < o.ServerConfig.iconList.length; i++) {
                            var t = {
                                url: o.ServerConfig.iconList[i],
                                appId: o.ServerConfig.packageList[i]
                            };
                            a.push(t)
                        }
                        o.LargeNavigation.getComponent("LargeNavigation").instantiation(a)
                    }),
                    i = "Platform/Prefabs/ExportNavigation",
                    cc.loader.loadRes(i, cc.Prefab, function(e, n) {
                        e && console.log("发生错误:", e),
                        o.ExportNavigation = cc.instantiate(n),
                        o.ExportNavigation.zIndex = 9999,
                        cc.game.addPersistRootNode(o.ExportNavigation)
                    })
                }
                if ("" === this.ServerConfig.wx_VideoCode ? (console.error("初始化微信视频组件失败:无效的视频广告ID"),
                this.Video = null) : (this.Video = window.wx.createRewardedVideoAd({
                    adUnitId: this.ServerConfig.wx_VideoCode
                }),
                this.Video.onClose(function(e) {
                    e.isEnded ? (o.Video.isLock = !1,
                    o.executeVideoSuccessCallBack()) : o.ServerConfig.isLine && o.ServerConfig.allowShowModal ? window.wx.showModal({
                        title: "提示",
                        content: "未观看完视频，是否继续？",
                        success: function(e) {
                            e.confirm ? (o.Video.isLock = !0,
                            o.Video.load().then(function() {
                                o.Video.show().then(function() {}).catch(function() {
                                    o.Video.isLock = !1,
                                    o.executeVideoFailureCallBack()
                                })
                            }).catch(function(e) {
                                o.Video.isLock = !1,
                                o.executeVideoFailureCallBack()
                            })) : e.cancel && (o.Video.isLock = !1,
                            o.executeShowLargeNavigation(),
                            o.executeVideoFailureCallBack())
                        },
                        fail: function(e) {
                            o.Video.isLock = !1,
                            o.executeVideoFailureCallBack()
                        }
                    }) : (o.Video.isLock = !1,
                    o.executeVideoFailureCallBack())
                }),
                this.Video.onError(function(e) {
                    o.Video.isLock = !1,
                    console.log("微信视频组件发生错误:", e)
                }),
                this.Video.load().then(function() {
                    o.Video.isLock = !1,
                    console.log("视频广告初始化成功, 等待触发显示!!!!")
                })),
                "" === this.ServerConfig.wx_BannerCode)
                    console.error("初始化微信Banner组件失败:无效的Banner广告ID"),
                    this.Banner = null;
                else {
                    this.Banner = window.wx.createBannerAd({
                        adUnitId: this.ServerConfig.wx_BannerCode,
                        adIntervals: 30,
                        style: {
                            left: 0,
                            top: this.Device.screenHeight - 200,
                            width: 200
                        }
                    }),
                    this.Banner.onError(function(e) {
                        console.log("微信Banner组件发生错误:", e),
                        o.Banner = null
                    }),
                    this.Banner.onResize(function(e) {
                        o.Banner.style.left = (o.Device.screenWidth - e.width) / 2,
                        o.Banner.style.top = o.Device.screenHeight - e.height
                    }),
                    this.Banner.onLoad(function() {
                        console.log("微信Banner组件初始化成功, 等待触发显示!!!!")
                    })
                }
                if ("" === this.ServerConfig.wx_InterstitialCode ? console.error("初始化微信插屏组件失败:无效的插屏广告ID") : (this.Interstitial = window.wx.createInterstitialAd({
                    adUnitId: this.ServerConfig.wx_InterstitialCode
                }),
                this.Interstitial.isLock = !1,
                this.Interstitial.onClose(function() {
                    o.Interstitial.isLock = !1
                })),
                "" === this.ServerConfig.wx_GridCode)
                    console.error("初始化微信格子组件失败:无效的格子广告ID"),
                    this.Grid = null;
                else {
                    this.Grid = window.wx.createGridAd({
                        adUnitId: this.ServerConfig.wx_GridCode,
                        adIntervals: 30,
                        style: {
                            left: 0,
                            top: this.Device.screenHeight - 200,
                            width: 200,
                            height: 130,
                            opacity: .8
                        },
                        adTheme: "white",
                        gridCount: 5
                    }),
                    this.Grid.onResize(function(e) {
                        o.Grid.style.left = (o.Device.screenWidth - e.width) / 2,
                        o.Grid.style.top = o.Device.screenHeight - e.height
                    }),
                    this.Grid.onError(function(e) {
                        console.error("初始化微信格子组件失败~~~"),
                        o.Grid = null
                    }),
                    this.Grid.onLoad(function() {
                        console.log("初始化微信格子组件成功11111111~~~")
                    })
                }
            }
            return c(e, [{
                key: "showVideo",
                value: function(e, n) {
                    var a = this;
                    this.Video ? this.Video.isLock ? console.log("123123123213123") : (cc.director.pause(),
                    cc.audioEngine.pauseAll(),
                    this.video_success = e,
                    this.video_failure = n,
                    this.Video.isLock = !0,
                    this.Video.show().then(function() {
                        console.log("微信视频组件首次显示成功")
                    }).catch(function() {
                        console.error("微信视频组件首次显示失败, 开始第二次加载..."),
                        a.Video.load().then(function() {
                            a.Video.show().then(function() {}).catch(function(e) {
                                a.Video.isLock = !1,
                                a.executeVideoFailureCallBack()
                            })
                        }).catch(function(e) {
                            a.Video.isLock = !1,
                            a.executeVideoFailureCallBack()
                        })
                    })) : e && e()
                }
            }, {
                key: "showBanner",
                value: function() {
                    this.hideBanner();
                    var e = i.MathMgr.getRandomNum(0, 100);
                    e < this.ServerConfig.systemRandom ? (e = i.MathMgr.getRandomNum(0, 100)) < this.ServerConfig.gridRandom && this.Grid ? this.executeShowGrid() : this.showSystemBanner() : this.executeShowLandscapeNavigation()
                }
            }, {
                key: "hideBanner",
                value: function() {
                    this.executeHideLandscapeNavigation(),
                    this.executeHideGrid(),
                    this.hideSystemBanner()
                }
            }, {
                key: "showSystemBanner",
                value: function() {
                    this.Banner && this.Banner.show().then(function() {
                        console.log("微信Banner成功显示!!")
                    })
                }
            }, {
                key: "hideSystemBanner",
                value: function() {
                    this.Banner && this.Banner.hide()
                }
            }, {
                key: "showInterstitial",
                value: function() {
                    var e = this;
                    this.Interstitial && (this.Interstitial.isLock ? console.warn("微信插屏组件处于锁定状态, 无法下一步操作!") : (this.Interstitial.isLock = !0,
                    this.Interstitial.load().then(function() {
                        console.log("微信插屏广告加载成功, 准备显示!!"),
                        e.Interstitial.show().then(function() {
                            console.log("微信插屏广告显示成功!!!")
                        }).catch(function(n) {
                            console.log("微信插屏广告显示失败!!!"),
                            e.Interstitial.isLock = !1
                        })
                    }).catch(function(n) {
                        console.log("微信插屏广告加载失败!!!"),
                        e.Interstitial.isLock = !1
                    })))
                }
            }, {
                key: "executeShowLandscapeNavigation",
                value: function() {
                    this.LandscapeNavigation && this.LandscapeNavigation.getComponent("LandscapeNavigation").executeDisplay(cc.size(130, 160))
                }
            }, {
                key: "executeHideLandscapeNavigation",
                value: function() {
                    this.LandscapeNavigation && (this.LandscapeNavigation.active = !1)
                }
            }, {
                key: "executeShowGrid",
                value: function() {
                    this.Grid && this.Grid.show().then(function() {
                        console.log("微信格子广告显示成功!!!")
                    }).catch(function(e) {
                        console.error("微信格子广告显示失败!!!")
                    })
                }
            }, {
                key: "executeHideGrid",
                value: function() {
                    this.Grid && this.Grid.hide()
                }
            }, {
                key: "executeShowNormalNavigation",
                value: function() {
                    this.NormalNavigation && this.NormalNavigation.getComponent("NormalNavigation").doDisplay()
                }
            }, {
                key: "executeShowExportNavigation",
                value: function(e) {
                    this.ExportNavigation ? (this.hideBanner(),
                    this.ExportNavigation.getComponent("ExportNavigation").doDisplay(e)) : e && e()
                }
            }, {
                key: "executeShowLargeNavigation",
                value: function() {
                    this.LargeNavigation && (this.hideBanner(),
                    this.LargeNavigation.getComponent("LargeNavigation").doDisplay(cc.size(218, 268)))
                }
            }, {
                key: "doShare",
                value: function(e, n) {
                    this.share_success = e,
                    this.share_failure = n,
                    this.isOpenShare = !0,
                    window.wx.shareAppMessage({
                        title: o.App.ShareLanguage,
                        imageUrl: "./Textures/shareImg.jpg"
                    })
                }
            }, {
                key: "onHideCallBack",
                value: function() {
                    this.isOpenShare && (this.triggerTime = (new Date).getTime())
                }
            }, {
                key: "onShowCallBack",
                value: function() {
                    var e = this;
                    if (this.isOpenShare) {
                        var n = (new Date).getTime()
                          , a = e.shareCount <= 0 ? 3 : e.shareCount >= 1 && e.shareCount <= 2 ? 3.5 : e.shareCount >= 3 && e.shareCount <= 4 ? 4 : e.shareCount >= 5 && e.shareCount <= 6 ? 4.5 : e.shareCount >= 7 && e.shareCount <= 8 ? 5 : e.shareCount >= 9 && e.shareCount <= 10 ? 5.5 : 6;
                        Math.floor((n - this.triggerTime) / 1e3) >= a ? (console.log("分享成功"),
                        this.shareCount++,
                        this.share_success && this.share_success(),
                        this.share_success = null) : (console.log("分享失败"),
                        this.share_failure && this.share_failure(),
                        this.share_failure = null)
                    }
                }
            }, {
                key: "fromToMiniProgram",
                value: function(e) {
                    var n = this;
                    window.wx.navigateToMiniProgram({
                        appId: e,
                        success: function() {},
                        fail: function() {
                            cc.director.getScene().getChildByName("LargeNavigation").active || n.executeShowLargeNavigation()
                        }
                    })
                }
            }, {
                key: "executeVideoSuccessCallBack",
                value: function() {
                    cc.director.resume(),
                    cc.audioEngine.resumeAll(),
                    this.video_success && this.video_success(),
                    this.video_success = null
                }
            }, {
                key: "executeVideoFailureCallBack",
                value: function() {
                    cc.director.resume(),
                    cc.audioEngine.resumeAll(),
                    this.video_failure && this.video_failure(),
                    this.video_failure = null
                }
            }]),
            e
        }();
        a.wechat = d,
        cc._RF.pop()
    }
    , {
        "../../Scripts/Utils": "Utils",
        "./PlatformUtils": "PlatformUtils"
    }],
    gameData: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "82acbpDMslOnae8w7n9zskx", "gameData"),
        Object.defineProperty(a, "__esModule", {
            value: !0
        }),
        a.CarDataList = void 0;
        a.CarDataList = {
            "module-1": [{
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-7",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-7",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: 165,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-7",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 7,
                    location: {
                        x: 0,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 275,
                        y: 220,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-7",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -165,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-7",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }],
                end: [{
                    orderIndex: 4,
                    location: {
                        x: 165,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 275,
                        y: 220,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-7",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-7",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -55,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 9,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 165,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }],
                end: [{
                    orderIndex: 8,
                    location: {
                        x: 0,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 9,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 275,
                        y: 220,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-7",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: 165,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 9,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }],
                end: [{
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -55,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 275,
                        y: 220,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-7",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: 165,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 165,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-5",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -165,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-5",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -165,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }],
                end: [{
                    orderIndex: 2,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -275,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 7,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 8,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 9,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 11,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-5",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 3,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 165,
                        y: -110,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-5",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 3,
                    location: {
                        x: -165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -165,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 9,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 10,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 11,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 275,
                        y: 220,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-5",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-5",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -165,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-5",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -55,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 9,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 4,
                    location: {
                        x: 165,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: 275,
                        y: -110,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }],
                end: [{
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 275,
                        y: 220,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }],
                end: [{
                    orderIndex: 3,
                    location: {
                        x: 165,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-5",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: 165,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -165,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }],
                end: [{
                    orderIndex: 5,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 275,
                        y: -110,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 8,
                    frameName: "car-1-5",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: 165,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 8,
                    location: {
                        x: 55,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -165,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 5,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 275,
                        y: 220,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 165,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -165,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 7,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 9,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 10,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }],
                end: [{
                    orderIndex: 10,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -275,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 7,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 8,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 9,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 10,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }],
                end: [{
                    orderIndex: 6,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 10,
                    location: {
                        x: 165,
                        y: -110,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -165,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 8,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 9,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 10,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }],
                end: [{
                    orderIndex: 9,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 10,
                    location: {
                        x: 275,
                        y: -110,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -165,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 8,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 9,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 10,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 11,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 12,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 13,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 9,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 11,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 12,
                    location: {
                        x: 275,
                        y: 220,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-7",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: 55,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }],
                end: [{
                    orderIndex: 4,
                    location: {
                        x: 275,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -55,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 165,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }],
                end: [{
                    orderIndex: 2,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 275,
                        y: 220,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -55,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 165,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 5,
                    location: {
                        x: -220,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 275,
                        y: -110,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 165,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 0,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 165,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-7",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -165,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: 0,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -220,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -110,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-5",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: 165,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 5,
                    location: {
                        x: -110,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 165,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 2,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }],
                end: [{
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 0,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 2,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }],
                end: [{
                    orderIndex: 5,
                    location: {
                        x: -110,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 2,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }],
                end: [{
                    orderIndex: 2,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -110,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    }
                }]
            }],
            "module-2": [{
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -275,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 9,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 10,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 3,
                    location: {
                        x: -275,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 9,
                    location: {
                        x: -110,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 55,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 165,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -165,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 9,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 10,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 11,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 12,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 11,
                    location: {
                        x: -165,
                        y: 0,
                        z: 0
                    }
                }, {
                    orderIndex: 9,
                    location: {
                        x: -110,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 10,
                    location: {
                        x: 110,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 275,
                        y: -110,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 7,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 8,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 9,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 10,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -275,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -165,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 11,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: 165,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 12,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 3,
                    location: {
                        x: -275,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -220,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 0,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: 165,
                        y: 220,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 8,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 9,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 10,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 11,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 12,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 13,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 14,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 10,
                    location: {
                        x: -110,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 11,
                    location: {
                        x: 55,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 14,
                    location: {
                        x: 110,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 13,
                    location: {
                        x: 275,
                        y: -110,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -275,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 1,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -275,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-7",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -165,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-7",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: 165,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 9,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 10,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 11,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -165,
                        y: 110,
                        z: 0
                    }
                }, {
                    orderIndex: 10,
                    location: {
                        x: -110,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 11,
                    location: {
                        x: 110,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 55,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -165,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-7",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: 165,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-7",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: 55,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 9,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 10,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 11,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 275,
                        y: 110,
                        z: 0
                    }
                }, {
                    orderIndex: 11,
                    location: {
                        x: 220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 10,
                    location: {
                        x: 0,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -165,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -110,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 9,
                    location: {
                        x: 110,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 275,
                        y: 220,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -275,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 9,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 10,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 11,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 12,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }],
                end: [{
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 9,
                    location: {
                        x: 0,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 275,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 12,
                    location: {
                        x: 165,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: 220,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-7",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -55,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 9,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 10,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 11,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 12,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 13,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }],
                end: [{
                    orderIndex: 4,
                    location: {
                        x: 165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 275,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -55,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -275,
                        y: 110,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -165,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 9,
                    location: {
                        x: -110,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 13,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-7",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -165,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 10,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 12,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-7",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-7",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: 55,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 8,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 9,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -275,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }],
                end: [{
                    orderIndex: 8,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -165,
                        y: 0,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -55,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 165,
                        y: 220,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -55,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 9,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 10,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 11,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 1,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -275,
                        y: 110,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -165,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 165,
                        y: 220,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -55,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 7,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 9,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 10,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 11,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 12,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -275,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 13,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }],
                end: [{
                    orderIndex: 10,
                    location: {
                        x: -220,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 0,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -165,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 11,
                    location: {
                        x: -110,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: 110,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 9,
                    location: {
                        x: 110,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 13,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -55,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 12,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -165,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 13,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 13,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 275,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 165,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -55,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 12,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -55,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 9,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 10,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 7,
                    location: {
                        x: 165,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -275,
                        y: 110,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -165,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: 165,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 12,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -165,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 10,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 9,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 11,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 165,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }],
                end: [{
                    orderIndex: 7,
                    location: {
                        x: 275,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 11,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 9,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 10,
                    location: {
                        x: 110,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 165,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 7,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 12,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -165,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 10,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 9,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -165,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 11,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -275,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -165,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 1,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 9,
                    location: {
                        x: -165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 11,
                    location: {
                        x: -275,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -220,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: 0,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 0,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 0,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 275,
                        y: -110,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-5",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -55,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 7,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 9,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 10,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 11,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 12,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 1,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: 110,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 55,
                        y: 110,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -220,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: 275,
                        y: 220,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-5",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -165,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 7,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 9,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 10,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 12,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 11,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -165,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 13,
                    frameName: "car-1-5",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -55,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 13,
                    location: {
                        x: -165,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 9,
                    location: {
                        x: 55,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 12,
                    location: {
                        x: 110,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: 275,
                        y: -110,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-5",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: 165,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 7,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 8,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 9,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 12,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 9,
                    location: {
                        x: -55,
                        y: 0,
                        z: 0
                    }
                }, {
                    orderIndex: 12,
                    location: {
                        x: -220,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 9,
                    location: {
                        x: -55,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 55,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: 165,
                        y: -110,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -55,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -165,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-5",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: 165,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 9,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 10,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 11,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 12,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 13,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 12,
                    location: {
                        x: -220,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 55,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 7,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 9,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 9,
                    location: {
                        x: 110,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -275,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 275,
                        y: 220,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -275,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 9,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 10,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 9,
                    location: {
                        x: -110,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 110,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 275,
                        y: 220,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 165,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 9,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 10,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 1,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 10,
                    location: {
                        x: 0,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -165,
                        y: 110,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -275,
                        y: 110,
                        z: 0
                    }
                }, {
                    orderIndex: 9,
                    location: {
                        x: -220,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 0,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 275,
                        y: 220,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-7",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 9,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 10,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 9,
                    location: {
                        x: -220,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 10,
                    location: {
                        x: -220,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 165,
                        y: 220,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 9,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 10,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 5,
                    location: {
                        x: -220,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 10,
                    location: {
                        x: 110,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 9,
                    location: {
                        x: 110,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 275,
                        y: 220,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 165,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 7,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 8,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 9,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 10,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 2,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 110,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 275,
                        y: 220,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 7,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 8,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 9,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 10,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 11,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 10,
                    location: {
                        x: 0,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 165,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 110,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 7,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 8,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 9,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 10,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 11,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 165,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }],
                end: [{
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 10,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 0,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -220,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 11,
                    location: {
                        x: 0,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 7,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 8,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 9,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 10,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 165,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 11,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 7,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -55,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 9,
                    location: {
                        x: 55,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 10,
                    location: {
                        x: 0,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 275,
                        y: 220,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 7,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 9,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 10,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 11,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 2,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }],
                end: [{
                    orderIndex: 2,
                    location: {
                        x: 165,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 275,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 220,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    }
                }]
            }],
            "module-3": [{
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }],
                end: [{
                    orderIndex: 5,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 165,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 2,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -110,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -275,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: 55,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 2,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -275,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -165,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }],
                end: [{
                    orderIndex: 5,
                    location: {
                        x: 220,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -110,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 165,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 165,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -55,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }],
                end: [{
                    orderIndex: 5,
                    location: {
                        x: 110,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -275,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -55,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -220,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 55,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -55,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 7,
                    location: {
                        x: 110,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 110,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -275,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -220,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 165,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 3,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 0,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 7,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }],
                end: [{
                    orderIndex: 2,
                    location: {
                        x: 165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 165,
                        y: 0,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 220,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -220,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 165,
                        y: -110,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 165,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }],
                end: [{
                    orderIndex: 4,
                    location: {
                        x: 165,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 275,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 220,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -55,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 55,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -220,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 7,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }],
                end: [{
                    orderIndex: 6,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 275,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -220,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-5",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -55,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-7",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -165,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 2,
                    location: {
                        x: 110,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 55,
                        y: 110,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 275,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -220,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 55,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 165,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 2,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -55,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 7,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 3,
                    location: {
                        x: 110,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 110,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 165,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 110,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -220,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -220,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 2,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -55,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-7",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -55,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 7,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 5,
                    location: {
                        x: -165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -165,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 110,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 275,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -220,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 165,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 55,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 55,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 165,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 2,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-5",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -165,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 7,
                    location: {
                        x: 220,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -165,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 165,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 165,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: 0,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -220,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 165,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 2,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 7,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 3,
                    location: {
                        x: 220,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 220,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 165,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -220,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -220,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 165,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 2,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 3,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 165,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -165,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -110,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 2,
                    frameName: "car-1-5",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: 55,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-7",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -165,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 7,
                    location: {
                        x: 110,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -55,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 165,
                        y: 110,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 275,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -220,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 165,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 2,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -55,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 3,
                    location: {
                        x: 110,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 165,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 110,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -275,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -220,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -55,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-5",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -165,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }],
                end: [{
                    orderIndex: 4,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 165,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -55,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 55,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 220,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -275,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -165,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 2,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 3,
                    location: {
                        x: 220,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 220,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 275,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -110,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -110,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -110,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 165,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 2,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 4,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 220,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 165,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -110,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -110,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 2,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 165,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -55,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 4,
                    location: {
                        x: 110,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 165,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -275,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -220,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 5,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -55,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-5",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -165,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 1,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 5,
                    location: {
                        x: 55,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -275,
                        y: 110,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -165,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 55,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 165,
                        y: 110,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 165,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -275,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 165,
                        y: -110,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -165,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 3,
                    location: {
                        x: -110,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 110,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 55,
                        y: 0,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 275,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -275,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -220,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 220,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 7,
                    frameName: "car-1-7",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -165,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 8,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 2,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 1,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 5,
                    location: {
                        x: -165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: 110,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 0,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 165,
                        y: 0,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -165,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -220,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -165,
                        y: 0,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 165,
                        y: -110,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 2,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 165,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-5",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: 55,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 1,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 5,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 165,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -165,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -165,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -110,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 275,
                        y: -110,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 165,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -55,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 2,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 8,
                    location: {
                        x: 110,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 165,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 110,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -275,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -220,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 2,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 165,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -275,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 1,
                    frameName: "car-1-5",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: 55,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -165,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 7,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 1,
                    location: {
                        x: -55,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 165,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -55,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 165,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 110,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -275,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -55,
                        y: 110,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 0,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 0,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -55,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 165,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 2,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -275,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 8,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 8,
                    location: {
                        x: 220,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 275,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -110,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -110,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 2,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 165,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-5",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-7",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -165,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 4,
                    location: {
                        x: -165,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 275,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 55,
                        y: 110,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -55,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -55,
                        y: 0,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 55,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 165,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 4,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 165,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 1,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 2,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 275,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 8,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 6,
                    location: {
                        x: 220,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 275,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 275,
                        y: 0,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 220,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -110,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -110,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 275,
                        y: -110,
                        z: 0
                    }
                }]
            }],
            "module-4": [{
                style: 1,
                start: [{
                    orderIndex: 2,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 1,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -275,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-7",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -55,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 7,
                    frameName: "car-1-7",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -165,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 6,
                    location: {
                        x: 165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -275,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: -55,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -110,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -275,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 220,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -275,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -275,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 6,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 2,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -55,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -275,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 1,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 7,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -165,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 2,
                    location: {
                        x: 165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 165,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -275,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -55,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -110,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -275,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 55,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 220,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -275,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -275,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -165,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 3,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 2,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 1,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: 165,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 7,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 4,
                    location: {
                        x: 55,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 275,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 220,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -275,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: 110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -110,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -275,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -55,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 55,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -220,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 6,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 1,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 8,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -165,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 7,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: -55,
                        y: 0,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 0,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 165,
                        y: 0,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: -55,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 0,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -165,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -220,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 0,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -165,
                        y: 0,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 165,
                        y: -220,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 165,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 2,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 6,
                    location: {
                        x: -55,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -275,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -165,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -55,
                        y: 0,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: 0,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -110,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 55,
                        y: 0,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 165,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -275,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -220,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -55,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -275,
                        y: 0,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -165,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 3,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 2,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -275,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -55,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 8,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -165,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 1,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 7,
                    location: {
                        x: 165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -275,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -55,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -110,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -275,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 220,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -275,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -275,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -275,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -55,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -165,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 8,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 4,
                    location: {
                        x: 165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: 220,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -275,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -55,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -110,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -275,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 55,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 220,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -275,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -275,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 2,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 165,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 1,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 4,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: 220,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 165,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 275,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -220,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 165,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 2,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 8,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 5,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 220,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 220,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 165,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -220,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -220,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 2,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 7,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 8,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }],
                end: [{
                    orderIndex: 7,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 275,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -220,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 165,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 8,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 1,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 2,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -55,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 7,
                    frameName: "car-1-5",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -55,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 6,
                    location: {
                        x: -165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -165,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 55,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 110,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 165,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 275,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -55,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -220,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 165,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: 110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 55,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 55,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 4,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 2,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 1,
                    frameName: "car-1-5",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: 165,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 7,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 275,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: 220,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -275,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -110,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -275,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -220,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 2,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 8,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -165,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 0,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -165,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: 0,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 0,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 165,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 165,
                        y: 110,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: 165,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 110,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -220,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -165,
                        y: 110,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -55,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 165,
                        y: 220,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 3,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 2,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 1,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-5",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: 55,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 7,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 8,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 8,
                    location: {
                        x: -165,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: 0,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 110,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 275,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 220,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -220,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 110,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 55,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 2,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 165,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -55,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 8,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 1,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 6,
                    location: {
                        x: -55,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -275,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -165,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -55,
                        y: 0,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 55,
                        y: 0,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: -110,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 55,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 55,
                        y: 110,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 165,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -275,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: -220,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -55,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -275,
                        y: 110,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -165,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 2,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 5,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 220,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 220,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 275,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -220,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -220,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 7,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 2,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-5",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 1,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 5,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -275,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -55,
                        y: 0,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 55,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: -110,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 55,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 165,
                        y: 0,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -55,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -275,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: -220,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -275,
                        y: 0,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 165,
                        y: -110,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 8,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-5",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 2,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 1,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 6,
                    location: {
                        x: -55,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -275,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -165,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -55,
                        y: 0,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 55,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: -110,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 165,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 165,
                        y: 0,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 165,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -275,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: -220,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -55,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 165,
                        y: 220,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 4,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 1,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 2,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 7,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 8,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -55,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 6,
                    location: {
                        x: -165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -220,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: 0,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 110,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 275,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 220,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -220,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 110,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 55,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -275,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-5",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -55,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-7",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -165,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -165,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 4,
                    location: {
                        x: 165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 165,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -275,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -55,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -110,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -275,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 55,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 220,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -275,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -275,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -165,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 2,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: 165,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 7,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 8,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 8,
                    location: {
                        x: -275,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 275,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 220,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -110,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -275,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -220,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 165,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 2,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -275,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-5",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: 55,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 3,
                    location: {
                        x: 165,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -55,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 165,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -275,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -165,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -275,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -165,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 165,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-5",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -165,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 8,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 2,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 2,
                    location: {
                        x: 220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: 0,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -55,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -275,
                        y: 0,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -165,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -110,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: 0,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -275,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -55,
                        y: 0,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 165,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 2,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: 0,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 7,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 8,
                    frameName: "car-1-5",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -165,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 7,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -165,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -55,
                        y: 0,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 0,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 165,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 165,
                        y: 0,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: 165,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 0,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -220,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -55,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 0,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -165,
                        y: 0,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -165,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 165,
                        y: 220,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 3,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -275,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 2,
                    frameName: "car-1-5",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: 55,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-7",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -165,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 1,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 2,
                    location: {
                        x: -55,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -275,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -110,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -275,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 165,
                        y: 110,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: 220,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -275,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -275,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 165,
                        y: -110,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 165,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 2,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-5",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: 55,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 8,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: -220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 3,
                    location: {
                        x: 165,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -55,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 165,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -165,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -55,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -165,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 165,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -55,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -55,
                        y: -110,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -165,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 2,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 1,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 165,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -165,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-5",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -165,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 7,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 7,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: 0,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 0,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 165,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 165,
                        y: 0,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 0,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -165,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -220,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 0,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 0,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -165,
                        y: 110,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 165,
                        y: -110,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 3,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 2,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 220,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 1,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 5,
                    frameName: "car-1-6",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -55,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-5",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-2",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: -110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-3",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 7,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 8,
                    location: {
                        x: -275,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: 0,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 110,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 275,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 220,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -220,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 110,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 55,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 275,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 6,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -55,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 3,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: 110,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-5",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 4,
                    frameName: "car-1-4",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -275,
                        y: 110,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 8,
                    location: {
                        x: -275,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 55,
                        y: 0,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 110,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 55,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 275,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 220,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 55,
                        y: 0,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 165,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -110,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: 110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: 110,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -275,
                        y: 0,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -220,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 275,
                        y: -165,
                        z: 0
                    }
                }]
            }, {
                style: 1,
                start: [{
                    orderIndex: 1,
                    frameName: "car-1-7",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 7,
                    frameName: "car-1-6",
                    angle: 0,
                    distance: 3,
                    location: {
                        x: -275,
                        y: 55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 4,
                    frameName: "car-1-5",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -55,
                        y: -55,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 6,
                    frameName: "car-1-7",
                    angle: 270,
                    distance: 3,
                    location: {
                        x: -165,
                        y: -275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 5,
                    frameName: "car-1-4",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: -165,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }, {
                    orderIndex: 3,
                    frameName: "car-1-1",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    },
                    isMain: !0,
                    isLandscape: !0
                }, {
                    orderIndex: 2,
                    frameName: "car-1-3",
                    angle: 0,
                    distance: 2,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !1
                }, {
                    orderIndex: 8,
                    frameName: "car-1-2",
                    angle: 270,
                    distance: 2,
                    location: {
                        x: -220,
                        y: 275,
                        z: 0
                    },
                    isMain: !1,
                    isLandscape: !0
                }],
                end: [{
                    orderIndex: 4,
                    location: {
                        x: 165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: 220,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: 165,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -275,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -55,
                        y: -220,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: -110,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -275,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 55,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 8,
                    location: {
                        x: 220,
                        y: 275,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 55,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: 165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -275,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -220,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 2,
                    location: {
                        x: -55,
                        y: 220,
                        z: 0
                    }
                }, {
                    orderIndex: 3,
                    location: {
                        x: -110,
                        y: 55,
                        z: 0
                    }
                }, {
                    orderIndex: 7,
                    location: {
                        x: -275,
                        y: 165,
                        z: 0
                    }
                }, {
                    orderIndex: 4,
                    location: {
                        x: -165,
                        y: -55,
                        z: 0
                    }
                }, {
                    orderIndex: 5,
                    location: {
                        x: -110,
                        y: -165,
                        z: 0
                    }
                }, {
                    orderIndex: 6,
                    location: {
                        x: -165,
                        y: -275,
                        z: 0
                    }
                }, {
                    orderIndex: 1,
                    location: {
                        x: 55,
                        y: -165,
                        z: 0
                    }
                }]
            }]
        },
        cc._RF.pop()
    }
    , {}],
    jianglIItem: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "47a03LZ1e5IKYYeIInToS4G", "jianglIItem");
        var o = e("../../Utils")
          , i = e("../../TweenClass");
        cc.Class({
            extends: cc.Component,
            properties: {
                guang: {
                    default: null,
                    type: cc.Node,
                    displayName: "光圈"
                },
                jiangLi_Count: {
                    default: null,
                    type: cc.Label,
                    displayName: "奖励的数量"
                }
            },
            onLoad: function() {
                i.TweenClass.scale_3_1_Tween(this.node.children[1]),
                o.SoundMgr.playEffect("jiangli")
            },
            start: function() {},
            update: function(e) {
                this.guang.angle += 1
            },
            closeNode: function() {
                o.SoundMgr.playEffect("button"),
                i.TweenClass.scale_close_Tween(this.node.children[1])
            },
            setJiangLi_Count: function(e) {
                this.jiangLi_Count.string = e,
                e = e.toString().replace("/", ""),
                cc.StorageInfo.sum_Money += parseInt(e),
                cc.setMoney()
            }
        }),
        cc._RF.pop()
    }
    , {
        "../../TweenClass": "TweenClass",
        "../../Utils": "Utils"
    }],
    levelItem: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "55015atCrVJxKDMJ+skG+rS", "levelItem");
        var o = e("../../Utils");
        cc.Class({
            extends: cc.Component,
            properties: {
                level_img: {
                    default: null,
                    type: cc.Sprite,
                    displayName: "关卡图片"
                },
                NO_label: {
                    default: null,
                    type: cc.Label,
                    displayName: "第几关"
                }
            },
            onLoad: function() {},
            start: function() {},
            click_level: function(e) {
                o.SoundMgr.playEffect("button");
                var n = e.target.name;
                n.split("-").length > 1 ? console.log("未解锁") : (console.log(n),
                cc.StorageInfo.click_Leve = parseInt(n),
                cc.director.loadScene("Playing"))
            },
            updateLevel: function(e) {
                e < 10 && (e = "0".concat(e)),
                this.NO_label.string = e;
                var n = cc.StorageInfo.Module[cc.StorageInfo.click_ModuleName];
                e = parseInt(e);
                var a = null;
                this.node.name = "".concat(e),
                e < n.now_Leve ? a = "level-guo" : e === n.now_Leve ? a = "level-dangqian" : (a = "level-suo",
                this.node.name = "".concat(e, "-suo"),
                this.NO_label.node.active = !1),
                o.AssMgr.setSpriteFrameByName(this.level_img, a)
            }
        }),
        cc._RF.pop()
    }
    , {
        "../../Utils": "Utils"
    }],
    modelItem: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "8f23cBOdGdPtKXHkS/VsDDb", "modelItem");
        var o = e("../../Utils");
        cc.Class({
            extends: cc.Component,
            properties: {
                guanShu: {
                    default: null,
                    type: cc.Node,
                    displayName: "关数"
                },
                suo: {
                    default: null,
                    type: cc.Node,
                    displayName: "锁"
                },
                model_img: {
                    default: null,
                    type: cc.Node,
                    displayName: "模式图"
                },
                nanDu: {
                    default: null,
                    type: cc.Sprite,
                    displayName: "模式的难度"
                }
            },
            onLoad: function() {
                this.guanShu.active = !1
            },
            start: function() {},
            click_Model: function(e) {
                var n = this;
                o.SoundMgr.playEffect("button");
                var a = e.target.name
                  , i = a.split("-");
                if (i.length > 1) {
                    console.log("看视频解锁,解锁");
                    cc.PlatformUtils.executeShowVideo(function() {
                        cc.StorageInfo.Module_suo[i[0] - 1] = !0,
                        console.log(cc.StorageInfo.Module_suo),
                        n.node.name = "".concat(i[0]),
                        n.suo.active = !1
                    })
                } else
                    console.log(a),
                    cc.StorageInfo.click_ModuleName = "module-".concat(a),
                    o.AssMgr.createPrefabByName("xuanGuan", function(e) {
                        var n = cc.instantiate(e);
                        cc.director.getScene().addChild(n)
                    })
            },
            updateModel: function(e) {
                this.node.name = "".concat(e, "-suo"),
                cc.StorageInfo.Module_suo[e - 1] && (this.node.name = "".concat(e),
                this.suo.active = !1,
                this.guanShu.active = !0),
                cc.PlatformUtils.RemoteConfig.isLine || (this.node.name = "".concat(e),
                this.suo.active = !1,
                this.guanShu.active = !0),
                o.AssMgr.setSpriteFrameByName(this.model_img.getComponent(cc.Sprite), "model-".concat(e)),
                o.AssMgr.setSpriteFrameByName(this.nanDu, "nandu-".concat(e)),
                this.guanShu.children[0].getComponent(cc.Label).string = cc.StorageInfo.Module["module-".concat(e)].now_Leve,
                this.guanShu.children[1].getComponent(cc.Label).string = cc.StorageInfo.Module["module-".concat(e)].sumLevel
            }
        }),
        cc._RF.pop()
    }
    , {
        "../../Utils": "Utils"
    }],
    oppoUtil: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "f4278HbWEJAgL9zVOLtF+DN", "oppoUtil"),
        window.ysOppo = {
            createChapingOPPO: function(e, n, a) {
                console.log("createchaping  ");
                var o = cc.view.getVisibleSize()
                  , i = (cc.v2(o.width / 2, o.height / 2),
                new cc.Node);
                i.parent = cc.director.getScene(),
                i.zIndex = cc.macro.MAX_ZINDEX,
                i.setContentSize(cc.winSize);
                var t = new cc.Texture2D
                  , r = new cc.SpriteFrame;
                t.initWithData(new Uint8Array([0, 0, 0]), cc.Texture2D.PixelFormat.RGB888, 1, 1, cc.winSize),
                r.setTexture(t),
                r.setRect(cc.rect(0, 0, 20 * cc.winSize.width, 20 * cc.winSize.width));
                var c = new cc.Node;
                c.parent = i,
                c.opacity = 1,
                c.addComponent(cc.Sprite).spriteFrame = r,
                c.on("touchend", function(e) {});
                var d = new cc.Node;
                d.parent = i,
                d.x = .5 * o.width,
                d.y = .5 * o.height;
                var s = d.addComponent(cc.Sprite);
                t = new cc.Texture2D,
                r = new cc.SpriteFrame,
                t.initWithData(new Uint8Array([0, 0, 0]), cc.Texture2D.PixelFormat.RGB888, 1, 1, cc.winSize),
                r.setTexture(t),
                r.setRect(cc.rect(0, 0, 500, 400)),
                s.spriteFrame = r,
                s.sizeMode = cc.Sprite.SizeMode.Custom,
                cc.loader.load(e, function(e, n) {
                    s.spriteFrame = new cc.SpriteFrame(n)
                });
                var l = new cc.Node;
                l.parent = i,
                l.x = .5 * o.width,
                l.y = .5 * o.height;
                var x = l.addComponent(cc.Sprite);
                cc.loader.loadRes("textures/ysguanggao/bj", function(e, n) {
                    x.spriteFrame = new cc.SpriteFrame(n)
                }),
                l.on(cc.Node.EventType.TOUCH_END, function(e) {
                    console.log("ad click"),
                    a && a(),
                    i.removeFromParent()
                }),
                d.on(cc.Node.EventType.TOUCH_END, function(e) {
                    console.log("ad click"),
                    a && a(),
                    i.removeFromParent()
                });
                var m = new cc.Node;
                m.parent = i,
                m.x = o.width / 2 + 230,
                m.y = o.height / 2 + 160,
                m.sizeMode = cc.Sprite.SizeMode.Custom,
                cc.loader.loadRes("textures/ysguanggao/native_3", function(e, n) {
                    m.addComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(n)
                });
                var f = new cc.Node;
                f.parent = i,
                f.x = o.width / 2 + 210,
                f.y = o.height / 2 - 90,
                cc.loader.loadRes("textures/ysguanggao/native_1", function(e, n) {
                    f.addComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(n)
                });
                var y = new cc.Node;
                y.parent = i,
                y.x = o.width / 2,
                y.y = o.height / 2 - 150,
                y.scale = 1.2,
                cc.loader.loadRes("textures/ysguanggao/native_5", function(e, n) {
                    y.addComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(n)
                }),
                y.on(cc.Node.EventType.TOUCH_END, function(e) {
                    console.log("ad click"),
                    a && a(),
                    i.removeFromParent()
                });
                var h = new cc.Node;
                return h.parent = i,
                h.opacity = 1,
                h.x = o.width / 2 + 230,
                h.y = o.height / 2 + 160,
                h.scale = window.ServerConfigBd.closeBtnScale,
                cc.loader.loadRes("textures/ysguanggao/native_3", function(e, n) {
                    h.addComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(n)
                }),
                h.on(cc.Node.EventType.TOUCH_END, function(e) {
                    console.log("closeBtn click"),
                    n && n(),
                    i.removeFromParent()
                }),
                i
            },
            createBannerOppo: function(e, n, a) {
                var o = cc.view.getVisibleSize()
                  , i = (cc.v2(o.width / 2, o.height / 2),
                new cc.Node);
                i.parent = cc.director.getScene(),
                i.zIndex = cc.macro.MAX_ZINDEX,
                i.setContentSize(cc.winSize);
                var t = new cc.Node;
                t.parent = i,
                t.x = .5 * o.width,
                t.y = .05 * o.height;
                var r = t.addComponent(cc.Sprite)
                  , c = new cc.Texture2D
                  , d = new cc.SpriteFrame;
                c.initWithData(new Uint8Array([0, 0, 0]), cc.Texture2D.PixelFormat.RGB888, 1, 1, cc.winSize),
                d.setTexture(c),
                d.setRect(cc.rect(0, 0, cc.winSize.width, .1 * cc.winSize.height)),
                r.spriteFrame = d,
                r.sizeMode = cc.Sprite.SizeMode.CUSTOM,
                cc.loader.load(e, function(e, n) {
                    r.spriteFrame = new cc.SpriteFrame(n)
                }),
                t.on(cc.Node.EventType.TOUCH_END, function(e) {
                    console.log("ad click"),
                    a && a(),
                    i.removeFromParent()
                });
                var s = new cc.Node;
                s.parent = i,
                s.x = o.width / 2 + 250,
                s.y = .09 * o.height,
                cc.loader.loadRes("textures/ysguanggao/native_3", function(e, n) {
                    s.addComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(n)
                });
                var l = new cc.Node;
                return l.parent = i,
                l.x = o.width / 2 + 250,
                l.y = .02 * o.height,
                cc.loader.loadRes("textures/ysguanggao/native_1", function(e, n) {
                    l.addComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(n)
                }),
                s.on(cc.Node.EventType.TOUCH_END, function(e) {
                    console.log("closeBtn click"),
                    n && n(),
                    i.removeFromParent()
                }),
                i
            }
        },
        window.oppoUtil = {
            shipinID: "446245",
            bannerID: "446230",
            yuanshengID1: "446238",
            yuanshengID2: "446240",
            yuanshengID3: "446243",
            MoreID: "446247",
            rewardedVideoAd: null,
            AdSuccess: function() {
                null != oppoUtil.videoCallback && (oppoUtil.videoCallback(),
                oppoUtil.videoCallback = null)
            },
            Adfail: function() {
                null != oppoUtil.videoCallbackfail && (oppoUtil.videoCallbackfail(),
                oppoUtil.videoCallbackfail = null)
            },
            yuanshengIndex: 0,
            ysOppoADK: null,
            isVideo: !1,
            isFrist: !0,
            isShowChaping: 0,
            portalInstance: null,
            bannerNative: null,
            chapingnativeAd: null,
            lfenzhong: !1,
            SHOWIndex: 0,
            initQQShow: function() {
                window.ServerConfigBd = window.GameConfig,
                window.ServerConfigBd.open1fz ? oppoUtil.lfenzhong = !0 : setTimeout(function() {
                    oppoUtil.lfenzhong = !0
                }, 6e4),
                1 == window.ServerConfigBd.updateAd && setInterval(function() {
                    oppoUtil.createNativead()
                }, window.ServerConfigBd.updateTime)
            },
            getVideoAd: function(e, n) {
                this.videoCallback = e,
                this.videoCallbackfail = n,
                null == oppoUtil.rewardedVideoAd ? oppoUtil.rewardedVideoAd = qg.createRewardedVideoAd({
                    adUnitId: oppoUtil.shipinID
                }) : (oppoUtil.rewardedVideoAd.offLoad(),
                oppoUtil.rewardedVideoAd.offError(),
                oppoUtil.rewardedVideoAd.offClose()),
                oppoUtil.rewardedVideoAd.load().then(function() {
                    console.log("激励视频广告load成功"),
                    oppoUtil.rewardedVideoAd.show().then(function() {
                        console.log("激励视频广告显示成功"),
                        oppoUtil.isVideo = !0
                    }).catch(function(e) {
                        console.log("激励视频广告显示失败", e),
                        oppoUtil.Adfail(),
                        qg.showToast({
                            message: "稍后再试。。"
                        })
                    })
                }).catch(function(e) {
                    console.log("激励视频广告load失败" + JSON.stringify(e)),
                    oppoUtil.Adfail(),
                    qg.showToast({
                        title: "稍后再试。。",
                        icon: "none",
                        duration: 2e3
                    })
                }),
                oppoUtil.rewardedVideoAd.onError(function(e) {
                    console.log(e),
                    oppoUtil.Adfail()
                }),
                oppoUtil.rewardedVideoAd.onClose(function(e) {
                    e && e.isEnded ? (oppoUtil.isVideo = !1,
                    oppoUtil.AdSuccess(),
                    console.log("vivo videoad play success22222222222222")) : (window.ServerConfigBd.showModal ? (window.qg.showModal({
                        title: "未观看完视频",
                        content: "观看完视频才能获得奖励哦",
                        success: function(e) {
                            e.confirm ? oppoUtil.rewardedVideoAd.show().then(function() {
                                console.log("激励视频 广告显示")
                            }).catch(function() {
                                oppoUtil.rewardedVideoAd.load().then(function() {
                                    oppoUtil.rewardedVideoAd.show()
                                }).catch(function(e) {
                                    oppoUtil.Adfail(),
                                    console.log("激励视频 广告显示失败")
                                })
                            }) : e.cancel && oppoUtil.Adfail()
                        },
                        fail: function(e) {
                            oppoUtil.Adfail()
                        }
                    }),
                    console.log("激励视频广告取消关闭，不发放奖励")) : oppoUtil.Adfail(),
                    oppoUtil.isVideo = !1,
                    console.log("vivo videoad play cancel"))
                })
            },
            GaiLv: function(e) {
                return 1 + Math.floor(100 * Math.random()) <= e
            },
            showAd_Banner: function() {
                oppoUtil.lfenzhong ? (oppoUtil.clearAD(),
                oppoUtil.isShowChaping++,
                oppoUtil.GaiLv(window.ServerConfigBd.ShowPopCp) ? oppoUtil.createNativeadChaping() : oppoUtil.createNativeadBanner()) : console.log("1分钟限制中-------")
            },
            showMoreGame: function() {
                oppoUtil.clearAD(),
                oppoUtil.portalInstance ? oppoUtil.portalInstance.show() : (oppoUtil.yujiazai(),
                qg.showToast({
                    title: "暂时没有更多游戏",
                    icon: "none",
                    duration: 2e3
                }))
            },
            yujiazai: function() {
                var e = window.qg.createGamePortalAd({
                    adUnitId: oppoUtil.MoreID
                });
                e.onLoad(function() {
                    oppoUtil.portalInstance = e
                }),
                e.onClose(function() {
                    console.log("关闭更多游戏"),
                    oppoUtil.portalInstance && (oppoUtil.portalInstance.destroy(),
                    oppoUtil.portalInstance = null),
                    oppoUtil.yujiazai()
                }),
                e.load()
            },
            showAdInGame: function() {
                oppoUtil.lfenzhong ? oppoUtil.GaiLv(window.ServerConfigBd.ShowInGameCp) && oppoUtil.createNativeadChaping(!1) : console.log("1分钟限制中-------")
            },
            showAd_ChaPing: function() {
                oppoUtil.lfenzhong ? oppoUtil.GaiLv(window.ServerConfigBd.ShowJieSuanCp) ? oppoUtil.createNativeadChaping() : oppoUtil.createNativeadBanner() : console.log("1分钟限制中-------")
            },
            showBanner: function() {
                oppoUtil.clearAD(),
                oppoUtil.bannerAd = qg.createBannerAd({
                    adUnitId: oppoUtil.bannerID
                }),
                oppoUtil.bannerAd.onError(function(e) {
                    console.log(e),
                    oppoUtil.GaiLv(window.ServerConfigBd.quitShow) && oppoUtil.createNativeadBanner()
                }),
                oppoUtil.bannerAd.show()
            },
            closeBanner: function() {
                oppoUtil.clearAD()
            },
            clearAD: function() {
                oppoUtil.bannerAd && oppoUtil.bannerAd.hide(),
                oppoUtil.ysOppoADK && oppoUtil.ysOppoADK.destroy()
            },
            createNativeadChaping: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                oppoUtil.chapingnativeAd && (oppoUtil.chapingnativeAd.offLoad(),
                oppoUtil.chapingnativeAd.offError(),
                oppoUtil.chapingnativeAd = null);
                var n = [oppoUtil.yuanshengID1, oppoUtil.yuanshengID2, oppoUtil.yuanshengID3];
                oppoUtil.yuanshengIndex += 1,
                oppoUtil.yuanshengIndex >= n.length && (oppoUtil.yuanshengIndex = 0),
                oppoUtil.chapingnativeAd = qg.createNativeAd({
                    adUnitId: n[oppoUtil.yuanshengIndex]
                }),
                oppoUtil.chapingnativeAd.onLoad(function(n) {
                    oppoUtil.chapingnativeAd.offLoad(),
                    oppoUtil.chapingnativeAd.reportAdShow({
                        adId: n.adList[0].adId
                    }),
                    oppoUtil.clearAD(),
                    oppoUtil.ysOppoADK = ysOppo.createChapingOPPO(n.adList[0].imgUrlList[0], function() {
                        oppoUtil.chapingnativeAd.offLoad(),
                        oppoUtil.chapingnativeAd.offError(),
                        oppoUtil.ysOppoADK = null,
                        oppoUtil.GaiLv(window.ServerConfigBd.quitShow) && !e && oppoUtil.createNativeadBanner()
                    }, function() {
                        oppoUtil.chapingnativeAd.reportAdClick({
                            adId: n.adList[0].adId
                        }),
                        oppoUtil.chapingnativeAd.offLoad(),
                        oppoUtil.chapingnativeAd.offError(),
                        oppoUtil.ysOppoADK = null,
                        oppoUtil.GaiLv(window.ServerConfigBd.quitShow) && !e && oppoUtil.createNativeadBanner()
                    })
                }),
                oppoUtil.chapingnativeAd.onError(function(n) {
                    oppoUtil.chapingnativeAd.offLoad(),
                    oppoUtil.chapingnativeAd.offError(),
                    oppoUtil.chapingnativeAd = null,
                    console.log("插屏显示错误了----" + JSON.stringify(n)),
                    oppoUtil.GaiLv(window.ServerConfigBd.quitShow) && !e && oppoUtil.showBanner()
                }),
                oppoUtil.chapingnativeAd.load()
            },
            createNativeadBanner: function() {
                oppoUtil.bannerNative && (oppoUtil.bannerNative.offLoad(),
                oppoUtil.bannerNative.offError(),
                oppoUtil.bannerNative = null),
                oppoUtil.clearAD();
                var e = [oppoUtil.yuanshengID1, oppoUtil.yuanshengID2, oppoUtil.yuanshengID3];
                oppoUtil.yuanshengIndex += 1,
                oppoUtil.yuanshengIndex >= e.length && (oppoUtil.yuanshengIndex = 0),
                oppoUtil.bannerNative = qg.createNativeAd({
                    adUnitId: e[oppoUtil.yuanshengIndex]
                }),
                oppoUtil.bannerNative.onLoad(function(e) {
                    oppoUtil.bannerNative.reportAdShow({
                        adId: e.adList[0].adId
                    }),
                    oppoUtil.clearAD(),
                    oppoUtil.ysOppoADK = ysOppo.createBannerOppo(e.adList[0].imgUrlList[0], function() {
                        oppoUtil.bannerNative.offLoad(),
                        oppoUtil.bannerNative.offError(),
                        oppoUtil.ysOppoADK = null
                    }, function() {
                        oppoUtil.bannerNative.reportAdClick({
                            adId: e.adList[0].adId
                        }),
                        oppoUtil.bannerNative.offLoad(),
                        oppoUtil.bannerNative.offError(),
                        oppoUtil.ysOppoADK = null
                    })
                }),
                oppoUtil.bannerNative.onError(function(e) {
                    oppoUtil.bannerNative.offLoad(),
                    oppoUtil.bannerNative.offError(),
                    console.log("调用banner错误了===" + JSON.stringify(e)),
                    oppoUtil.GaiLv(window.ServerConfigBd.quitShow) && oppoUtil.showBanner()
                }),
                oppoUtil.bannerNative.load()
            },
            createNativead: function() {
                var e = [oppoUtil.yuanshengID1, oppoUtil.yuanshengID2, oppoUtil.yuanshengID3];
                oppoUtil.yuanshengIndex += 1,
                oppoUtil.yuanshengIndex >= e.length && (oppoUtil.yuanshengIndex = 0);
                var n = qg.createNativeAd({
                    adUnitId: e[oppoUtil.yuanshengIndex]
                });
                n.onLoad(function(e) {
                    n.offLoad(),
                    n.reportAdShow({
                        adId: e.adList[0].adId
                    })
                }),
                n.onError(function(e) {}),
                n.load()
            }
        },
        cc._RF.pop()
    }
    , {}],
    pushHintItem: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "b09c0d9ovhLt7839Lf7VW+J", "pushHintItem");
        var o = e("../../TweenClass")
          , i = e("../../Utils");
        cc.Class({
            extends: cc.Component,
            properties: {},
            onLoad: function() {
                cc.click_count = 0,
                o.TweenClass.scale_3_1_Tween(this.node.children[1])
            },
            start: function() {
                cc.PlatformUtils.executeShowBanner(cc.v2(cc.view.getVisibleSize().width / 2, cc.view.getVisibleSize().height), cc.v2(.5, 0)),
                cc.PlatformUtils.executeShowInterstitial(!0)
            },
            button_Click: function(e) {
                switch (i.SoundMgr.playEffect("button"),
                e.target.name) {
                case "chakan":
                    console.log("查看广告");
                    cc.PlatformUtils.executeShowVideo(function() {
                        cc.time_count = null,
                        cc.isHint = !0,
                        cc.carInit(),
                        cc.hint()
                    });
                    break;
                case "fangqi":
                    cc.PlatformUtils.excuteRandSuiji(),
                    cc.isHint = !1,
                    cc.time_count = 1
                }
                cc.director.getScene().resumeSystemEvents(!0),
                o.TweenClass.scale_close_Tween(this.node.children[1])
            }
        }),
        cc._RF.pop()
    }
    , {
        "../../TweenClass": "TweenClass",
        "../../Utils": "Utils"
    }],
    putong: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "0b1e4tp6jNLxbZsMAd0Frpi", "putong");
        var o = e("../../../Utils")
          , i = e("../../../TweenClass");
        cc.Class({
            extends: cc.Component,
            properties: {
                first_Day: {
                    default: null,
                    type: cc.Node,
                    displayName: "第几天"
                },
                DayBack_1: {
                    default: null,
                    type: cc.Sprite,
                    displayName: "第几天的背景"
                },
                DayBack_2: {
                    default: null,
                    type: cc.Sprite,
                    displayName: "第几天的背景"
                },
                jiangLi_Count: {
                    default: null,
                    type: cc.Label,
                    displayName: "奖励的数量"
                },
                yiQianDao_img: {
                    default: null,
                    type: cc.Node,
                    displayName: "已签到的图"
                }
            },
            onLoad: function() {},
            start: function() {},
            init: function(e, n, a) {
                var t = (new Date).getDate()
                  , r = null;
                if ("string" == typeof a && (r = parseInt(a.split("-")[1])),
                "string" == typeof n) {
                    var c = n.split("-");
                    n = parseInt(c[0])
                }
                this.yiQianDao_img.active = !1,
                o.AssMgr.setSpriteFrameByName(this.first_Day.getComponent(cc.Sprite), "tianshu_".concat(e)),
                this.jiangLi_Count.string = "/".concat(100 * e);
                var d = "lanse";
                2 === n && (this.yiQianDao_img.active = !0),
                1 === n && (d = "huangkuang",
                r || i.TweenClass.scale_2_Tween(this.node)),
                r && t === r && (d = "lanse"),
                o.AssMgr.setSpriteFrameByName(this.DayBack_2, d)
            }
        }),
        cc._RF.pop()
    }
    , {
        "../../../TweenClass": "TweenClass",
        "../../../Utils": "Utils"
    }],
    victory: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "7539dV2ellPLIvwQ078bkkO", "victory");
        var o = e("../../TweenClass")
          , i = e("../../../resources/Platform/PlatformUtils")
          , t = e("../../Utils");
        cc.Class({
            extends: cc.Component,
            properties: {
                light: {
                    default: null,
                    type: cc.Node,
                    displayName: "光"
                },
                fx: {
                    default: null,
                    type: cc.Node,
                    displayName: "分享"
                }
            },
            onLoad: function() {
                cc.StorageInfo.click_Leve >= cc.StorageInfo.Module[cc.StorageInfo.click_ModuleName].now_Leve && (cc.StorageInfo.Module[cc.StorageInfo.click_ModuleName].now_Leve += 1),
                cc.StorageInfo.sum_Money += 30,
                o.TweenClass.scale_3_1_Tween(this.node.children[1]),
                this.fx.active = !1,
                t.SoundMgr.playEffect("victory")
            },
            start: function() {
                (cc.sys.localStorage.setItem(i.App.storageName, JSON.stringify(cc.StorageInfo)),
                cc.PlatformUtils.executeStopRecorder(),
                cc.PlatformUtils.PlatformCode === i.PlatformList.头条) && (this.fx.active = !0,
                o.TweenClass.shake_Tween(this.fx),
                t.MathMgr.getRandomNum(0, 100) < cc.PlatformUtils.RemoteConfig.randomPush && t.AssMgr.createPrefabByName("FengXiang", function(e) {
                    var n = cc.instantiate(e);
                    cc.director.getScene().addChild(n)
                }));
                window.qg ? cc.PlatformUtils.executeShowVivoChaPing() : cc.PlatformUtils.executeShowBanner(cc.v2(cc.view.getVisibleSize().width / 2, cc.view.getVisibleSize().height), cc.v2(.5, 0)),
                cc.PlatformUtils.executeShowInterstitial(!0)
            },
            update: function() {
                this.light.angle += 1
            },
            click_Button: function(e) {
                t.SoundMgr.playEffect("button");
                var n = function() {
                    if (cc.StorageInfo.click_Leve += 1,
                    cc.StorageInfo.click_Leve > cc.StorageInfo.Module[cc.StorageInfo.click_ModuleName].sumLevel)
                        return cc.StorageInfo.click_Leve = cc.StorageInfo.Module[cc.StorageInfo.click_ModuleName].sumLevel,
                        cc.StorageInfo.Module[cc.StorageInfo.click_ModuleName].now_Leve = cc.StorageInfo.Module[cc.StorageInfo.click_ModuleName].sumLevel,
                        void cc.director.loadScene("model");
                    cc.director.loadScene("Playing")
                };
                switch (e.target.name) {
                case "next":
                    console.log("下一关"),
                    cc.PlatformUtils.winVideo(),
                    n();
                    break;
                case "two_next":
                    console.log("双倍领取,下一关");
                    cc.PlatformUtils.executeShowVideo(function() {
                        cc.StorageInfo.sum_Money += 30,
                        n()
                    });
                    break;
                case "share":
                    return console.log("分享"),
                    void cc.PlatformUtils.executeShare();
                case "fanhui":
                    cc.director.loadScene("model")
                }
            }
        }),
        cc._RF.pop()
    }
    , {
        "../../../resources/Platform/PlatformUtils": "PlatformUtils",
        "../../TweenClass": "TweenClass",
        "../../Utils": "Utils"
    }],
    warningItem: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "4e116VvECNH/JwGjWYKcQk9", "warningItem"),
        cc.Class({
            extends: cc.Component,
            properties: {
                warning_text: {
                    default: null,
                    type: cc.Label,
                    displayName: "警告文字"
                }
            },
            onLoad: function() {
                var e = this;
                cc.tween(this.node).to(5, {
                    opacity: 0
                }, {
                    easing: "smooth"
                }).call(function() {
                    e.node.removeFromParent()
                }).start()
            },
            setWarning_text: function(e) {
                this.warning_text.string = e
            }
        }),
        cc._RF.pop()
    }
    , {}],
    xuanGuanItem: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "bbcf3wy1ndDl7ltnX2iJ2ms", "xuanGuanItem");
        var o = e("../../Utils");
        cc.Class({
            extends: cc.Component,
            properties: {
                level_content: {
                    default: null,
                    type: cc.Node,
                    displayName: "选关的关卡容器"
                }
            },
            onLoad: function() {},
            start: function() {
                var e = this;
                this.level_content.removeAllChildren();
                var n = cc.StorageInfo.Module[cc.StorageInfo.click_ModuleName];
                o.AssMgr.createPrefabByName("level", function(a) {
                    for (var o = 0; o < n.sumLevel; o++) {
                        var i = cc.instantiate(a);
                        e.level_content.addChild(i),
                        i.getComponent("levelItem").updateLevel(o + 1)
                    }
                })
            },
            clcik_Button: function(e) {
                switch (o.SoundMgr.playEffect("button"),
                e.target.name) {
                case "fanhui":
                    this.node.removeFromParent()
                }
            }
        }),
        cc._RF.pop()
    }
    , {
        "../../Utils": "Utils"
    }],
    yinsiScript: [function(e, n, a) {
        "use strict";
        cc._RF.push(n, "7f82fzsM3VAtKZKryGZiYC1", "yinsiScript"),
        cc.Class({
            extends: cc.Component,
            properties: {
                clickYinSiNode: cc.Node
            },
            start: function() {
                window.qg || window.qq || (this.node.active = !1)
            },
            onclickBtn: function() {
                this.clickYinSiNode ? this.clickYinSiNode.getComponent("UserYinsi").onShow() : console.log("请挂上隐私政策节点")
            }
        }),
        cc._RF.pop()
    }
    , {}]
}, {}, ["4399", "UserYinsi", "yinsiScript", "ButtonControl", "StorgeInfo", "TDHttps", "Hand_Prefab_Script", "JingBi", "CarItem", "MapItem", "gameData", "BuyMoneyItem", "FengXiang", "QianDao", "putong", "jianglIItem", "pushHintItem", "victory", "warningItem", "levelItem", "xuanGuanItem", "modelItem", "Load", "Main", "Model", "OnlineRewards", "Playing_Scene_Script", "TimeControl", "TweenClass", "Utils", "oppoUtil", "PlatformUtils", "QQUtil", "AlertBanner", "BoxHotWindow", "ExhibitionBar", "ExportNavigation", "LandscapeBanner", "LandscapeNavigation", "LargeNavigation", "LittleNavigation", "MutuallyItem", "NormalBanner", "NormalHotItem", "NormalNavigation", "SlideEvent", "SmallHotItem", "SpecialBanner", "NativeBanner", "NativeInterstitial", "TouTiaoTools", "_4399", "_UC", "_baidu", "_bytedance", "_huawei", "_oppo", "_tencent", "_wechat"]);